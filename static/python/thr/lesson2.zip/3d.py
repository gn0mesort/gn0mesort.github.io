import pygame
import moderngl
import numpy
import math
import sys
from pyglm import glm

WIDTH = 1280
HEIGHT = 720
# This is the camera's movement speed in world units per second.
CAMERA_SPEED = 1.0

# We don't strictly need a camera class, and this camera is simplistic compared a camera object for a 3d game.
# However, it's much easier to manage movement through a class like this than to try and manage it directly. When
# you add the complication of rotating the camera (i.e., mouse look) with respect to the world axes this simplifies
# the code significantly.
class Camera:
    """
    An object representing a 3D camera.
    """
    def __init__(self, position: glm.vec3 = glm.vec3(0, 0, 0)):
        """
        Construct a 3D camera at the given position.

        @type position: glm.vec3
        @param position: The initial position of the camera. This defaults to glm.vec3(0, 0, 0).
        """
        self.__UP = glm.vec3(0, 1, 0)
        self.__front = glm.vec3(0, 0, -1)
        self.__position = position
    def look(self) -> glm.mat4:
        """
        Produce a 4x4 view matrix using the camera's current position and direction.

        @rtype: glm.mat4
        @returns: A view matrix suitable for writing to a shader stage as the view transform of the world.
        """
        return glm.lookAt(self.__position, self.__position + self.__front, self.__UP)
    def move_forward(self, speed: float) -> None:
        """
        Move the camera forward by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move forward. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position + speed * self.__front
    def move_backward(self, speed: float) -> None:
        """
        Move the camera backward by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move backward. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position - speed * self.__front
    def move_left(self, speed: float) -> None:
        """
        Move the camera left by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move left. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position - speed * glm.normalize(glm.cross(self.__front, self.__UP))
    def move_right(self, speed: float) -> None:
        """
        Move the camera right by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move right. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position + speed * glm.normalize(glm.cross(self.__front, self.__UP))

# Floating-point comparison's are tricky. Computers only deal in 1s and 0s, something Python tries to conceal from
# us. Floating-point works by turning patterns of 1s and 0s into fractions. A float is made up of three parts, a sign
# (positive or negative), an exponent (power of 2), and a mantissa (a fraction written in binary). The mantissa is a
# lot like an int, but each step of the mantissa represents one epsilon unit (epsilon is a mathematical symbol that
# represents a small but non-zero difference. It looks like a cursive E) rather than exactly 1. Near zero, these
# epsilon units are very small and so lots of numbers can be represented. As we get further from zero, the distance
# between each unit becomes wider and wider. To compound this problem, floating-point numbers are stored
# in binary not decimal. Some decimal values cannot be properly represented in binary and vice-versa. The result is
# that even values that seem simple may not be exactly what we expect. For example, 0.3 is likely slightly more than
# 0.3 (perhaps 0.300000011920928955078). All of this makes comparing two floating-point values that are close
# together tricky.
#
# To handle this problem correctly, we need a function like this that can determine if two float values are almost
# equal.
def fequal(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    """
    Compare two floating-point values for equality with an epsilon

    @type a: float
    @param a: The first float to compare.
    @type b: float
    @param b: The second float to compare.
    @type epsilon: float
    @param epsilon: The maximum allowable difference between a and b before they are considered different. This
                    defaults to the system epsilon (sys.float_info.epsilon) which is appropriate for values near 0.
                    For larger values, you should choose an appropriate epsilon yourself.
    @rtype: bool
    @returns: True if a is approximately equal to b. False otherwise.
    """
    abs_a = math.fabs(a)
    abs_b = math.fabs(b)
    difference = math.fabs(a - b)
    # This handles the case where the two numbers are actually exactly equal. Still, they might not be what we expect,
    # precisely, but equal is equal.
    if a == b:
        return True
    # If either number is 0, or the sum of their absolute values is less than the smallest positive float value
    # we need to take care in how we measure their difference.
    elif a == 0 or b == 0 or abs_a + abs_b < sys.float_info.min:
        return difference < (epsilon * sys.float_info.min)
    # In other cases, we compute the "relative error". This means we determine if their difference divided by the
    # sum of their absolute values is less than some value epsilon.
    else:
        return difference / min(abs_a + abs_b, sys.float_info.max) < epsilon

# Often, in computers we work with two separate color systems. When we work with colors inside of programs we usually
# use "linear" color. In this system, each unit of color is exactly one unit brighter than the last. This is true
# regardless of whether or not we use 0-255 unscaled RGB or 0.0-1.0 scaled RGB (as we do here). However, this maps
# poorly to human vision and sometimes results in colors that appear incorrect to the human eye. To fix this
# we use a "non-linear" color system for screens. In these systems, each unit is not exactly one unit brighter than
# the last. How they behave depends on the specific color system instead. The most common of these systems is called
# sRGB. sRGB is commonly used for computer displays, but some professionals might use other color systems to get
# greater precision. Since we work with linear colors, we need to use a function like this to map from linear color to
# sRGB color.
#
# This function is required specifically for the linear to non-linear (a/k/a gamma) mapping. You shouldn't change it,
# however, you may choose to tweak the 2.4 into a larger or smaller number. This is called "gamma correction" and is
# how computer games usually handle image brightness.
def gamma(l: float) -> float:
    """
    Gamma encode a linear color channel into the sRGB colorspace.

    @type l: float
    @param l: The linear input color channel.
    @rtype: float
    @returns: The gamma encoded color channel value.
    """
    if l > 0.0031308 and not fequal(l, 0.0031308):
        return 1.055 * math.pow(l, 1 / 2.4) - 0.055
    return 12.92 * l

# Modern graphics processing hardware is programmable. During the drawing of 3d geometry, the GPU needs to execute
# programs to determine what the resulting image will look like. There are two required programs, and many optional
# programs. Conventionally, we call GPU programs "shaders", because he original purpose of these programs was to shade
# (i.e., color) 3d geometry. The first  required program is the vertex shader (a/k/a vertex shader stage).
# This program is responsible for determining where the vertices of a rendering are in the 3d volume. A vertex
# (plural "vertices") is a single point or corner on the erimeter (outside) of a shape. For 2d shapes (polygons) these
# are the corners that join sides. For 3d shapes (polyhedra) the location of vertices can be complex.
#
# In general, the only polygon a computer can render is the triangle. That means that complex polyhedra must usually
# be broken up into meshes (sometimes called nets) of triangles before drawing. Computers can also draw lines and
# points, but these are not truly polygons (and could be decomposed into triangles anyway if they were).
#
# This particular vertex program is very simple. It has three contants which represent the position of the mesh
# (model), the position of the camera (view), and the type of projection (projection) to use for the drawing. Each
# vertex is made up of seven float values. The first three float values are the (x, y, z) coordinate of the vertex in
# 3d space. The second four float values make up the color and transparency associated with the vertex. The position
# is used alongside the constant matrices to determine the final position of the vertex on the screen. The color is
# simply passed to the next stage.
vertex_src = """
#version 450 core
layout (location = 0) uniform mat4 model;
layout (location = 1) uniform mat4 view;
layout (location = 2) uniform mat4 projection;

layout (location = 0) in vec3 i_position;
layout (location = 1) in vec4 i_color;

layout (location = 0) out vec4 o_color;

void main() {
    o_color = i_color;
    gl_Position = projection * view * model * vec4(i_position, 1.0);
}
""".strip()


# The second required program is called a fragment shader (a/k/a fragment shader stage). The fragment shader is run
# once for every fragment in the mesh (a fragment is like a pixel but it is not strictly a pixel. For the sake of
# simplicity you can think of it as a pixel for now). This program determines what the color of that fragment will be.
#
# You'll see here that the gamma and fequal functions make another appearance. The reason for this is that the colors
# of the surface are interpolated (estimated) across the surface of our mesh. Each fragment might have a slightly
# different color. Therefore, we need to gamma encode each fragment individually. Besides gamma correction this
# program simply writes the color to the first output image (a/k/a color_0).
#
# These programs are both written in a language called GLSL (the OpenGL Shading Language) which is not much like Python
# at all. GLSL inherits its syntax from the C programming language. However, it's not much like C either.
fragment_src = """
#version 450 core

layout (location = 0) in vec4 i_color;

layout (location = 0) out vec4 color_0;

const float FLT_MAX = 3.402823466e+38;
const float FLT_MIN = 1.175494351e-38;

bool fequal(const float a, const float b, const float epsilon) {
    const float abs_a = abs(a);
    const float abs_b = abs(b);
    const float difference = abs(a - b);
    if (a == b)
    {
        return true;
    }
    else if (a == 0 || b == 0 || abs_a + abs_b < FLT_MIN)
    {
        return difference < (epsilon * FLT_MIN);
    }
    else
    {
        return difference / min(abs_a + abs_b, FLT_MAX) < epsilon;
    }
}

float gamma(const float l) {
    if (l > 0.0031308 && !fequal(l, 0.0031308, 1e-30))
    {
        return 1.055 * pow(l, 1.0 / 2.4) - 0.055;
    }
    return 12.92 * l;
}

vec4 gamma(const vec4 l) {
    return vec4(gamma(l.r), gamma(l.g), gamma(l.b), l.a);
}

void main() {
    color_0 = gamma(i_color);
}
""".strip()


# In 3d graphics, we usually work with what are called normalized device coordinates. Unlike the raster we've talked
# about in the past, the NDC volume has its origin at the center of the screen. This image can help you visualize it:
# https://i.pinimg.com/736x/84/f3/c6/84f3c6d93542bbf66c70a6eb9537e6bb--coding-tutorials-challenge-accepted.jpg
#
# Along the x-axis, negative numbers are to the left and positive are to the right. Along the y-axis positive numbers
# are up and negative numbers are down. Along the z-axis positive numbers are away from the viewer and negative numbers
# are toward the viewer. The origin sits in the center at (0, 0, 0).
#
# Colors are similarly normalized, but, usually, there are no negative colors. Each color is still made up of red,
# green, and blue channels. Instead of 0-255, though, the values start at 0 and max out at 1.0.
#
# This array (note it's a numpy array and not a list or tuple), represents the data that will be sent to our shader
# programs to draw our image. It first contains position data in 3d coordinates. Next, it contains color data for each
# point on our drawing. What shape does this draw?
vertices = numpy.array((-0.5, -0.5, 0.0, 1.0, 0.0, 0.0, 1.0,
                         0.0,  0.5, 0.0, 0.0, 1.0, 0.0, 1.0,
                         0.5, -0.5, 0.0, 0.0, 0.0, 1.0, 1.0))

# It's not strictly necessary, but commonly we want to deduplicate vertex data by telling the GPU which vertex to
# process in what order. We do this through an index array. Here, though, we just draw each index in order.
indices = numpy.array((0, 1, 2))
# We still have to initialize PyGame.
pygame.init()
# After initialization, but before creating our screen, we need to give the display some information about our 3d
# rendering context. Here we set the following parameters:
#
# OpenGL version -> 4.5
# OpenGL profile -> core
#
# The core profile means we can only use OpenGL 4.5 features and not older features retained for compatibility.
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 4)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 5)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE)
# Finally, we actually create of display window. We have to ask specifically for OpenGL and for double buffering.
pygame.display.set_mode((WIDTH, HEIGHT), pygame.DOUBLEBUF | pygame.OPENGL)
# Next, we need to get the 3d rendering context.
gl = moderngl.get_context()
# This enables rendering with depth (i.e., 3d rendering). We can still do 3d with this disabled, but it's harder.
# What happens if you comment out this line and place two drawings very close to each other?
gl.enable(gl.DEPTH_TEST)
# We still need a clock.
clock = pygame.time.Clock()
quitting = False
# OpenGL has to prepare our shader programs explicitly. This is actually a two step process where each shader is
# compiled (i.e., translated to something the GPU understands) and then linked (i.e., hooked together so data will flow
# correctly).
shader = gl.program(vertex_shader=vertex_src, fragment_shader=fragment_src)
# In OpenGL, data has to be sent to the GPU explicitly. To do this we create a buffer and store our data in it.
# This first buffer contains vertex data so it is a vertex buffer object (VBO). We send the data as "f4"
# (floating-point with 4 bytes per value).
vbo = gl.buffer(vertices.astype("f4").tobytes())
# Similarly, we need to send our index data. This is called an element buffer by OpenGL so we refer to it as an
# element buffer object (EBO). Here we send the data as "u4" (unsigned integer with 4 bytes per value).
ebo = gl.buffer(indices.astype("u4").tobytes())
# Finally, we must create a vertex array object. This is a confusing name. What this actually does is tell OpenGL how
# to read our vertex and index data. It also informs OpenGL of which shader program we'd like to run.
vao = gl.vertex_array(shader, vbo, "i_position", "i_color", index_buffer=ebo)
# Here we're going to create our rendering constants. Each of these is a matrix (a 4x4 block of floating-point values
# in this case).
#
# For the projection matrix we create a perspective projection. In this projection, objects that are further away are
# drawn smaller than objects up close. The other common projection is called an orthographic projection. In an
# orthographic projection, each object retains its size over distance.
projection = glm.perspective(glm.radians(45.0), WIDTH / HEIGHT, 0.1, 1000.0)
# The camera object represents the eye or lens of the camera viewing the scene. It is used to compile the second matrix
# called the view matrix.
camera = Camera(glm.vec3(0.0, 0.0, 2.0))
# The last matrix is the model matrix. It represents the transformation of the drawn geometry in space. A
# transformation is made up of a translation, rotation, scale, and less commonly shearing. Translation moves the
# object around in space. Rotation does what you would expect. Scaling makes the object larger or smaller.
model = glm.mat4()
delta_time = 0.0
# For smooth controls, we need to retain the control's state across frames. To do this, we're storing each control as
# a bool in a dictionary keyed with PyGame key constants.
controls = { pygame.K_w: False, pygame.K_a: False, pygame.K_s: False, pygame.K_d: False }
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        # This sets the control dict's state to the correct state depending on key events.
        if (event.type == pygame.KEYDOWN or event.type == pygame.KEYUP) and event.key in controls.keys():
            controls[event.key] = event.type == pygame.KEYDOWN
    # FIXME: You should write something here to make the camera move around. You can use Camera.move_forward,
    # Camera.move_backward, Camera.move_left, and Camera.move_right to ensure correct movement. However, you must check
    # keys yourself and determine which direction to move each time.
    pass
    # This will rotate our drawing at a rate of 72 degrees per second. That means it should take 5 seconds to rotate
    # all the way around.
    model = glm.rotate(model, glm.radians(72) * delta_time, glm.vec3(0, 1, 0))
    # We need to clear the screen once per frame to ensure a blank drawing surface. I like to blank with a non-zero
    # color because it helps with debugging.
    gl.clear(gamma(0.2), gamma(0.2), gamma(0.2), 1.0)
    # Next, we need to write our constants to the GPU.
    shader["model"].write(model)
    shader["view"].write(camera.look())
    shader["projection"].write(projection)
    # Finally, we draw.
    vao.render()
    # When the drawing is complete we flip the display so that our drawing is visible.
    pygame.display.flip()
    # Then we calculate how much time has passed.
    delta_time = clock.tick() / 1000.0
pygame.quit()

# Once you have movement working, you should try some of the following things:
#
# 1. Drawing a second mesh at the different positon. You can use glm.translate to move a mesh around.
# 2. Try tampering with some of the values here. What happens if you reduce the number of degrees in the rotation?
#    What happens if you change the color values in vertices? What happens if you change the camera's UP vector?
# 3. See if you can figure out how to draw a square or rectangle in 3d space. How many vertices do you need for a
#    rectangle?
#
# Useful Links:
#     https://github.com/Zuzu-Typ/PyGLM
#     https://moderngl.readthedocs.io/en/5.8.2/index.html
