import pygame

WIDTH = 1280
HEIGHT = 720

def redraw(screen, sprite, x, y, width, height):
    screen.fill((0, 0, 0))
    screen.blit(sprite, (x, y, width, height))

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
quitting = False
player_sprite = pygame.Surface((16, 16), flags=pygame.SRCALPHA)
player_sprite.fill((255, 0, 0))
player_x = int(1280 / 2) - int(player_sprite.get_width() / 2)
player_y = int(720 / 2) - int(player_sprite.get_height() / 2)
player_speed = 16
screen.fill((0, 0, 0))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                player_y = player_y - player_speed
                redraw(screen, player_sprite, player_x, player_y, 16, 16)
            elif event.key == pygame.K_s:
                player_y = player_y + player_speed
                redraw(screen, player_sprite, player_x, player_y, 16, 16)
            elif event.key == pygame.K_a:
                player_x = player_x - player_speed
                redraw(screen, player_sprite, player_x, player_y, 16, 16)
            elif event.key == pygame.K_d:
                player_x = player_x + player_speed
                redraw(screen, player_sprite, player_x, player_y, 16, 16)
    pygame.display.flip()
    clock.tick()
pygame.quit()
