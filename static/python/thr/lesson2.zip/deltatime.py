from dataclasses import dataclass

import pygame

@dataclass
class PlayerData:
    # Because we're now using smooth movements, our position can actually be in between pixels (we'll still always
    # land on one pixel or another though).
    x: float = 0
    y: float = 0
    speed: float = 0
    sprite: pygame.Surface = None

WIDTH = 1280
HEIGHT = 720

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
quitting = False
player = PlayerData()
player.sprite = pygame.Surface((16, 16), flags=pygame.SRCALPHA)
player.sprite.fill((255, 0, 0))
player.x = int(1280 / 2) - int(player.sprite.get_width() / 2)
player.y = int(720 / 2) - int(player.sprite.get_height() / 2)
# This is now in pixels per second and not pixels per input!!
player.speed = 128
delta_time = 0.0
keys = { pygame.K_w: False, pygame.K_s: False, pygame.K_a: False, pygame.K_d: False }
screen.fill((0, 0, 0))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if (event.type == pygame.KEYDOWN or event.type == pygame.KEYUP) and event.key in keys.keys():
            keys[event.key] = event.type == pygame.KEYDOWN
    if keys[pygame.K_w]:
        player.y = player.y - player.speed * delta_time
    elif keys[pygame.K_s]:
        player.y = player.y + player.speed * delta_time
    if keys[pygame.K_a]:
        player.x = player.x - player.speed * delta_time
    elif keys[pygame.K_d]:
        player.x = player.x + player.speed * delta_time
    screen.fill((0, 0, 0))
    screen.blit(player.sprite, (player.x, player.y, player.sprite.get_width(), player.sprite.get_height()))
    pygame.display.flip()
    delta_time = clock.tick() / 1000.0
pygame.quit()


