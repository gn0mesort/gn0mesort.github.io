from dataclasses import dataclass

import pygame

@dataclass
class PlayerData:
    x: float = 0
    y: float = 0
    speed: float = 0
    sprite: pygame.Surface = None

WIDTH = 1280
HEIGHT = 720

# This will load and set up the player's sprite. A sprite is an image used to represent a character in a 2D game.
# The player's sprite will be a UFO described by ufo.webp. Your PyGame implementation may not load WebP files. If
# that's the case, try ufo.png or ufo.bmp (as a last resort).
def create_ufo(width: int, height: int) -> PlayerData:
    """
    Create a UFO sprite with associated player data.

    @type width: int
    @param width: The screen width in pixels. This is used to determine where to place the UFO.
    @type height: int
    @param height: The screen height in pixels. This is used to determine where to place the UFO.
    @rtype: PlayerData
    @returns: A PlayerData object that is placed at the center of the screen rectangle and has a UFO sprite loaded.
    """
    pass

# This function will warp the player around when they leave the screen. The result is that the space works a little
# bit like it was the surface of a donut. When the player leaves the bottom of the screen, they should reappear at
# the top. When they leave at the top, they reappear at the bottom. The same should work with left and right.
def warp(player: PlayerData) -> None:
    """
    Warp a player so they wrap around the edges of the screen. This is consistent across diagonals too.

    @type player: PlayerData
    @param player: The player to warp. The player is modified by this operation. This must not be None.
    """
    pass

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
quitting = False
player = create_ufo(WIDTH, HEIGHT)
delta_time = 0.0
keys = { pygame.K_w: False, pygame.K_s: False, pygame.K_a: False, pygame.K_d: False }
screen.fill((0, 0, 0))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if (event.type == pygame.KEYDOWN or event.type == pygame.KEYUP) and event.key in keys.keys():
            keys[event.key] = event.type == pygame.KEYDOWN
    if keys[pygame.K_w]:
        player.y = player.y - player.speed * delta_time
    elif keys[pygame.K_s]:
        player.y = player.y + player.speed * delta_time
    if keys[pygame.K_a]:
        player.x = player.x - player.speed * delta_time
    elif keys[pygame.K_d]:
        player.x = player.x + player.speed * delta_time
    warp(player)
    screen.fill((0, 0, 0))
    screen.blit(player.sprite, (player.x, player.y, player.sprite.get_width(), player.sprite.get_height()))
    pygame.display.flip()
    delta_time = clock.tick() / 1000.0
pygame.quit()
