from dataclasses import dataclass

import pygame

@dataclass
class PlayerData:
    x: int = 0
    y: int = 0
    speed: int = 0
    sprite: pygame.Surface = None

WIDTH = 1280
HEIGHT = 720

def redraw(screen: pygame.Surface, player: PlayerData) -> None:
    screen.fill((0, 0, 0))
    screen.blit(player.sprite, (player.x, player.y, player.sprite.get_width(), player.sprite.get_height()))

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
quitting = False
player = PlayerData()
player.sprite = pygame.Surface((16, 16), flags=pygame.SRCALPHA)
player.sprite.fill((255, 0, 0))
player.x = int(1280 / 2) - int(player.sprite.get_width() / 2)
player.y = int(720 / 2) - int(player.sprite.get_height() / 2)
player.speed = 16
screen.fill((0, 0, 0))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                player.y = player.y - player.speed
                redraw(screen, player)
            elif event.key == pygame.K_s:
                player.y = player.y + player.speed
                redraw(screen, player)
            elif event.key == pygame.K_a:
                player.x = player.x - player.speed
                redraw(screen, player)
            elif event.key == pygame.K_d:
                player.x = player.x + player.speed
                redraw(screen, player)
    pygame.display.flip()
    clock.tick()
pygame.quit()
