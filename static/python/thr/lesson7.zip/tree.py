from __future__ import annotations

class Tree:
    def __init__(self, data):
        self.__data = data
        self.__children = [ ]
    def data(self):
        return self.__data
    def child_at(self, index: int) -> Tree:
        return self.__children[index]
    def add_child(self, data) -> None:
        self.__children.append(Tree(data))
