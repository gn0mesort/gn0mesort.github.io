from __future__ import annotations

class BinaryTree:
    def __init__(self, data):
        self.__data = data
        self.__left = None
        self.__right = None
    def data(self):
        return self.__data
    def left_child(self) -> BinaryTree:
        return self.__left
    def right_child(self) -> BinaryTree:
        return self.__right
    def add_left_child(self, data) -> None:
        if self.__left is None:
            self.__left = BinaryTree(data)
        else:
            raise RuntimeError("The tree already has a left child.")
    def add_right_child(self, data) -> None:
        if self.__right is None:
            self.__right = BinaryTree(data)
        else:
            raise RuntimeError("The tree already has a right child.")
