from __future__ import annotations
import math
import pygame
import pygame.freetype
from pathlib import Path

class LinkedList:
    def __init__(self, value):
        self.__value = value
        self.__next = None
    def insert_after(self, value) -> None:
        next = None
        if self.__next is not None:
            next = self.__next
        self.__next = LinkedList(value)
        self.__next.__next = next
    def remove(self, value) -> None:
        prev = self
        head = self.__next
        while head is not None:
            if head.__value == value:
                prev.__next = head.__next
                head = None
            else:
                prev = head
                head = head.__next
    def append(self, value) -> None:
        head = self
        ids = set()
        while head.__next is not None:
            if id(head) in ids:
                raise RuntimeError("There is a duplicate ID in the list.")
            ids.add(id(head))
            head = head.__next
        head.__next = LinkedList(value)
    def next(self) -> LinkedList:
        return self.__next
    def value(self):
        return self.__value
    @staticmethod
    def to_ring(head: LinkedList) -> LinkedList:
        ids = set()
        dummy = head
        while dummy.__next is not None:
            if id(dummy) in ids:
                raise RuntimeError("There is a duplicate ID in the list.")
            ids.add(id(dummy))
            dummy = dummy.__next
        dummy.__next = head
        return head

def prepare_string(message: str) -> str:
    return message.strip().replace("\t", " ").replace("\f", " ").replace("\r", " ")

def truncate_string(message: str, typeface: pygame.freetype.Font, max_width: int) -> (int, bool, str):
    real = len(message)
    smessage = message
    width = typeface.get_rect(message).width
    cut = 0
    a = 0
    done = True
    old = None
    while width > max_width:
        a += 1
        next = message.rsplit(None, a)[0]
        if smessage == next:
            cut += 1
            smessage = next[:-cut]
        else:
            smessage = next
        width = typeface.get_rect(smessage).width
        real = len(smessage)
        done = False
    return (real, done, smessage)

def linewrap(message: str, typeface: pygame.freetype.Font, columns: int, rows: int = 1) -> list[str]:
    wrapped = [ ]
    lines = message.split("\n")
    em = typeface.get_rect("M")
    for i, line in enumerate(lines):
        lines[i] = prepare_string(line)
    for line in lines:
        done = False
        while not done:
            next_line, done, smessage = truncate_string(line, typeface, columns * em.width)
            wrapped.append(smessage.strip())
            line = line[next_line:]
    blocks = [ ]
    if rows > 1:
        for i in range(0, len(wrapped), rows):
            merged = None
            if i + rows < len(wrapped):
                merged = "\n".join(wrapped[i:i + rows])
            else:
                merged = "\n".join(wrapped[i:])
            blocks.append(merged)
    return blocks

class SpriteMap:
    def __init__(self, path: str|Path, width: int, height: int):
        if width < 1 or height < 1:
            raise RuntimeError(f"The smallest sprite size is 1x1, but the input size was {width}x{height}.")
        self.__width = int(width)
        self.__height = int(height)
        self.__surface = pygame.image.load(path)
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def size(self) -> (int, int):
        return (self.__width, self.__height)
    def convert(self, surface: pygame.surface.Surface|None = None) -> None:
        if surface is None:
            self.__surface = self.__surface.convert()
        else:
            self.__surface = self.__surface.convert(surface)
    def convert_alpha(self, surface: pygame.surface.Surface|None = None) -> None:
        if surface is None:
            self.__surface = self.__surface.convert_alpha()
        else:
            self.__surface = self.__surface.convert_alpha(surface)
    def get(self, x: int, y: int) -> pygame.surface.Surface:
        return self.__surface.subsurface(pygame.Rect(x * self.__width, y * self.__height, self.__width, self.__height))

def center(source: (int, int), destination: (int, int)) -> (int, int):
    return ((destination[0] - source[0]) // 2, (destination[1] - source[1]) // 2)

def render_box(boxmap: SpriteMap, rect: pygame.Rect, bgcolor = pygame.Color(0, 0, 0)) -> pygame.surface.Surface:
    image = pygame.surface.Surface(rect.bottomright, flags=pygame.SRCALPHA).convert_alpha()
    image.fill(bgcolor)
    width_in_tiles = image.get_width() // boxmap.width()
    height_in_tiles = image.get_height() // boxmap.height()
    for i in range(height_in_tiles):
        for j in range(width_in_tiles):
            source = None
            if (j, i) == (0, 0):
                source = boxmap.get(0, 0)
            elif (j, i) == (width_in_tiles - 1, 0):
                source = boxmap.get(3, 0)
            elif (j, i) == (0, height_in_tiles - 1):
                source = boxmap.get(0, 3)
            elif (j, i) == (width_in_tiles - 1, height_in_tiles - 1):
                source = boxmap.get(3, 3)
            elif i == 0:
                source = boxmap.get(1, 0)
            elif i == height_in_tiles - 1:
                source = boxmap.get(1, 3)
            elif j == 0:
                source = boxmap.get(0, 1)
            elif j == width_in_tiles - 1:
                source = boxmap.get(3, 1)
            if source is not None:
                image.blit(source, (j * boxmap.width(), i * boxmap.height()))
    return image

def render_dialogue(message: str, typeface: pygame.freetype.Font, boxmap: SpriteMap, bgcolor = pygame.Color(0, 0, 0)) -> pygame.surface.Surface:
    lines = message.split("\n")
    subsurfaces = [ ]
    rect = pygame.Rect(0, 0, 0, 0)
    for line in lines:
        subsurface, subrect = typeface.render(line, fgcolor=pygame.Color(255, 255, 255))
        if rect.width < subrect.width:
            rect.width = subrect.width
        if rect.height != 0:
            rect.height += 2
        rect.height += subrect.height
        subsurfaces.append(subsurface)
    surface = pygame.surface.Surface(rect.size, flags=pygame.SRCALPHA)
    for subsurface in subsurfaces:
        surface.blit(subsurface, rect.topleft)
        rect.top += 2 + subrect.height
    rect = surface.get_rect()
    rect.width = (rect.width // boxmap.width() + 4) * boxmap.width()
    rect.height = (rect.height // boxmap.height() + 4) * boxmap.height()
    box = render_box(boxmap, rect, bgcolor=bgcolor)
    box.blit(surface, center(surface.get_rect().size, box.get_rect().size))
    return box
