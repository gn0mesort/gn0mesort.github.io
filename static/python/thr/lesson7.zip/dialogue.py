from __future__ import annotations
from library import *

WIDTH = 640
HEIGHT = 480
DEBUG = True

LEFT = 0
RIGHT = 1

class BinaryChoiceTree:
    # FIXME: We need to implement a complete binary tree here.
    # We need a constructor, accessor methods, and methods for adding/inserting elements into the tree below the
    # root.
    # Each tree element must have a message/prompt and exactly two choices. The choices can be "" to indicate the
    # lack of a choice, but then they must BOTH be "".
    pass

def play_sound(sound: pygame.mixer.Sound) -> None:
    if sound.get_num_channels() > 0:
        sound.stop()
    sound.play()

def next_cursor(cursor: int) -> int:
    return (cursor + 1) & 1

def previous_cursor(cursor: int) -> int:
    cursor = cursor - 1
    if cursor < 0:
        cursor = RIGHT + 1 + cursor
    return cursor

pygame.init()
boxmap = SpriteMap("box.webp", 4, 4)
pointer = pygame.image.load("pointer.webp")
actionsound = pygame.mixer.Sound("action.wav")
typeface = pygame.freetype.Font("nec.ttf", 12)
typeface.antialiased = False
screen = pygame.display.set_mode((WIDTH, HEIGHT))
boxmap.convert_alpha()
# FIXME: We need to set up a tree with dialogue here. Each tree element
pass
quitting = False
cursor = LEFT
use_cursor = len(head.left_choice()) > 0
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_ESCAPE:
                quitting = True
            elif event.key == pygame.K_UP or event.key == pygame.K_w:
                play_sound(actionsound)
                cursor = previous_cursor(cursor)
            elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                play_sound(actionsound)
                cursor = next_cursor(cursor)
            elif event.key == pygame.K_e or event.key == pygame.K_RETURN:
                # FIXME: Here we need to process input for our choice. There are two possible scenarios here.
                # First, the tree can have a left and a right child (a binary choice). In this case we must use the
                # cursor to determine which path to follow.
                #
                # The second case is linear dialogue. In this case there is no choice at all. We just follow the left
                # path.
                #
                # We can decide which scenario we have based on use_cursor.
                pass
    screen.fill(pygame.Color(0, 0, 0))
    prompt = render_dialogue(head.prompt(), typeface, boxmap, bgcolor=pygame.Color(0, 0, 255))
    prompt = pygame.transform.scale(prompt, (prompt.get_width() * 2, prompt.get_height() * 2))
    position = center(prompt.get_rect().size, screen.get_rect().size)
    screen.blit(prompt, position)
    if use_cursor:
        choices = render_dialogue(head.left_choice() + "\n" + head.right_choice(), typeface, boxmap, bgcolor=pygame.Color(0, 0, 255))
        choices = pygame.transform.scale(choices, (choices.get_width() * 2, choices.get_height() * 2))
        screen.blit(choices, (position[0], position[1] + prompt.get_height() + 10))
        if cursor == LEFT:
            screen.blit(pointer, (position[0] - 32, position[1] + prompt.get_height() + 10 + 8))
        else:
            screen.blit(pointer, (position[0] - 32, position[1] + prompt.get_height() + 10 + 40))
    pygame.display.update()
pygame.quit()
