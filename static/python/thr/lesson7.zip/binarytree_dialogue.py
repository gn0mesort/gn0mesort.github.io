from __future__ import annotations

class BinaryTree:
    def __init__(self, data):
        self.__data = data
        self.__left = None
        self.__right = None
    def data(self):
        return self.__data
    def left_child(self) -> BinaryTree:
        return self.__left
    def right_child(self) -> BinaryTree:
        return self.__right
    def add_left_child(self, data) -> None:
        if self.__left is None:
            self.__left = BinaryTree(data)
        else:
            raise RuntimeError("The tree already has a left child.")
    def add_right_child(self, data) -> None:
        if self.__right is None:
            self.__right = BinaryTree(data)
        else:
            raise RuntimeError("The tree already has a right child.")

root = BinaryTree({ "message": "How are you today?", "a": "Good", "b": "Bad" })
root.add_left_child({ "message": "That's great!" })
root.add_right_child({ "message": "What's wrong?", "a": "I'm hungry", "b": "I'm tired" })
root.right_child().add_left_child({ "message": "You should eat!" })
root.right_child().add_right_child({ "message": "You should sleep!" })

element = root
while element is not None:
    print(element.data()["message"])
    if "a" in element.data():
        print(f"a) {element.data()["a"]}")
    if "b" in element.data():
        print(f"b) {element.data()["b"]}")
    if "a" in element.data() or "b" in element.data():
        choice = input("> ").lower().strip()
        if choice == "a":
            element = element.left_child()
        elif choice == "b":
            element = element.right_child()
    else:
        element = element.left_child()
