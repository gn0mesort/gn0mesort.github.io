dialogue = ("No one touches my Princess!!", "LIGHT WARRIORS??", "You impertinent fools.",
            "I, Gardland, will knock you all down!!")

for line in dialogue:
    print(line)
    input("> ")
