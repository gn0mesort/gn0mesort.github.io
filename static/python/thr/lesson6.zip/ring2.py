class Ring:
    def __init__(self, data: list):
        self.__data = data.copy()
        self.__current = 0
    def value(self):
        return self.__data[self.__current]
    def next(self):
        self.__current = (self.__current + 1) % len(self.__data)

ring = Ring([ "No one touches my Princess!!", "LIGHT WARRIORS??", "You impertinent fools.",
              "I, Garland, will knock you all down!!" ])

while True:
    print(ring.value())
    input("> ")
    ring.next()
