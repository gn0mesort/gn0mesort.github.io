WIDTH = 80
HEIGHT = 24

DEFAULT = "\x1b[0m"
RED = "\x1b[41m"
GREEN = "\x1b[42m"
BLUE = "\x1b[44m"

def box(window: list, x: int, y: int, width: int, height: int, bgcolor: str = BLUE) -> None:
    if (x + width) * (y + height) >= len(window):
        raise RuntimeError("Out of bounds index.")
    for i in range(y, y + height):
        for j in range(x, x + width):
            index = i * WIDTH + j
            complex_condition = (j == x and i == y) or (j == x + width - 1 and i == y + height - 1)
            complex_condition = complex_condition or (j == x and i == y + height - 1)
            complex_condition = complex_condition or (j == x + width - 1 and i == y)
            if complex_condition:
                window[index] = f"{DEFAULT}*{DEFAULT}"
            elif j == x or j == x + width - 1:
                window[index] = f"{DEFAULT}|{DEFAULT}"
            elif i == y or i == y + height - 1:
                window[index] = f"{DEFAULT}-{DEFAULT}"
            else:
                window[index] = f"{bgcolor} {DEFAULT}"

def display(window: list) -> None:
    for i in range(HEIGHT):
        for j in range(WIDTH):
             print(window[i * WIDTH + j], end="")
        print("")

window = [ f"{DEFAULT} {DEFAULT}" ] * (WIDTH * HEIGHT)
box(window, 0, 0, 40, 12)
box(window, 38, 10, 20, 6)
display(window)
