from __future__ import annotations
import pygame
import pygame.freetype
from library import *

WIDTH = 1280
HEIGHT = 720
DEBUG = True

class LinkedList:
    def __init__(self, value):
        self.__value = value
        self.__next = None
    def insert_after(self, value) -> None:
        # FIXME: This method should add a value into the list right after the head of the list.
        pass
    def remove(self, value) -> None:
        # FIXME: This method should behave like the regular list.remove() method. It needs to find the first
        # matching element in the list, and remove that element from the list while keeping the list in tact.
        pass
    def append(self, value) -> None:
        # FIXME: This method should behave like the remove list.append() method. It needs to find the end of the
        # list and add the new value after it. However, if the list is a ring, it should fail!
        pass
    def next(self) -> LinkedList:
        return self.__next
    def value(self):
        return self.__value
    @staticmethod
    def to_ring(head: LinkedList) -> LinkedList:
        # FIXME: This method should turn a regular linked list into a ring by assigning the tail to reference the
        # head of the list.
        pass

def render_box(boxmap: SpriteMap, rect: pygame.Rect, bgcolor = pygame.Color(0, 0, 0)) -> pygame.surface.Surface:
    # FIXME: This method must render a box with the given border in boxmap. The box should have the desired background
    # color and dimensions
    pass

def render_dialogue(message: str, typeface: pygame.freetype.Font, boxmap: SpriteMap, bgcolor = pygame.Color(0, 0, 0)) -> pygame.surface.Surface:
    lines = message.split("\n")
    subsurfaces = [ ]
    rect = pygame.Rect(0, 0, 0, 0)
    for line in lines:
        subsurface, subrect = typeface.render(line, fgcolor=pygame.Color(255, 255, 255))
        if rect.width < subrect.width:
            rect.width = subrect.width
        if rect.height != 0:
            rect.height += 2
        rect.height += subrect.height
        subsurfaces.append(subsurface)
    surface = pygame.surface.Surface(rect.size, flags=pygame.SRCALPHA)
    for subsurface in subsurfaces:
        surface.blit(subsurface, rect.topleft)
        rect.top += 2 + subrect.height
    rect = surface.get_rect()
    rect.width = (rect.width // boxmap.width() + 4) * boxmap.width()
    rect.height = (rect.height // boxmap.height() + 4) * boxmap.height()
    box = render_box(boxmap, rect, bgcolor=bgcolor)
    box.blit(surface, center(surface.get_rect().size, box.get_rect().size))
    return box

pygame.init()
boxmap = SpriteMap("box.webp", 4, 4)
typeface = pygame.freetype.Font("nec.ttf", 12)
typeface.antialiased = False
screen = pygame.display.set_mode((WIDTH, HEIGHT))
boxmap.convert_alpha()
text = """
    No one touches my Princess!!
    LIGHT WARRIORS?? You impertinent fools. I, Garland, will knock you all down!!
""".strip()
lines = [ ]
for line in text.split("\n"):
    lines.extend(linewrap(line, typeface, 35, 4))
# FIXME: We need to construct a linked list here. This should be simple using the class we've already worked on.
# Finally, we need to turn the linked list into a ring.
pass
dialogue = render_dialogue(head.value(), typeface, boxmap, bgcolor=pygame.Color(0, 0, 255))
scaled = pygame.transform.scale(dialogue, (dialogue.get_width() * 4, dialogue.get_height() * 4))
screen.blit(scaled, center(scaled.get_rect().size, screen.get_rect().size))
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP and event.key == pygame.K_ESCAPE:
            quitting = True
        elif event.type == pygame.KEYUP and event.key == pygame.K_e:
            screen.fill((0, 0, 0))
            if head is not None:
                head = head.next()
            if head is not None:
                dialogue = render_dialogue(head.value(), typeface, boxmap, bgcolor=pygame.Color(0, 0, 255))
                scaled = pygame.transform.scale(dialogue, (dialogue.get_width() * 4, dialogue.get_height() * 4))
                screen.blit(scaled, center(scaled.get_rect().size, screen.get_rect().size))
    pygame.display.update()
pygame.quit()
