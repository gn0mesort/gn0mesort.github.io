from __future__ import annotations

class LinkedListNode:
    def __init__(self, value):
        self.__value = value
        self.__next = None
    def value(self):
        return self.__value
    def next(self) -> LinkedListNode:
        return self.__next
    def insert_after(self, next: LinkedListNode) -> None:
        self.__next = next

dialogue = LinkedListNode("No one touches my Princess!!")
dummy = dialogue
dummy.insert_after(LinkedListNode("LIGHT WARRIORS??"))
dummy = dummy.next()
dummy.insert_after(LinkedListNode("You impertinent fools."))
dummy = dummy.next()
dummy.insert_after(LinkedListNode("I, Garland, will knock you all down!!"))
dummy = dummy.next()
dummy.insert_after(dialogue)

dummy = dialogue
while dummy is not None:
    print(dummy.value())
    input("> ")
    dummy = dummy.next()
