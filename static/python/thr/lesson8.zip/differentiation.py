from collections.abc import Callable

def f(x: int|float) -> int|float:
    return x * x

def differentiate(fn: Callable, x: int|float, step: int|float = 1e-5) -> int|float:
    center = (x, fn(x))
    forward = (x + step, fn(x + step))
    backward = (x - step, fn(x - step))
    first = (forward[1] - center[1]) / (forward[0] - center[0])
    second = (backward[1] - center[1]) / (backward[0] - center[0])
    return (first + second) / 2

print("  x |    y")
for i in range(-10, 11, 1):
    print(f" {i} | {differentiate(f, i)}")
