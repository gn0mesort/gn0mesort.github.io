import pygame

WIDTH = 640
HEIGHT = 480
FIXED_UPDATE = 1.0 / 60.0
FLOOR_WIDTH = WIDTH // 16
GRAVITY = 980

pygame.init()
box = pygame.surface.Surface((16, 16), flags=pygame.SRCALPHA)
box.fill(pygame.Color(255, 255, 255))
player = box.get_rect()
player.topleft = ((WIDTH - player.width) // 2, HEIGHT - 2 * player.height)
velocity = [ 0, 0 ]
floor = pygame.surface.Surface((16, 16), flags=pygame.SRCALPHA)
floor.fill(pygame.Color(128, 128, 128))
screen = pygame.display.set_mode((WIDTH, HEIGHT))
floor = floor.convert_alpha()
box = box.convert_alpha()
clock = pygame.time.Clock()
acc = 0
dt = 0

quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                if player.y + player.height == HEIGHT - floor.get_height():
                    velocity = [ 0, 720 ]
    while acc >= FIXED_UPDATE:
        if player.y + player.height < HEIGHT - floor.get_height():
            velocity[1] = velocity[1] - GRAVITY * FIXED_UPDATE
        elif player.y + player.height > HEIGHT - floor.get_height():
            player.y = HEIGHT - floor.get_height() - player.height
            velocity = [ 0, 0 ]
        acc = acc - FIXED_UPDATE
    player.y = player.y - velocity[1] * dt
    screen.fill(pygame.Color(0, 0, 0))
    for i in range(FLOOR_WIDTH):
        screen.blit(floor, (i * floor.get_width(), HEIGHT - floor.get_height()))
    screen.blit(box, player.topleft)
    pygame.display.update()
    dt = clock.tick() / 1000.0
    acc = acc + dt
pygame.quit()
