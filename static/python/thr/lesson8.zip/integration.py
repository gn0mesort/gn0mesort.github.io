from collections.abc import Callable

def f(x: int|float) -> int|float:
    return 2 * x

def integrate(fn: Callable, start: int|float, end: int|float, step: int|float = 1e-5) -> int|float:
    current = start
    total = 0
    while abs(current - end) > abs(step):
        total = total + fn(current) * step
        current = current + step
    return total

print("  x |    y")
for i in range(-10, 11, 1):
    if i < 0:
        print(f"{i} | {integrate(f, 0, i, -1e-5)}")
    else:
        print(f" {i} | {integrate(f, 0, i)}")
