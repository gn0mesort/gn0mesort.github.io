import pygame
import pygame.freetype
import pymunk
import pymunk.pygame_util

from library import *

DEBUG = False
WIDTH = 640
HEIGHT = 480
TILE_WIDTH = 16
TILE_HEIGHT = 16

class FixedUpdateStep:
    def __init__(self, time: float):
        # FIXME: We need to initialize our fixed updater here.
        pass
    def _update_handler(self, dt: float, fresh: bool) -> None:
        pass
    def tick(self, dt: float) -> None:
        # FIXME: This is where we accumulate time for the fixed updater.
        pass
    def update(self) -> None:
        # FIXME: This is where we perform updates. We need to update until the accumulator is less than the time of
        # our fixed update step. We also need to indicate to the update handler when this is the first update for
        # a given frame.
        pass

class PhysicsUpdateStep(FixedUpdateStep):
    UPDATE_TIME: float = 1 / 60
    STEPS_PER_UPDATE: int  = 4
    MAX_UPDATES_PER_FRAME: int = 8
    def __init__(self, space: pymunk.Space):
        # FIXME: We need to initialize our physics updater here.
        pass
    def _update_handler(self, dt: float, fresh: bool) -> None:
        # FIXME: This is where our physics step needs to take place. Although one step is sufficient, it's better
        # to run a few steps per update. We also need to ensure that we only run a fixed number of updates per frame.
        # If the framerate becomes very low (e.g. <1 Hz) it can trigger lots and lots of physics updates at once which
        # will make the next frame even slower. To prevent this we can use the fresh parameter to determine if we're
        # running in a new frame or not.
        pass

class FramerateUpdateStep(FixedUpdateStep):
    UPDATE_TIME: float = 1 / 6
    def __init__(self, clock: pygame.time.Clock, typeface: pygame.freetype.Font):
        super().__init__(FramerateUpdateStep.UPDATE_TIME)
        self.__clock = clock
        self.__typeface = typeface
        self.__target = self.__typeface.render(f"{self.__clock.get_fps():.02f} Hz")[0]
    def _update_handler(self, dt: float, fresh: bool) -> None:
        self.__target = self.__typeface.render(f"{self.__clock.get_fps():.02f} Hz")[0]
    def draw(self, target: pygame.surface.Surface) -> None:
        target.blit(self.__target, (2, 5))

def player_platform_post_solve(arbiter: pymunk.Arbiter, space: pymunk.Space, data) -> None:
    player_shape, platform_shape = arbiter.shapes
    if platform_shape.collision_type != 0b10:
        player_shape, platform_shape = platform_shape, player_shape
    normal = arbiter.contact_point_set.normal
    if normal.y > 0.5 and not fequal(normal.y, 0.5, 1e-7):
        data["ground_velocity"] = platform_shape.body.velocity

class Player(Entity):
    SPEED: float = 100
    JUMP_SPEED: float = -2500
    def __init__(self, space: pymunk.Space):
        super().__init__()
        # FIXME: We need to set up our player here. The player needs to retain the physics space and needs to have
        # a dynamic body with a box shape.
        pass
        self.__data = { "ground_velocity": pymunk.Vec2d.zero() }
        space.add(self.__body, self.__body_shape)
        space.on_collision(1, 2, post_solve=player_platform_post_solve, data=self.__data)
        self.__sprite = pygame.surface.Surface((TILE_WIDTH, TILE_HEIGHT), flags=pygame.SRCALPHA)
        self.__sprite.fill(pygame.Color(255, 0, 0))
    def set_position(self, x: int, y: int) -> None:
        self.__body.position = (x - TILE_WIDTH // 2, y - TILE_HEIGHT // 2)
        self.__body.velocity = (0, 0)
    def update(self, controls: Controller, dt: float) -> None:
        # FIXME: We need to handle updates to the player here. The player is a dynamic body so we need to consider
        # that in how we implement controls and how he handle weird cases (rotation). The player must be able to move
        # left and right. They must also be able to jump (as long as they are on a platform)
        # Finally, the player should stick to moving platforms and not fall off easily.
        pass
    def draw(self, target: pygame.surface.Surface) -> None:
        rect = self.__sprite.get_rect()
        target.blit(self.__sprite, (self.__body.position.x - rect.w / 2, self.__body.position.y - rect.h / 2))

class MovingPlatform(KinematicPlatform):
    SPEED: float = 50
    def __init__(self, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__(space, x, y, width, height)
        self._body.velocity = (MovingPlatform.SPEED, 0)
    def update(self, controls: Controller, dt: float) -> None:
        # FIXME: The moving platform is a Kinematic body, so it's up to our code to make it move. We need to write
        # that code here.
        pass

pygame.init()
controls = Controller()
controls.map_action("left", (pygame.K_a, pygame.K_LEFT))
controls.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controls.map_action("jump", (pygame.K_SPACE, pygame.K_UP, pygame.K_w))
controls.map_action("reset", (pygame.K_e,))
space = pymunk.Space()
space.gravity = (0, 980)
player = Player(space)
player.set_position(WIDTH // 2, HEIGHT - TILE_HEIGHT - 1)
platforms = [ ]
platforms.append(StaticPlatform(space, WIDTH // 2, HEIGHT - TILE_HEIGHT // 2, 100 * WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, -TILE_WIDTH // 2, HEIGHT // 2, TILE_WIDTH, HEIGHT))
platforms.append(StaticPlatform(space, WIDTH + TILE_WIDTH // 2, HEIGHT // 2, TILE_WIDTH, HEIGHT))
platforms.append(StaticPlatform(space, WIDTH // 2, HEIGHT - 4 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
platforms.append(MovingPlatform(space, WIDTH // 2, HEIGHT - 8 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
platforms.append(MovingPlatform(space, WIDTH // 2 + 2 * TILE_WIDTH, HEIGHT - 16 * TILE_HEIGHT, 2 * TILE_WIDTH,
                                TILE_HEIGHT))
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
typeface = pygame.freetype.Font("nec.ttf", 16)
typeface.fgcolor = pygame.Color(255, 255, 255)
typeface.bgcolor = pygame.Color(0, 0, 0)
dt = 0
physics = PhysicsUpdateStep(space)
framerate = FramerateUpdateStep(clock, typeface)
quitting = False
space.step(1)
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        controls.update(event)
        if controls.is_action_pressed("reset"):
            player.set_position(WIDTH // 2, HEIGHT // 2)
    physics.update()
    if DEBUG:
        framerate.update()
    player.update(controls, dt)
    for platform in platforms:
        platform.update(controls, dt)
    screen.fill(pygame.Color(0, 0, 0))
    player.draw(screen)
    for platform in platforms:
        platform.draw(screen)
    if DEBUG:
        options = pymunk.pygame_util.DrawOptions(screen)
        options.flags |= pymunk.SpaceDebugDrawOptions.DRAW_COLLISION_POINTS | pymunk.SpaceDebugDrawOptions.DRAW_CONSTRAINTS
        space.debug_draw(options)
        framerate.draw(screen)
    pygame.display.update()
    dt = clock.tick() / 1000.0
    physics.tick(dt)
    framerate.tick(dt)
pygame.quit()
