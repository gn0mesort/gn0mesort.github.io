import sys
import math
import pygame
import pymunk

def fequal(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    """
    Compare two floating point values for equality with an epsilon. This is useful for finding two values that are
    almost but not exactly equal. Such situations commonly arise from floating point math and it's crucial to handle
    them.

    @type a: float
    @param a: The first value to compare.
    @type b: float
    @param b: The second value to compare.
    @type epsilon: float
    @param epsilon: A small acceptable difference between a and b. In mathematics, epsilon is usually used to represent
                    very small (often infinitely small) differences between two numbers. Here, we use it to mean that
                    two float values off by this amount are "close enough to equal". This defaults to
                    sys.float_info.epsilon, which is appropriate for comparing numbers near 0. In general, you should
                    specify your own epsilon with an appropriate value for your situation.
    @rtype: bool
    @returns: True if a and b are equal within the epsilon range. False otherwise.
    """
    abs_a = math.fabs(a)
    abs_b = math.fabs(b)
    difference = math.fabs(a - b)
    if a == b:
        return True
    elif a == 0 or b == 0 or (abs_a + abs_b < sys.float_info.min):
        return difference < (epsilon * sys.float_info.min)
    else:
        return difference / min(abs_a + abs_b, sys.float_info.max) < epsilon

class Controller:
    def __init__(self):
        self.__keymap = { }
        self.__action_states = { }
    def map_action(self, action: str, keys: tuple) -> None:
        for key in keys:
            self.__keymap[key] = action
        self.__action_states[action] = 0
    def update(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYUP or event.type == pygame.KEYDOWN:
            if event.key in self.__keymap:
                action = self.__keymap[event.key]
                if event.type == pygame.KEYUP:
                    self.__action_states[action] = 0
                else:
                    self.__action_states[action] = ((self.__action_states[action] & 1) << 1) | 1
    def is_action_pressed(self, action: str) -> bool:
        return self.__action_states[action] > 0
    def is_action_just_pressed(self, action: str) -> bool:
        return self.__action_states[action] == 1

class Entity:
    def __init__(self):
        pass
    def update(self, controls: Controller, dt: float) -> None:
        pass
    def draw(self, target: pygame.surface.Surface) -> None:
        pass

class FixedUpdateStep:
    def __init__(self, time: float):
        self.__step_time = time
        self.__acc = 0
    def _update_handler(self, dt: float, fresh: bool) -> None:
        pass
    def tick(self, dt: float) -> None:
        self.__acc = self.__acc + dt
    def update(self) -> None:
        fresh = True
        while self.__acc >= self.__step_time:
            self.__acc = self.__acc - self.__step_time
            self._update_handler(self.__step_time, fresh)
            fresh = False

def clamp(value: int|float, min: int|float, max: int|float) -> int|float:
    return min(max(value, min), max)

def lerpconst(start: int|float, end: int|float, difference: int|float) -> int|float:
    return start + clamp(end - start, -d, d)



class Platform(Entity):
    def __init__(self, body_type: int, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__()
        self._body = pymunk.Body(body_type=body_type, moment=math.inf)
        self._body.position = (x, y)
        self._body_shape = pymunk.Poly.create_box(self._body, size=(width, height))
        self._body_shape.mass = 1000
        self._body_shape.collision_type = 0b10
        self._body.moment = float("inf")
        space.add(self._body, self._body_shape)
        self._sprite = pygame.surface.Surface((width, height), flags=pygame.SRCALPHA)
        self._sprite.fill(pygame.Color(0, 255, 0))
    def draw(self, target: pygame.surface.Surface) -> None:
        rect = self._sprite.get_rect()
        target.blit(self._sprite, (self._body.position.x - rect.w / 2, self._body.position.y - rect.h / 2))

class StaticPlatform(Platform):
    def __init__(self, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__(pymunk.Body.STATIC, space, x, y, width, height)

class KinematicPlatform(Platform):
    def __init__(self, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__(pymunk.Body.KINEMATIC, space, x, y, width, height)
