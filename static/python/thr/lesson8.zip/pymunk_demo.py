import pygame
import pymunk
import pymunk.pygame_util

WIDTH = 640
HEIGHT = 480
FIXED_PHYSICS_STEP = 1 / 60

space = pymunk.Space()
space.gravity = (0, 980)
body = pymunk.Body()
body.position = (WIDTH // 2, HEIGHT // 2)
shape = pymunk.Circle(body, 16)
shape.mass = 5
floor = pymunk.Body(body_type=pymunk.Body.STATIC)
floor.position = (WIDTH // 2, HEIGHT - 16)
floor_shape = pymunk.Poly.create_box(floor, size=(10 * WIDTH, 32))
space.add(body, shape, floor, floor_shape)

pygame.init()
clock = pygame.time.Clock()
dt = 0
physics_acc = 0
screen = pygame.display.set_mode((WIDTH, HEIGHT))
quitting = False
stepping = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_e or event.key == pygame.K_RETURN:
                stepping = not stepping
            elif event.key == pygame.K_r:
                body.position = (WIDTH // 2, HEIGHT // 2)
                body.velocity = (0, 0)
                body.angle = 0
                body.angular_velocity = 0
    while physics_acc >= FIXED_PHYSICS_STEP:
        if stepping:
            space.step(FIXED_PHYSICS_STEP)
        physics_acc = physics_acc - FIXED_PHYSICS_STEP
    screen.fill(pygame.Color(255, 255, 255))
    options = pymunk.pygame_util.DrawOptions(screen)
    options.flags |= pymunk.SpaceDebugDrawOptions.DRAW_COLLISION_POINTS | pymunk.SpaceDebugDrawOptions.DRAW_CONSTRAINTS
    space.debug_draw(options)
    pygame.display.update()
    dt = clock.tick() / 1000
    physics_acc = physics_acc + dt
pygame.quit()
