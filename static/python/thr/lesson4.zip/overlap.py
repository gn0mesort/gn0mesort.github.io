import pygame

def colliderect(a: pygame.Rect, b: pygame.Rect) -> bool:
    if a.x + a.width > b.x and b.x + b.width > a.x and a.y + a.height > b.y and b.y + b.height > a.y:
        return True
    return False

a = pygame.Rect(0, 0, 16, 16)
b = pygame.Rect(8, 8, 16, 16)
c = pygame.Rect(64, 64, 16, 16)

print(f"a collides with b? PyGame: {a.colliderect(b)}, Our Version: {colliderect(a, b)}")
print(f"a collides with c? PyGame: {a.colliderect(c)}, Our Version: {colliderect(a, c)}")
print(f"a collides with b? PyGame: {b.colliderect(a)}, Our Version: {colliderect(b, a)}")
print(f"a collides with c? PyGame: {c.colliderect(a)}, Our Version: {colliderect(c, a)}")


