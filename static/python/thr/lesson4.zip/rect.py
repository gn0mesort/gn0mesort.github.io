import pygame

bounds = pygame.Rect(0, 0, 16, 16)
print(bounds)
