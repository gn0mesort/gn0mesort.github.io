from dataclasses import dataclass

import pygame

@dataclass
class PlayerData:
    x: float = 0
    y: float = 0
    speed: float = 0
    sprite: pygame.Surface = None

WIDTH = 1280
HEIGHT = 720

def create_ufo(width: int, height: int) -> PlayerData:
    ufo = PlayerData()
    ufo.sprite = pygame.image.load("ufo.webp")
    ufo.x = int(width / 2) - int(ufo.sprite.get_width() / 2)
    ufo.y = int(height / 2) - int(ufo.sprite.get_height() / 2)
    ufo.speed = 256
    return ufo

def warp(player: PlayerData) -> None:
    if int(player.x) > WIDTH + player.sprite.get_width():
        player.x = -player.sprite.get_width()
    elif int(player.x) < -player.sprite.get_width():
        player.x = WIDTH + player.sprite.get_width()
    if int(player.y) > HEIGHT + player.sprite.get_height():
        player.y = -player.sprite.get_height()
    elif int(player.y) < -player.sprite.get_height():
        player.y = HEIGHT + player.sprite.get_height()

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
quitting = False
player = create_ufo(WIDTH, HEIGHT)
visaabb = pygame.Surface((player.sprite.get_width(), player.sprite.get_height()), flags=pygame.SRCALPHA)
block = PlayerData()
block.x = int(WIDTH / 2) - (2 * player.sprite.get_width())
block.y = int(HEIGHT / 2)
block.sprite = pygame.Surface((player.sprite.get_width(), player.sprite.get_height()), flags=pygame.SRCALPHA)
block.sprite.fill(pygame.Color(255, 255, 255))
visaabb.fill(pygame.Color(0, 0, 0, 0))
bb = pygame.Rect(0, 0, player.sprite.get_width() - 1, player.sprite.get_height() - 1)
pygame.draw.lines(visaabb, pygame.Color(255, 0, 0, 255), True, (bb.topleft, bb.topright, bb.bottomright, bb.bottomleft))
delta_time = 0.0
keys = { pygame.K_w: False, pygame.K_s: False, pygame.K_a: False, pygame.K_d: False }
screen.fill((0, 0, 0))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if (event.type == pygame.KEYDOWN or event.type == pygame.KEYUP) and event.key in keys.keys():
            keys[event.key] = event.type == pygame.KEYDOWN
    x = player.x
    y = player.y
    if keys[pygame.K_w]:
        y = y - player.speed * delta_time
    elif keys[pygame.K_s]:
        y = y + player.speed * delta_time
    if keys[pygame.K_a]:
        x = x - player.speed * delta_time
    elif keys[pygame.K_d]:
        x = x + player.speed * delta_time
    aabb = block.sprite.get_rect()
    aabb.x = block.x
    aabb.y = block.y
    if not aabb.colliderect(pygame.Rect(x, y, player.sprite.get_width(), player.sprite.get_height())):
        player.x = x
        player.y = y
    warp(player)
    screen.fill((0, 0, 0))
    screen.blit(block.sprite, (block.x, block.y))
    screen.blit(visaabb, (block.x, block.y))
    screen.blit(player.sprite, (player.x, player.y, player.sprite.get_width(), player.sprite.get_height()))
    screen.blit(visaabb, (player.x, player.y))
    pygame.display.flip()
    delta_time = clock.tick() / 1000.0
pygame.quit()
