import pygame
from pathlib import Path
from dataclasses import dataclass
import math
import sys
import random

class SpriteMap:
    def __init__(self, path: Path|str, tile_extent: pygame.Rect):
        self.__spritemap = pygame.image.load(path).convert_alpha()
        self.__tile_width = tile_extent.width
        self.__tile_height = tile_extent.height
    def get(self, x, y) -> pygame.surface.Surface:
        return self.__spritemap.subsurface(pygame.Rect(self.__tile_width * x, self.__tile_height * y,
                                                       self.__tile_width, self.__tile_height))

def min(a: float|int, b: float|int) -> float|int:
    return a if a < b else b

def max(a: float|int, b: float|int) -> float|int:
    return a if a > b else b

def clamp(v: float|int, lo: float|int, hi: float|int) -> float|int:
    return min(max(v, lo), hi)

def remap(x: int|float, a: int|float, b: int|float, c: int|float, d: int|float) -> int|float:
    return c + (x - a) * (d - c) / (b - a)

def fequal(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    abs_a = math.fabs(a)
    abs_b = math.fabs(b)
    difference = math.fabs(a - b)
    if a == b:
        return True
    elif a == 0 or b == 0 or (abs_a + abs_b < sys.float_info.min):
        return difference < (epsilon * sys.float_info.min)
    else:
        return difference / min(abs_a + abs_b, sys.float_info.max) < epsilon

def flessthan(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    return a < b and not fequal(a, b, epsilon)

def fgreaterthan(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    return a > b and not fequal(a, b, epsilon)

class Level:
    def __init__(self, path: Path|str, passage: pygame.surface.Surface, wall: pygame.surface.Surface):
        surface = pygame.image.load(path)
        self.__width = surface.get_width()
        self.__height = surface.get_height()
        if (passage.get_width(), passage.get_height()) != (wall.get_width(), wall.get_height()):
            raise RuntimeError("Passage and wall tiles must have equal sizes.")
        self.__passage = passage
        self.__wall = wall
        self.__tiles = bytearray()
        self.__tiles.extend([ 0 ] * self.__width * self.__height)
        self.__surface = None
        for i in range(self.__height):
            for j in range(self.__width):
                color = surface.get_at((j, i))
                if color != pygame.Color(0, 0, 0) and color.a == 255:
                    self.__tiles[i * self.__width + j] = 1
        self.__prerender()
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def tile_width(self) -> int:
        return self.__passage.get_width()
    def tile_height(self) -> int:
        return self.__passage.get_height()
    def pixel_width(self) -> int:
        return self.__width * self.__passage.get_width()
    def pixel_height(self) -> int:
        return self.__height * self.__passage.get_height()
    def index_from_coordinates(self, x: float, y: float) -> tuple:
        x = remap(x, 0, (self.__width - 1) * self.__passage.get_width(), 0, self.__width - 1)
        y = remap(y, 0, (self.__width - 1) * self.__passage.get_height(), 0, self.__height - 1)
        return (int(x), int(y))
    def is_passable(self, bounds: pygame.Rect) -> bool:
        result = True
        # FIXME: We need to determine if a tile that the player is trying to walk to is open (passable) or closed
        # (not passable). This information is stored in he self.__tiles array, but we need to retrieve it and figure
        # out which tile we want using the player's bounding rectangle.
        return result
    def __prerender(self) -> None:
        self.__surface = pygame.surface.Surface((self.pixel_width(), self.pixel_height()), flags=pygame.SRCALPHA)
        self.__surface = self.__surface.convert_alpha()
        for i in range(self.__height):
            for j in range(self.__width):
                x = j * self.__passage.get_width()
                y = i * self.__passage.get_height()
                if self.__tiles[i * self.__width + j] != 0:
                    self.__surface.blit(self.__passage, (x, y))
                else:
                    self.__surface.blit(wall, (x, y))
    def render(self, target: pygame.surface.Surface) -> None:
        target.blit(self.__surface, (0, 0))

class Animation:
    def __init__(self, framestep: float, frames: list|tuple,
                 repeat: bool = True):
        self.__framestep = framestep
        self.__frames = frames
        self.__repeat = repeat
        self.__acc = 0
        self.__index = 0
        self.__should_stop = False
        self.__playing = False
    def get_surface(self) -> pygame.surface.Surface:
        return self.__frames[self.__index]
    def reset(self) -> None:
        self.__index = 0
        self.__acc = 0
        self.__should_stop = False
        self.__playing = False
    def play(self) -> None:
        self.__playing = True
        self.__should_stop = False
    def should_stop(self) -> None:
        self.__should_stop = True
    def update(self, dt: float) -> None:
        if not self.__playing:
            return
        self.__acc = self.__acc + dt
        while self.__acc >= self.__framestep:
            self.__acc = self.__acc - self.__framestep
            if self.__should_stop:
                self.reset()
            elif self.__index < len(self.__frames) - 1:
                self.__index = self.__index + 1
            elif self.__index == len(self.__frames) - 1 and self.__repeat:
                self.__index = 0

@dataclass
class Vector2:
    x: float = 0
    y: float = 0

@dataclass
class IntVector2:
    x: int = 0
    y: int = 0

class Actor:
    def __init__(self, base: pygame.surface.Surface):
        self.__animations = { }
        self.__current_animation = None
        self.__playing = False
        self.__screen_position = Vector2()
        self.__velocity = Vector2()
        self.__logical_position = IntVector2()
        self.__move_speed = 0
    def teleport_to(self, x: float, y: float) -> None:
        self.__logical_position.x = int(x)
        self.__logical_position.y = int(y)
        self.__screen_position.x = x
        self.__screen_position.y = y
    def position(self) -> IntVector2:
        return self.__screen_position
    def width(self) -> int:
        return self.__animations[self.__current_animation].get_surface().get_width()
    def height(self) -> int:
        return self.__animations[self.__current_animation].get_surface().get_height()
    def add_animation(self, name: str, animation: Animation) -> None:
        self.__animations[name] = animation
        if self.__current_animation is None:
            self.__current_animation = name
    def play_animation(self, name: str) -> None:
        if name != self.__current_animation:
            self.__animations[name].reset()
        self.__animations[name].play()
        self.__current_animation = name
        self.__playing = True
    def stop_animation(self) -> None:
        self.__animations[self.__current_animation].should_stop()
        self.__playing = False
    def is_animating(self) -> bool:
        return self.__playing
    def animation(self) -> str:
        return self.__current_animation
    def velocity(self) -> Vector2:
        return Vector2(self.__velocity.x, self.__velocity.y)
    def set_velocity(self, v: Vector2) -> None:
        self.__velocity = v
    def update(self, dt: float, level: Level) -> None:
        self.__animations[self.__current_animation].update(dt)
        surface = self.__animations[self.__current_animation].get_surface()
        dir_x = 0
        if self.__velocity.x < 0:
            dir_x = -1
        elif self.__velocity.x > 0:
            dir_x = 1
        dir_y = 0
        if self.__velocity.y < 0:
            dir_y = -1
        elif self.__velocity.y > 0:
            dir_y = 1
        is_equal = fequal(self.__screen_position.x, self.__logical_position.x, 1e-2)
        is_equal = is_equal and fequal(self.__screen_position.y, self.__logical_position.y, 1e-2)
        if is_equal:
            self.__screen_position.x = self.__logical_position.x
            self.__screen_position.y = self.__logical_position.y
            if dir_x != 0 or dir_y != 0:
                if dir_x < 0:
                    self.play_animation("walk_left")
                elif dir_x > 0:
                    self.play_animation("walk_right")
                elif dir_y < 0:
                    self.play_animation("walk_up")
                elif dir_y > 0:
                    self.play_animation("walk_down")
                bounds = pygame.Rect(0, 0, surface.get_width(), surface.get_height())
                bounds.x = self.__logical_position.x + dir_x * level.tile_width()
                bounds.y = self.__logical_position.y + dir_y * level.tile_height()
                if level.is_passable(bounds):
                    self.__logical_position.x = self.__logical_position.x + dir_x * level.tile_width()
                    self.__logical_position.y = self.__logical_position.y + dir_y * level.tile_height()
                    self.__move_speed = math.hypot(self.__velocity.x, self.__velocity.y)
            else:
                self.stop_animation()
        dx = self.__logical_position.x - self.__screen_position.x
        dy = self.__logical_position.y - self.__screen_position.y
        step_x = self.__velocity.x * dt
        step_y = self.__velocity.y * dt
        if math.fabs(dx) <= self.__move_speed * dt:
            self.__screen_position.x = self.__logical_position.x
        else:
            self.__screen_position.x = self.__screen_position.x + math.copysign(self.__move_speed * dt, dx)
        if math.fabs(dy) <= math.fabs(step_y):
            self.__screen_position.y = self.__logical_position.y
        else:
            self.__screen_position.y = self.__screen_position.y + math.copysign(self.__move_speed * dt, dy)
    def render(self, target: pygame.surface.Surface) -> None:
        location = (int(self.__screen_position.x), int(self.__screen_position.y))
        target.blit(self.__animations[self.__current_animation].get_surface(), location)

class Pickup:
    def __init__(self, sprite: pygame.surface.Surface, x: int, y: int):
        self.__sprite = sprite
        self.__screen_position = IntVector2(x, y)
    def get_rect(self) -> pygame.Rect:
        return pygame.Rect(self.__screen_position.x, self.__screen_position.y, self.__sprite.get_width(),
                           self.__sprite.get_height())
    def render(self, target: pygame.surface.Surface) -> None:
        target.blit(self.__sprite, (self.__screen_position.x, self.__screen_position.y))
    def collides(self, player: Actor) -> bool:
        # FIXME: We need to know when the player collides with a pickup item.
        pass

def no_pickups(pickups: list, bounds: pygame.Rect) -> bool:
    # FIXME: We need to detect if a rectangle has a treasure. That way we can avoid placing a second treasure there!
    pass

MAX_TREASURES = 10
START_X = 1
START_Y = 1

pygame.init()
pygame.display.set_mode((1, 1), pygame.HIDDEN)
floormap = SpriteMap("floor.webp", pygame.Rect(0, 0, 16, 16))
wallmap = SpriteMap("wall.webp", pygame.Rect(0, 0, 16, 16))
playermap = SpriteMap("rogue.webp", pygame.Rect(0, 0, 16, 16))
pickupmap = SpriteMap("pickups.webp", pygame.Rect(0, 0, 16, 16))
passage = floormap.get(1, 19)
wall = wallmap.get(1, 19)
level = Level("level.webp", passage, wall)
screen = pygame.display.set_mode((4 * level.pixel_width(), 4 * level.pixel_height()), pygame.SHOWN)
player = Actor(playermap.get(0, 0))
dur = 1.0 / 4.0
player_down = Animation(dur, (playermap.get(0, 0), playermap.get(1, 0), playermap.get(2, 0), playermap.get(3, 0)))
player_up = Animation(dur,  (playermap.get(0, 3), playermap.get(1, 3), playermap.get(2, 3), playermap.get(3, 3)))
player_left = Animation(dur, (playermap.get(0, 1), playermap.get(1, 1), playermap.get(2, 1), playermap.get(3, 1)))
player_right = Animation(dur, (playermap.get(0, 2), playermap.get(1, 2), playermap.get(2, 2), playermap.get(3, 2)))
player.add_animation("walk_down", player_down)
player.add_animation("walk_up", player_up)
player.add_animation("walk_left", player_left)
player.add_animation("walk_right", player_right)
player.teleport_to(START_X * level.tile_width(), START_Y * level.tile_height())
quitting = False
backbuffer = pygame.surface.Surface((level.pixel_width(), level.pixel_height()), flags=pygame.SRCALPHA).convert_alpha()
scalebuffer = pygame.surface.Surface((screen.get_width(), screen.get_height()), flags=pygame.SRCALPHA).convert_alpha()
clock = pygame.time.Clock()
dt = 0.0
pickups = [ ]
for i in range(MAX_TREASURES):
    # FIXME: We need to add treasures to the game before playing. Treasures shouldn't be placed on walls, and they
    # shouldn't overlap with each other. Otherwise, they should be put somewhere random.
    pass
controls = { pygame.K_w: False, pygame.K_a: False, pygame.K_s: False, pygame.K_d: False }
debugtype = pygame.font.Font(pygame.font.get_default_font(), 24)
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYDOWN or event.type == pygame.KEYUP:
            controls[event.key] = event.type == pygame.KEYDOWN
    if controls[pygame.K_w]:
        player.set_velocity(Vector2(0, -2 * level.tile_height()))
    if controls[pygame.K_s]:
        player.set_velocity(Vector2(0, 2 * level.tile_height()))
    if controls[pygame.K_a]:
        player.set_velocity(Vector2(-2 * level.tile_width(), 0))
    if controls[pygame.K_d]:
        player.set_velocity(Vector2(2 * level.tile_width(), 0))
    if not controls[pygame.K_w] and not controls[pygame.K_a] and not controls[pygame.K_s] and not controls[pygame.K_d]:
        player.set_velocity(Vector2())
    player.update(dt, level)
    # FIXME: We need to handle collisions with pickups, at the most basic when the player touches a pickup we need to
    # remove it from the game.
    pass
    screen.fill(pygame.Color(0, 0, 0))
    level.render(backbuffer)
    for pickup in pickups:
        pickup.render(backbuffer)
    player.render(backbuffer)
    pygame.transform.scale(backbuffer, (screen.get_width(), screen.get_height()), dest_surface=scalebuffer)
    screen.blit(scalebuffer, (0, 0))
    screen.blit(debugtype.render(f"{clock.get_fps():.02f} Hz", True, (255, 255, 255)), (0, 0))
    pygame.display.update()
    dt = clock.tick() / 1000.0
pygame.quit()
