import pygame

class Controller:
    def __init__(self):
        self.__keymap = { }
        self.__action_states = { }
    def map_action(self, action: str, keys: tuple) -> None:
        for key in keys:
            self.__keymap[key] = action
        self.__action_states[action] = 0
    def update(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYUP or event.type == pygame.KEYDOWN:
            if event.key in self.__keymap:
                action = self.__keymap[event.key]
                if event.type == pygame.KEYUP:
                    self.__action_states[action] = 0
                else:
                    self.__action_states[action] = ((self.__action_states[action] & 1) << 1) | 1
    def is_action_pressed(self, action: str) -> bool:
        return self.__action_states[action] > 0
