class DirectedVertex:
    def __init__(self, value: int):
        self.__value = value
        self.__adjacent = [ ]
    def value(self) -> int:
        return self.__value
    def connect(self, other) -> None:
        if not other in self.__adjacent and self is not other:
            self.__adjacent.append(other)
    def adjacent(self) -> tuple:
        return tuple(self.__adjacent)

head = DirectedVertex(0)
next = head
for i in range(10):
    next.connect(DirectedVertex(i))
    next = next.adjacent()[0]
head = head.adjacent()[0]
while head is not None:
    print(f"{head.value()} ", end="")
    if len(head.adjacent()) > 0:
        head = head.adjacent()[0]
        print("-> ", end="")
    else:
        head = None
print("")
