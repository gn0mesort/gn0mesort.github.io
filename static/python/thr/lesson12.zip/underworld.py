import math

import pygame
import pygame.freetype

import uur
from controller import Controller

WIDTH = 320
HEIGHT = 180
WALK_SPEED = 100
ROTATE_SPEED = 1
MAP_ALPHA = int(255 * 0.50)

class Vertex:
    # FIXME: We need to implement the entire Vertex class here. A vertex in a graph needs some way to track edges
    # to other vertices. We will also need to implement functionality to make the vertex hashable.
    pass

class RoomVertex(Vertex):
    # FIXME: We also need to implement a specialized RoomVertex class. A RoomVertex represents a single room in the
    # game world and its connections to other rooms (hallways). Each room is defined by a pygame.Rect. There needs
    # to be an easy way to find the bottom right position of the room too.
    pass

def draw_map(graph: list[RoomVertex]) -> pygame.surface.Surface:
    widest = max(graph, key=RoomVertex.right).right()
    deepest = max(graph, key=RoomVertex.bottom).bottom()
    surface = pygame.surface.Surface((widest, deepest), flags=pygame.SRCALPHA)
    surface.fill(pygame.Color(0, 0, 0, 0))
    for room in graph:
        pygame.draw.rect(surface, pygame.Color(255, 255, 255, MAP_ALPHA), room.rect())
        for adjacent in room.adjacencies():
            pygame.draw.line(surface, pygame.Color(255, 255, 255, MAP_ALPHA), room.rect().center,
                             adjacent.rect().center, width=3)
    return surface

def tiles_from_surface(surface: pygame.surface.Surface) -> list[uur.Tile]:
    floor = uur.Tile()
    floor.floor_height = 0
    floor.ceiling_height = 8
    floor.wall_north_texture_id = 0
    floor.wall_east_texture_id = 0
    floor.wall_south_texture_id = 0
    floor.wall_west_texture_id = 0
    floor.floor_texture_id = 1
    floor.ceiling_texture_id = 2
    wall = floor.copy()
    wall.floor_height = wall.ceiling_height
    tiles = [ ]
    pixels = pygame.PixelArray(surface)
    for y in range(surface.get_height()):
        for x in range(surface.get_width()):
            if pixels[x, y] > 0:
                tiles.append(floor)
            else:
                tiles.append(wall)
    pixels.close()
    return tiles

# FIXME: Finally, we need to build a graph of the world space. If we don't there won't be a map to explore.
# We need to define a list of RoomVertex objects as well as a starting RoomVertex for the player to be placed at.
# Once we've done that the program will build the game world and minimap from our graph.
pass

map = draw_map(graph)
tiles = tiles_from_surface(map)
minimap = pygame.surface.Surface(map.get_size(), flags=pygame.SRCALPHA)

pygame.init()
screen = pygame.display.set_mode((WIDTH * 4, HEIGHT * 4))
pygame.image.save(map.convert(), "map.png")
pygame.display.set_caption("Underworld")
quitting = False

world = uur.World(tiles, (minimap.get_width(), minimap.get_height()))
position = uur.Vector3(start.rect().centerx * uur.World.TILE_SIZE, 4 * uur.UNIT,
                       start.rect().centery * uur.World.TILE_SIZE)
world.teleport_player_to(position)
backbuffer = uur.RenderTarget((WIDTH, HEIGHT))
clock = pygame.time.Clock()
dt = 0.0
controller = Controller()
controller.map_action("forward", (pygame.K_w, pygame.K_UP))
controller.map_action("backward", (pygame.K_s, pygame.K_DOWN))
controller.map_action("strafel", (pygame.K_a, pygame.K_LEFT))
controller.map_action("strafer", (pygame.K_d,pygame.K_RIGHT))
controller.map_action("turnl", (pygame.K_q,))
controller.map_action("turnr", (pygame.K_e,))
controller.map_action("looku", (pygame.K_PAGEUP,))
controller.map_action("lookd", (pygame.K_PAGEDOWN,))
backbuffer.load_texture("wall.png")
backbuffer.load_texture("floor.png")
backbuffer.load_texture("ceiling.png")
typeface = pygame.freetype.Font("nec.ttf", 12)
typeface.fgcolor = pygame.Color(255, 255, 0)
typeface.bgcolor = pygame.Color(0, 0, 0, 128)
fps, _ = typeface.render(f"{clock.get_fps():.2f} Hz")
pos, _ = typeface.render("")
delta = True
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        controller.update(event)
    position = world.player().position()
    position = uur.Vector3(position.x , position.y, position.z)
    old = uur.Vector3(position.x, position.y, position.z)
    yaw = world.player().yaw()
    pitch = world.player().pitch()
    if controller.is_action_pressed("forward"):
        position.x += math.sin(yaw) * WALK_SPEED * dt
        position.z += math.cos(yaw) * WALK_SPEED * dt
        delta = True
    if controller.is_action_pressed("backward"):
        position.x -= math.sin(yaw) * WALK_SPEED * dt
        position.z -= math.cos(yaw) * WALK_SPEED * dt
        delta = True
    if controller.is_action_pressed("strafel"):
        position.x -= math.cos(yaw) * WALK_SPEED * dt
        position.z += math.sin(yaw) * WALK_SPEED * dt
        delta = True
    if controller.is_action_pressed("strafer"):
        position.x += math.cos(yaw) * WALK_SPEED * dt
        position.z -= math.sin(yaw) * WALK_SPEED * dt
        delta = True
    if controller.is_action_pressed("turnl"):
        yaw = yaw - ROTATE_SPEED * dt
        delta = True
    if controller.is_action_pressed("turnr"):
        yaw = yaw + ROTATE_SPEED * dt
        delta = True
    if controller.is_action_pressed("looku"):
        pitch = pitch + ROTATE_SPEED * dt
        delta = True
    if controller.is_action_pressed("lookd"):
        pitch = pitch - ROTATE_SPEED * dt
        delta = True
    if yaw > 2 * math.pi:
        yaw = yaw - 2 * math.pi
    if yaw < 0:
        yaw = 2 * math.pi + yaw
    if pitch > math.pi / 4:
        pitch = math.pi / 4
    if pitch < -math.pi / 4:
        pitch = -math.pi / 4
    if (position.x < uur.World.TILE_SIZE // 2 or
        position.x >= (world.width() * uur.World.TILE_SIZE) - uur.World.TILE_SIZE // 2):
        position.x = old.x
    if (position.z < uur.World.TILE_SIZE // 2 or
        position.z >= (world.height() * uur.World.TILE_SIZE) - uur.World.TILE_SIZE // 2):
        position.z = old.z
    next = world.at((int(position.x / uur.World.TILE_SIZE),
                     int(position.z / uur.World.TILE_SIZE)))
    cur = world.at((int(old.x / uur.World.TILE_SIZE),
                   int(old.z / uur.World.TILE_SIZE)))
    if next.floor_height * uur.UNIT > old.y:
        position.x = old.x
        position.z = old.z
    world.player().set_position(position)
    world.player().set_yaw(yaw)
    world.player().set_pitch(pitch)
    screen.fill(pygame.Color(0, 0, 0))
    if delta:
        backbuffer.render_world(world)
        delta = False
    backbuffer.draw(screen)
    minimap.fill(pygame.Color(0, 0, 0, 0))
    minimap.blit(map, (0, 0))
    map_x = old.x / uur.World.TILE_SIZE
    map_y = old.z / uur.World.TILE_SIZE
    pygame.draw.line(minimap, pygame.Color(255, 0, 0), (map_x, map_y), (map_x + math.sin(yaw), map_y + math.cos(yaw)))
    scaled_minimap = pygame.transform.scale_by(minimap, 2)
    screen.blit(scaled_minimap, (screen.get_width() - scaled_minimap.get_width() - 5, screen.get_height() - scaled_minimap.get_height() - 5))
    screen.blit(fps, (5, 5))
    screen.blit(pos, (5, 25))
    pygame.display.flip()
    dt  = clock.tick() / 1000.0
    fps, _ = typeface.render(f"{clock.get_fps():0.02f} Hz")
    pos, _ = typeface.render(f"x={old.x:0.02f}, y={old.y:0.02f}, z={old.z:0.02f}, yaw={(world.player().yaw() * 180.0) / math.pi:0.02f} pitch={(world.player().pitch() * 180.0) / math.pi:0.02f}")
