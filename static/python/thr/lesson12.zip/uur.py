import math

from pathlib import Path
from dataclasses import dataclass

import pygame

@dataclass
class Vector3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

@dataclass
class Vector2:
    x: float = 0.0
    y: float = 0.0

@dataclass
class IntVector2:
    x: int = 0
    y: int = 0

@dataclass
class Tile:
    floor_height: int = 0
    ceiling_height: int = 0
    slope_type: int = 0
    floor_texture_id: int = 0
    ceiling_texture_id: int = 0
    wall_north_texture_id: int = 0
    wall_east_texture_id: int = 0
    wall_south_texture_id: int = 0
    wall_west_texture_id: int = 0
    def copy(self):
        return Tile(self.floor_height, self.ceiling_height, self.slope_type, self.floor_texture_id,
                    self.ceiling_texture_id, self.wall_north_texture_id, self.wall_east_texture_id,
                    self.wall_south_texture_id, self.wall_west_texture_id)

@dataclass
class Polygon:
    vertices: tuple[Vector3] = (Vector3(), Vector3(), Vector3(), Vector3())
    texture_coordinates: tuple[Vector2] = (Vector2(), Vector2(), Vector2(), Vector2())
    texture_id: int = 0
    average_depth: float = 0

@dataclass
class ScreenVertex:
    x: float = 0.0
    y: float = 0.0
    u: float = 0.0
    v: float = 0.0
    inverse_z: float = 0.0

class Texture:
    def __init__(self, path: str|Path):
        self.__surface = pygame.image.load(path)
        self.__pixels = pygame.PixelArray(self.__surface)
    def sample(self, coords: tuple[float, float]) -> pygame.Color:
        u, v = coords
        u = clamp(u, 0.0, 1.0)
        v = clamp(v, 0.0, 1.0)
        tx = int(u * (self.__surface.get_width() - 1))
        ty = int(v * (self.__surface.get_height() - 1))
        return self.__surface.unmap_rgb(self.__pixels[tx, ty])

class Player:
    def __init__(self, position: Vector3, pitch: float = 0, yaw: float = 0):
        self.__position = position
        self.__pitch = pitch
        self.__yaw = yaw
    def position(self) -> Vector3:
        return self.__position
    def set_position(self, position: Vector3) -> None:
        self.__position = position
    def pitch(self) -> float:
        return self.__pitch
    def set_pitch(self, pitch: float) -> None:
        self.__pitch = pitch
    def yaw(self) -> float:
        return self.__yaw
    def set_yaw(self, yaw: float) -> None:
        self.__yaw = yaw

class World:
    TILE_SIZE = 64.0
    MAX_VISIBLE_TILES = 256
    def __init__(self, tiles: tuple[Tile], size: tuple[int, int]):
        width, height = size
        self.__width = width
        self.__height = height
        self.__player = Player(Vector3())
        if len(tiles) != self.__width * self.__height:
            raise RuntimeError("World size must match the number of tiles!")
        self.__tilemap = [ ]
        for tile in tiles:
            self.__tilemap.append(tile)
        self.__visited = [ False ] * (self.__width * self.__height)
    def player(self) -> Player:
        return self.__player
    def teleport_player_to(self, position: Vector3) -> None:
        self.__player.set_position(position)
    def at(self, coords: tuple[int, int]) -> Tile:
        x, y = coords
        return self.__tilemap[y * self.__width + x]
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def should_draw_wall(self, position: IntVector2, direction: int) -> bool:
        dx = (0, 0, 1, -1)
        dy = (-1, 1, 0, 0)
        nx = position.x + dx[direction]
        ny = position.y + dy[direction]
        if nx < 0 or nx >= self.__width or ny < 0 or ny >= self.__height:
            return True
        neighbor = self.at((nx, ny))
        current = self.at((position.x, position.y))
        if neighbor.floor_height >= neighbor.ceiling_height:
            return True
        return neighbor.floor_height > current.floor_height or current.floor_height > neighbor.ceiling_height

def lerp(a: float, b: float, t: float) -> float:
    return a + t * (b - a)

def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))

def dot(a: Vector3, b: Vector3) -> float:
    return a.x * b.x + a.y * b.y + a.z * b.z

def add(a: Vector3, b: Vector3) -> Vector3:
    return Vector3(a.x + b.x, a.y + b.y, a.z + b.z)

def sub(a: Vector3, b: Vector3) -> Vector3:
    return Vector3(a.x - b.x, a.y - b.y, a.z - b.z)

def scale(v: Vector3, s: float) -> Vector3:
    return Vector3(v.x * s, v.y * s, v.z * s)

def normalize(v: Vector3) -> Vector3:
    len = math.sqrt(dot(v, v))
    if len > 0:
        return scale(v, 1.0 / len)
    else:
        return Vector3(0, 0, 0)

def point_in_front(p: Vector3, normal: Vector3, distance: float) -> bool:
    return dot(p, normal) + distance >= 0

def average(iterable) -> float:
    total = 0.0
    for x in iterable:
        total += x
    return total / len(iterable)

def distance(a: tuple[int, int], b: tuple[int, int]) -> float:
    return math.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)

def distance_3d(a: Vector3, b: Vector3) -> float:
    return math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2 + (b.z - a.z) ** 2)

UNIT = 11
DRAW_DISTANCE = 3

class RenderTarget:
    NEAR_PLANE = 0.1
    FAR_PLANE = 1000.0
    FOV = 96.0
    def __init__(self, size: tuple[int, int]):
        self.__surface = pygame.surface.Surface(size)
        self.__pixels = None
        self.__textures = [ ]
    def load_texture(self, path: str|Path) -> int:
        res = len(self.__textures)
        self.__textures.append(Texture(path))
        return res
    def textures(self) -> tuple[Texture]:
        return tuple(self.__textures)
    def _project_vertex(self, world: Vector3, position: Vector3, yaw: float, pitch: float) -> ScreenVertex:
        local = sub(world, position)
        cy = math.cos(yaw)
        sy = math.sin(yaw)
        lx = local.x * cy - local.z * sy
        lz = local.x * sy + local.z * cy
        local.x = lx
        local.z = lz
        cp = math.cos(pitch)
        sp = math.sin(pitch)
        ly = local.y * cp - local.z * sp
        lz = local.y * sp + local.z * cp
        local.y = ly
        local.z = lz
        res = ScreenVertex()
        if local.z < RenderTarget.NEAR_PLANE:
            res.inverse_z = -1
            return res
        proj = (self.__surface.get_width() / 2) / math.tan(RenderTarget.FOV * math.pi / 360.0)
        res.x = self.__surface.get_width() // 2 + (local.x / local.z) * proj
        res.y = self.__surface.get_height() // 2 - (local.y / local.z) * proj
        res.inverse_z = 1.0 / local.z
        return res
    def _project_polygon(self, p: Polygon, player: Vector3, yaw: float, pitch: float) -> tuple[ScreenVertex]:
        vertices = [ ]
        for i in range(4):
            vertex = self._project_vertex(p.vertices[i], player, yaw, pitch)
            vertex.u = p.texture_coordinates[i].x * vertex.inverse_z
            vertex.v = p.texture_coordinates[i].y * vertex.inverse_z
            vertices.append(vertex)
        return tuple(vertices)
    def _get_min_y(self, vertices: list[ScreenVertex]) -> int:
        min = int(vertices[0].y)
        for i in range(1, len(vertices)):
            if vertices[i].y < min:
                min = int(vertices[i].y)
        return clamp(min, 0, self.__surface.get_height() - 1)
    def _get_max_y(self, vertices: list[ScreenVertex]) -> int:
        max = int(vertices[0].y)
        for i in range(1, len(vertices)):
            if vertices[i].y > max:
                max = int(vertices[i].y)
        return clamp(max, 0, self.__surface.get_height() - 1)
    def _interpolate_edge(self, start: ScreenVertex, end: ScreenVertex, y: int) -> ScreenVertex:
        if end.y == start.y:
            return ScreenVertex(start.x, y, start.u, start.v, start.inverse_z)
        t = (float(y) - start.y) / (end.y - start.y)
        res = ScreenVertex()
        res.x = lerp(start.x, end.x, t)
        res.u = lerp(start.u, end.u, t)
        res.v = lerp(start.v, end.v, t)
        res.inverse_z = lerp(start.inverse_z, end.inverse_z, t)
        return res
    def _find_edges(self, vertices: list[ScreenVertex], y: int) -> tuple[ScreenVertex, ScreenVertex]:
        left_x = float("inf")
        right_x = float("-inf")
        left = ScreenVertex()
        right = ScreenVertex()
        for i in range(len(vertices)):
            s = vertices[i]
            e = vertices[(i + 1) & 3]
            if (s.y <= y and y < e.y) or (e.y <= y and y < s.y):
                interpolant = self._interpolate_edge(s, e, y)
                interpolant.y = y
                if interpolant.x < left_x:
                    left = interpolant
                    left_x = left.x
                if interpolant.x > right_x:
                    right = interpolant
                    right_x = right.x
        return (left, right)
    def _rasterize(self, p: Polygon, player: Vector3, yaw: float, pitch: float) -> None:
        vertices = self._project_polygon(p, player, yaw, pitch)
        xc = sum(v.x for v in p.vertices) / len(p.vertices)
        zc = sum(v.z for v in p.vertices) / len(p.vertices)
        min_y = self._get_min_y(vertices)
        max_y = self._get_max_y(vertices)
        for vertex in vertices:
            if vertex.inverse_z <= 0:
                return
        for y in range(min_y, max_y + 1):
            left, right = self._find_edges(vertices, y)
            start_x = int(math.ceil(left.x))
            end_x = int(math.floor(right.x))
            start_x = clamp(start_x, 0, self.__surface.get_width() - 1)
            end_x = clamp(end_x, 0, self.__surface.get_width() - 1)
            span_length = right.x - left.x
            if span_length <= 0:
                continue
            for x in range(start_x, end_x + 1):
                t = (float(x) - left.x) / span_length
                inverse_z = lerp(left.inverse_z, right.inverse_z, t)
                if inverse_z <= 0:
                    continue
                u = lerp(left.u, right.u, t) / inverse_z
                v = lerp(left.v, right.v, t) / inverse_z
                col = self.__textures[p.texture_id].sample((u, v))
                d = clamp(abs(distance_3d(player, Vector3(xc, player.y, zc))), 0, DRAW_DISTANCE * World.TILE_SIZE)
                d = 1 - (d / (DRAW_DISTANCE * World.TILE_SIZE))
                r = int(clamp(col.r * d, 0, 255))
                g = int(clamp(col.g * d, 0, 255))
                b = int(clamp(col.b * d, 0, 255))
                col.update(r, g, b)
                self.__pixels[x, y] = col
    def _compute_floor_verts(self, position: IntVector2, tile: Tile) -> list[Vector3]:
        base_x = position.x * World.TILE_SIZE
        base_z = position.y * World.TILE_SIZE
        height = tile.floor_height * UNIT
        res = [ Vector3(base_x, height, base_z + World.TILE_SIZE),
                Vector3(base_x + World.TILE_SIZE, height, base_z + World.TILE_SIZE),
                Vector3(base_x + World.TILE_SIZE, height, base_z), Vector3(base_x, height, base_z) ]
        if tile.slope_type == 1:
            res[3].y += UNIT
            res[2].y += UNIT
        elif tile.slope_type == 2:
            res[0].y += UNIT
            res[1].y += UNIT
        elif tile.slope_type == 3:
            res[1].y += UNIT
            res[2].y += UNIT
        elif tile.slope_type == 4:
            res[0].y += UNIT
            res[3].y += UNIT
        return res
    def _compute_uvs(self) -> list[Vector2]:
        return [ Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0) ]
    def _compute_ceiling_verts(self, position: IntVector2, tile: Tile) -> list[Vector3]:
        vertices = self._compute_floor_verts(position, tile)
        height = tile.ceiling_height * UNIT
        for i in range(4):
            vertices[i].y = height - (vertices[i].y - tile.floor_height * UNIT)
        return vertices
    def _compute_wall_verts(self, position: IntVector2, dir: int, tile: Tile, neighbor: Tile) -> list[Vector3]:
        base_x = position.x * World.TILE_SIZE
        base_z = position.y * World.TILE_SIZE
        bottom = min(tile.floor_height, neighbor.floor_height) * UNIT
        top = max(tile.ceiling_height, neighbor.ceiling_height) * UNIT
        vertices = None
        if dir == 0:
            vertices = [ Vector3(base_x, bottom, base_z), Vector3(base_x + World.TILE_SIZE, bottom, base_z),
                         Vector3(base_x + World.TILE_SIZE, top, base_z), Vector3(base_x, top, base_z) ]
        elif dir == 1:
            vertices = [ Vector3(base_x + World.TILE_SIZE, bottom, base_z + World.TILE_SIZE),
                         Vector3(base_x, bottom, base_z + World.TILE_SIZE),
                         Vector3(base_x, top, base_z + World.TILE_SIZE),
                         Vector3(base_x + World.TILE_SIZE, top, base_z + World.TILE_SIZE) ]
        elif dir == 2:
            vertices = [ Vector3(base_x + World.TILE_SIZE, bottom, base_z + World.TILE_SIZE),
                         Vector3(base_x + World.TILE_SIZE, bottom, base_z),
                         Vector3(base_x + World.TILE_SIZE, top, base_z),
                         Vector3(base_x + World.TILE_SIZE, top, base_z + World.TILE_SIZE) ]
        elif dir == 3:
            vertices = [ Vector3(base_x, bottom, base_z), Vector3(base_x, bottom, base_z + World.TILE_SIZE),
                         Vector3(base_x, top, base_z + World.TILE_SIZE), Vector3(base_x, top, base_z) ]
        return vertices
    def _build_polygons(self, visible: list[IntVector2], world: World) -> list[Polygon]:
        res = [ ]
        for i in range(len(visible)):
            position = visible[i]
            tile = world.at((position.x, position.y))
            floor = Polygon()
            floor.vertices = self._compute_floor_verts(position, tile)
            floor.texture_coordinates = self._compute_uvs()
            floor.texture_id = tile.floor_texture_id
            floor.average_depth = sum(distance_3d(world.player().position(), v) for v in floor.vertices) / 4
            res.append(floor)
            ceiling = Polygon()
            ceiling.vertices = self._compute_ceiling_verts(position, tile)
            ceiling.texture_coordinates = self._compute_uvs()
            ceiling.texture_id = tile.ceiling_texture_id
            ceiling.average_depth = sum(distance_3d(world.player().position(), v) for v in ceiling.vertices) / 4
            res.append(ceiling)
            for dir in range(4):
                if world.should_draw_wall(position, dir):
                    dx = (0, 0, 1, -1)
                    dy = (-1, 1, 0, 0)
                    npos = IntVector2(position.x + dx[dir], position.y + dy[dir])
                    neighbor = None
                    if npos.x >= 0 and npos.x < world.width() and npos.y >= 0 and npos.y < world.height():
                        neighbor = world.at((npos.x, npos.y))
                    else:
                        neighbor = tile
                    wall = Polygon()
                    wall.vertices = self._compute_wall_verts(position, dir, tile, neighbor)
                    wall.texture_coordinates = self._compute_uvs()
                    wall.average_depth = sum(distance_3d(world.player().position(), v) for v in wall.vertices) / 4
                    if dir == 0:
                        wall.texture_id = tile.wall_north_texture_id
                    elif dir == 1:
                        wall.texture_id = tile.wall_south_texture_id
                    elif dir == 2:
                        wall.texture_id = tile.wall_east_texture_id
                    elif dir == 3:
                        wall.texture_id = tile.wall_west_texture_id
                    res.append(wall)
        return sorted(res, key=lambda polygon: polygon.average_depth, reverse=True)
    def render_world(self, world: World) -> None:
        self.__surface.fill(pygame.Color(0, 0, 0))
        self.__pixels = pygame.PixelArray(self.__surface)
        grid = world.player().position()
        grid = IntVector2(int(grid.x / World.TILE_SIZE), int(grid.z / World.TILE_SIZE))
        visible = [ ]
        for i in range(world.height()):
            for j in range(world.width()):
                if abs(distance((grid.x, grid.y), (j, i))) < DRAW_DISTANCE:
                    visible.append(IntVector2(j, i))
        polygons = self._build_polygons(visible, world)
        for polygon in polygons:
            self._rasterize(polygon, world.player().position(), world.player().yaw(), world.player().pitch())
        self.__pixels.close()
        self.__pixels = None
    def draw(self, target: pygame.surface.Surface) -> None:
        surface = pygame.transform.scale(self.__surface, target.get_size())
        target.blit(surface, (0, 0))
