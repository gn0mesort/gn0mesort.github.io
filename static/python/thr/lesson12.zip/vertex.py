class Vertex:
    def __init__(self, value: int):
        self.__value = value
        self.__adjacent = [ ]
    def value(self) -> int:
        return self.__value
    def connect(self, other) -> None:
        if not other in self.__adjacent and self is not other:
            self.__adjacent.append(other)
            other.connect(self)
    def adjacent(self) -> tuple:
        return tuple(self.__adjacent)

graph = [ ]
graph.append(Vertex(1))
graph.append(Vertex(2))
graph.append(Vertex(3))
graph[0].connect(graph[1])
graph[1].connect(graph[2])
graph[2].connect(graph[0])
