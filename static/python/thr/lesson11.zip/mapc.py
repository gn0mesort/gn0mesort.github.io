#!/usr/bin/env python3

import sys

from argparse import ArgumentParser
from pathlib import Path

import binmap
from tiled import TiledMap

def main() -> None:
    parser = ArgumentParser(description="Compiles Tiled TMX (XML) format maps to binary map files.")
    parser.add_argument("TMX", help="A TMX formatted tile map file.", type=Path)
    parser.add_argument("-o", "--output", type=Path, help="The name of an output file to write data to. The default " +
                                                          "is to replace the extension of the input file with " +
                                                          "\".binmap\".", default=None)
    args = parser.parse_args()
    input_path = args.TMX.absolute()
    output_path = input_path.with_suffix(".binmap")
    if args.output is not None:
        output_path = args.output.absolute()
    map = TiledMap(input_path)
    binmap.save_map(output_path, map)
if __name__ == "__main__":
    main()
