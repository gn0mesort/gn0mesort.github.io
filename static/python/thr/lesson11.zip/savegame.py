import sys
from pathlib import Path

MAGIC = b"SAVEGAME"

class Character:
    def __init__(self, name: str, level: int, strength: int, vitality: int, intelligence: int, spirit: int,
                 current_hp: int = None):
        self.__name = name
        self.__level = level
        self.__strength = strength
        self.__vitality = vitality
        self.__intelligence = intelligence
        self.__spirit = spirit
        self.__current_hp = self.max_hp()
        if current_hp is not None:
            self.__current_hp = current_hp
    def name(self) -> str:
        return self.__name
    def level(self) -> int:
        return self.__level
    def strength(self) -> int:
        return self.__strength
    def vitality(self) -> int:
        return self.__vitality
    def intelligence(self) -> int:
        return self.__intelligence
    def spirit(self) -> int:
        return self.__spirit
    def max_hp(self) -> int:
        return self.__level + (self.__vitality // 2) * self.__level
    def current_hp(self) -> int:
        return self.__current_hp
    def __eq__(self, rhs) -> bool:
        result = self.__name == rhs.__name
        result = result and self.__level == rhs.__level
        result = result and self.__strength == rhs.__strength
        result = result and self.__vitality == rhs.__vitality
        result = result and self.__intelligence == rhs.__intelligence
        result = result and self.__spirit == rhs.__spirit
        result = result and self.__current_hp == rhs.__current_hp
        return result

def to_u8_bytes(x: int) -> bytes:
    return (x & 0xff).to_bytes(1, byteorder=sys.byteorder)

def to_u16_bytes(x: int) -> bytes:
    return (x & 0xff_ff).to_bytes(2, byteorder=sys.byteorder)

def to_u64_bytes(x: int) -> bytes:
    return (x & 0xff_ff_ff_ff_ff_ff_ff_ff).to_bytes(8, byteorder=sys.byteorder)


def int_from_bytes(bin: bytes) -> int:
    return int.from_bytes(bin, byteorder=sys.byteorder)

def to_string_bytes(text: str) -> bytes:
    result = bytearray()
    utf = text.encode("utf-8")
    result.extend(to_u64_bytes(len(utf)))
    result.extend(utf)
    return bytes(result)

def string_from_bytes(bin: bytes) -> str:
    return bin.decode("utf-8")

def save(path: str|Path, character: Character) -> None:
    file = open(path, "wb")
    file.write(MAGIC)
    file.write(to_u16_bytes(1))
    file.write(to_string_bytes(character.name()))
    file.write(to_u8_bytes(character.level()))
    file.write(to_u8_bytes(character.strength()))
    file.write(to_u8_bytes(character.vitality()))
    file.write(to_u8_bytes(character.intelligence()))
    file.write(to_u8_bytes(character.spirit()))
    file.write(to_u16_bytes(character.current_hp()))
    file.close()

def load(path: str|Path) -> Character:
    result = None
    file = open(path, "rb")
    try:
        magic = file.read(len(MAGIC))
        if magic != MAGIC:
            raise RuntimeError(f"Invalid file. Header was {repr(magic)}, but the application expects {repr(MAGIC)}.")
        version = int_from_bytes(file.read(2))
        name_length = int_from_bytes(file.read(8))
        name = string_from_bytes(file.read(name_length))
        level = int_from_bytes(file.read(1))
        strength = int_from_bytes(file.read(1))
        vitality = int_from_bytes(file.read(1))
        intelligence = int_from_bytes(file.read(1))
        spirit = int_from_bytes(file.read(1))
        hp = int_from_bytes(file.read(2))
        result = Character(name, level, strength, vitality, intelligence, spirit, current_hp=hp)
    finally:
        file.close()
    return result

character = Character("Jeff", 12, 1, 2, 3, 4, current_hp=9)
save("jeff.savegame", character)
loaded = load("jeff.savegame")
if character != loaded:
    print("Bad load!")
else:
    print("OK!")


