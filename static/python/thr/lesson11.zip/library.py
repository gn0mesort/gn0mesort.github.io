import os
from pathlib import Path

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import pygame
del os.environ["PYGAME_HIDE_SUPPORT_PROMPT"]

class SpriteMap:
    def __init__(self, path: str|Path, size: tuple[int, int]):
        width, height = size
        if width < 1 or height < 1:
            raise RuntimeError(f"The smallest sprite size is 1x1, but the input size was {width}x{height}.")
        self.__width = int(width)
        self.__height = int(height)
        self.__surface = pygame.image.load(path)
        self.__empty = pygame.surface.Surface((self.__width, self.__height), flags=pygame.SRCALPHA)
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def size(self) -> tuple[int, int]:
        return (self.__width, self.__height)
    def convert(self, surface: pygame.surface.Surface|None = None) -> None:
        if surface is None:
            self.__surface = self.__surface.convert()
        else:
            self.__surface = self.__surface.convert(surface)
    def convert_alpha(self, surface: pygame.surface.Surface|None = None) -> None:
        if surface is None:
            self.__surface = self.__surface.convert_alpha()
        else:
            self.__surface = self.__surface.convert_alpha(surface)
    def get(self, coords: tuple[int, int]) -> pygame.surface.Surface:
        x, y = coords
        if x >= self.__width or y >= self.__height:
            return self.__empty
        return self.__surface.subsurface(pygame.Rect(x * self.__width, y * self.__height, self.__width, self.__height))

class Tile:
    FLAGS_NONE = 0x00_00
    FLAGS_SOLID = 0x00_01
    def __init__(self, coords: tuple[int, int], flags: int = 0):
        self.__coords = tuple(coords)
        self.__flags = flags
    def coords(self) -> tuple[int, int]:
        return self.__coords
    def x(self) -> int:
        return self.__coords[0]
    def y(self) -> int:
        return self.__coords[1]
    def flags(self) -> int:
        return self.__flags

class Map:
    def __init__(self, size: tuple[int, int], tiles: tuple[Tile]):
        self.__size = size
        self.__tiles = tiles
    def get(self, coords: tuple[int, int]) -> Tile:
        return self.__tiles[coords[1] * self.__size[0] + coords[0]]
    def size(self) -> tuple[int, int]:
        return self.__size

class Level:
    def __init__(self, map: Map, tilemap: SpriteMap):
        self.__map = map
        self.__tilemap = tilemap
    def get_surface(self, coords: tuple[int, int]) -> pygame.surface.Surface:
        tile = self.__map.get(coords)
        return self.__tilemap.get(tile.coords())
    def is_passable(self, coords: tuple[int, int]) -> bool:
        return (self.__map.get(coords).flags() & Tile.FLAGS_SOLID) == Tile.FLAGS_NONE
    def width(self) -> int:
        return self.__map.size()[0]
    def height(self) -> int:
        return self.__map.size()[1]
    def size(self) -> tuple[int, int]:
        return self.__map.size()
    def tile_width(self) -> int:
        return self.__tilemap.width()
    def tile_height(self) -> int:
        return self.__tilemap.height()
    def tile_size(self) -> tuple[int, int]:
        return self.__tilemap.size()
    def pixel_width(self) -> int:
        return self.width() * self.tile_width()
    def pixel_height(self) -> int:
        return self.height() * self.tile_height()
    def pixel_size(self) -> tuple[int, int]:
        return (self.pixel_width(), self.pixel_height())
