#!/usr/bin/env python3

import os
from argparse import ArgumentParser
from pathlib import Path

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import pygame
del os.environ["PYGAME_HIDE_SUPPORT_PROMPT"]

import binmap
from library import *

DEBUG = True

def main():
    parser = ArgumentParser(description="View a binary map file.")
    parser.add_argument("FILE", type=Path, help="A path to a .binmap file to load.")
    args = parser.parse_args()
    input_path = Path(args.FILE).absolute()
    pygame.init()
    screen = pygame.display.set_mode((10, 10), flags=pygame.HIDDEN)
    level = binmap.load_map(input_path)
    pygame.display.set_caption(str(input_path.relative_to(Path.cwd())))
    pygame.display.set_mode(level.pixel_size())
    quitting = False
    while not quitting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quitting = True
        if DEBUG:
            screen.fill(pygame.Color(128, 128, 128))
        else:
            screen.fill(pygame.Color(0, 0, 0))
        for i in range(level.height()):
            for j in range(level.width()):
                screen.blit(level.get_surface((j, i)), (j * level.tile_width(), i * level.tile_height()))
        pygame.display.flip()
    pygame.quit()

if __name__ == "__main__":
    main()
