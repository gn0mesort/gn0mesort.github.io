from pathlib import Path

from tiled import *

from library import *

BYTEORDER = "little"
MAP_MAGIC = b"BINMAP"
FILE_VERSION = 1

def store_u8(file, x: int) -> None:
    file.write((x & 0xff).to_bytes(1, byteorder=BYTEORDER))

def load_u8(file) -> int:
    return int.from_bytes(file.read(1), byteorder=BYTEORDER)

def store_u16(file, x: int) -> None:
    # FIXME: This needs to store a 16-bit (2 byte) integer. To do this, we need to first clear any of the higher
    # bytes using a bitmask operation. Then, we need to convert the integer to the desired number of bytes in the
    # correct order. Here the byte order is little (smallest digits first, or backward) which is slightly faster
    # on most computers.
    pass

def load_u16(file) -> int:
    # FIXME: This is where we need to reverse our 16-bit store operation, we need to read 16-bits out of the input
    # file and then we need to convert it to an integer. The byte order must match the one we used to write the file!
    # If it changes then we might get backwards numbers!
    pass

def store_u64(file, x: int) -> None:
    file.write((x & 0xff_ff_ff_ff_ff_ff_ff_ff).to_bytes(8, byteorder=BYTEORDER))

def load_u64(file) -> int:
    return int.from_bytes(file.read(8), byteorder=BYTEORDER)

def store_bytes(file, b: bytes|bytearray) -> None:
    file.write(b)

def load_bytes(file, count: int) -> bytes:
    return file.read(count)

def store_string(file, text: str) -> None:
    # FIXME: Storing a string is tricky, unlike integers. We need to store the size first and then store the actual
    # text. Before we can understand the size of a string we need to convert it to bytes. The character count is
    # not always representative of the byte count!
    pass

def load_string(file) -> str:
    # FIXME: Loading a string is the opposite of storing a string. To load a string we first need to read and
    # discover the size of the string. Then, we need to read exactly that many bytes and decode it using the
    # UTF-8 encoding.
    pass

def save_map(path: str|Path, map: TiledMap) -> None:
    file = open(path, "wb")
    try:
        store_bytes(file, MAP_MAGIC)
        store_u16(file, FILE_VERSION)
        store_u64(file, map.width())
        store_u64(file, map.height())
        store_u64(file, map.tile_width())
        store_u64(file, map.tile_height())
        store_string(file, str(map.tileset().image().path().name))
        for index in map.data():
            y = int((index - 1) / map.tileset().width())
            x = (index - 1) - (y * map.tileset().width())
            store_u8(file, x)
            store_u8(file, y)
            flags = 0
            if index in map.tileset().tiles():
                properties = map.tileset().tiles()[index]
                if "flags" in properties:
                    flags = properties["flags"]
            store_u16(file, flags)
    finally:
        file.close()

def load_map(path: str|Path) -> Level:
    # FIXME: We need to write a function to load a map. This is sort of like "un-saving" the map. We need to perform
    # the saving operations in reverse. Take care to ensure that an operation is really "reverse" as it's not always
    # obvious!
    pass
