from pathlib import Path
from xml.etree.ElementTree import ElementTree

from defusedxml.ElementTree import parse

class TiledImage:
    def __init__(self, path: str|Path, name: str):
        path = Path(path).absolute()
        self.__path = path
        self.__name = name
        self.__data = path.read_bytes()
    def path(self) -> Path:
        return self.__path
    def name(self) -> str:
        return self.__name
    def data(self) -> bytes:
        return self.__data

class TiledTileSet:
    def __init__(self, path: str|Path):
        path = Path(path).absolute()
        self.__path = path
        self.__xml = parse(path)
        root = self.__xml.getroot()
        self.__name = root.get("name")
        self.__width = int(root.get("columns"))
        self.__height = int(root.get("tilecount")) // self.__width
        self.__tile_width = int(root.get("tilewidth"))
        self.__tile_height = int(root.get("tileheight"))
        image_path = (path.parent / root.find("image").get("source").strip()).absolute()
        self.__image = TiledImage(image_path, image_path.name)
        self.__tiles = { }
        for tile in root.iterfind("tile"):
            id = int(tile.get("id"))
            self.__tiles[id] = { }
            properties = self.__tiles[id]
            for property in tile.iterfind("properties/property"):
                name = property.get("name")
                value = property.get("value")
                kind = property.get("type")
                if kind == "int":
                    properties[name] = int(value)
                elif kind == "float":
                    properties[name] = float(value)
                elif kind == "bool":
                    properties[name] = bool(value)
                else:
                    properties[name] = value
    def path(self) -> Path:
        return self.__path
    def name(self) -> str:
        return self.__name
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def tile_width(self) -> int:
        return self.__tile_width
    def tile_height(self) -> int:
        return self.__tile_height
    def image(self) -> TiledImage:
        return self.__image
    def tiles(self) -> dict:
        return self.__tiles.copy()

class TiledMap:
    def __init__(self, path: str|Path):
        path = Path(path).absolute()
        self.__path = path
        self.__xml = parse(path)
        root = self.__xml.getroot()
        self.__width = int(root.get("width"))
        self.__height = int(root.get("height"))
        self.__tile_width = int(root.get("tilewidth"))
        self.__tile_height = int(root.get("tileheight"))
        tileset_path = (path.parent / root.find("tileset").get("source").strip()).absolute()
        data = root.find("layer/data").text.split(",")
        self.__data = [ ]
        for index in data:
            self.__data.append(int(index))
        self.__data = tuple(self.__data)
        self.__tileset = TiledTileSet(tileset_path)
    def path(self) -> Path:
        return self.__path
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def tile_width(self) -> int:
        return self.__tile_width
    def tile_height(self) -> int:
        return self.__tile_height
    def data(self) -> tuple[int]:
        return self.__data
    def tileset(self) -> TiledTileSet:
        return self.__tileset

