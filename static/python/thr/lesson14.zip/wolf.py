import pygame
import pygame.freetype

from raycast import *
from controller import Controller

WIDTH = 640
HEIGHT = 480
MAX_FPS = 300

TURN_THETA = 25 * 0.08726646
MOVE_SPEED = 4

ASPECT_4_3 = 0
ASPECT_16_9 = 1

def aspect() -> int:
    if WIDTH / 16 == WIDTH // 16 and HEIGHT / 9 == HEIGHT // 9:
        return ASPECT_16_9
    if WIDTH / 4 == WIDTH // 4 and HEIGHT / 3 == HEIGHT // 3:
        return ASPECT_4_3

def create_target(ar: int) -> pygame.surface.Surface:
    width = 320
    if ar == ASPECT_16_9:
        height = 180
    else:
        height = 240
    return pygame.surface.Surface((width, height))

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
ar = aspect()
fov = 106
if ar == ASPECT_4_3:
    fov = 75
backbuffer = create_target(ar)
typeface = pygame.freetype.Font("nec.ttf", 12)
typeface.bgcolor = pygame.Color(0, 0, 0, 128)
typeface.fgcolor = pygame.Color(255, 255, 0, 255)
clock = pygame.time.Clock()
dt = 0
fps, _ = typeface.render("0000.00 Hz")
location, _ = typeface.render("x = 0, y = 0, yaw = 0")
controls = Controller()
controls.map_action("forward", (pygame.K_w, pygame.K_UP))
controls.map_action("backward", (pygame.K_s, pygame.K_DOWN))
controls.map_action("left", (pygame.K_a, pygame.K_LEFT))
controls.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controls.map_action("turnl", (pygame.K_q,))
controls.map_action("turnr", (pygame.K_e,))
ceiling = pygame.Color(56, 56, 56)
floor = pygame.Color(113, 113, 113)
if LIGHTING:
    ceiling = pygame.Color(ceiling.r // 4, ceiling.g // 4, ceiling.b // 4)
    floor = pygame.Color(floor.r // 4, floor.g // 4, floor.b // 4)
world = World(Map("e1m1.webp"), ceiling, floor, fov=fov)
textures = { }
textures[int(pygame.Color(0, 0, 170))] = world.load_texture("blue.webp")
textures[int(pygame.Color(170, 170, 170))] = world.load_texture("gray.webp")
textures[int(pygame.Color(170, 85, 0))] = world.load_texture("brown.webp")
textures[int(pygame.Color(255, 255, 85))] = world.load_texture("yellow.webp")
world.use_texture_atlas(textures)
korax_tex_id = world.load_texture("korax.webp")
korax = Object((13, 52), korax_tex_id, world_scale=(1, 1.2), vertical_offset=0.5)
world.map().add_object(korax)
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_f:
                world.player().toggle_light()
        controls.update(event)
    theta = 0
    if controls.is_action_pressed("turnl"):
        theta = -TURN_THETA
    elif controls.is_action_pressed("turnr"):
        theta = TURN_THETA
    world.player().pivot(theta * dt)
    speed = 0
    if controls.is_action_pressed("forward"):
        speed = MOVE_SPEED
    elif controls.is_action_pressed("backward"):
        speed = -MOVE_SPEED
    world.player().walk(speed * dt)
    speed = 0
    if controls.is_action_pressed("left"):
        speed = -MOVE_SPEED
    elif controls.is_action_pressed("right"):
        speed = MOVE_SPEED
    world.player().strafe(speed * dt)
    screen.fill(pygame.Color(51, 51, 51))
    world.draw(backbuffer)
    screen.blit(pygame.transform.scale(backbuffer, screen.get_size()), (0, 0))
    screen.blit(fps, (5, 5))
    screen.blit(location, (5, 15))
    pygame.display.flip()
    dt = clock.tick() / 1000
    fps, _ = typeface.render(f"{clock.get_fps():04.02f} Hz")
    location, _ = typeface.render(f"x = {world.player().position()[0]:04.02f}, y = {world.player().position()[1]:04.02f}, yaw = {degrees(world.player().yaw()):04.02f}")
