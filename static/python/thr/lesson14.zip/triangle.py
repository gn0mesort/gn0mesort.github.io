import math

from dataclasses import dataclass

import pygame

WIDTH = 640
HEIGHT = 480

@dataclass
class Vertex:
    x: int = 0
    y: int = 0
    u: float = 0.0
    v: float = 0.0
    def copy(self):
        return Vertex(x, y, u, v)

def lerp(a: float, b: float, t: float) -> float:
    return a + t * (b - a)

def clamp(v, lo, hi):
    return min(max(v, lo), hi)

def interpolate_on_edge(a: Vertex, b: Vertex, y: float) -> tuple[int, float, float]:
    if a.y == b.y:
        return (a.x, a.u, a.v)
    t = (y - a.y) / (b.y - a.y)
    x = int(lerp(a.x, b.x, t))
    u = lerp(a.u, b.u, t)
    v = lerp(a.v, b.v, t)
    return (x, u, v)

def sample_texture(texture: pygame.PixelArray, uv: tuple[float, float]) -> pygame.Color:
    u, v = uv
    u = clamp(u, 0.0, 1.0)
    v = clamp(v, 0.0, 1.0)
    tx = int(u * (texture.surface.get_width() - 1))
    ty = int(v * (texture.surface.get_height() - 1))
    return texture.surface.unmap_rgb(texture[tx, ty])

def draw_affine_scanline(target: pygame.PixelArray, texture: pygame.PixelArray, y: int,
                         left: tuple[int, float, float], right: tuple[int, float, float]) -> None:
    if right[0] < left[0]:
        tmp = right
        right = left
        left = tmp
    left_x, left_u, left_v = left
    right_x, right_u, right_v = right
    width = right_x - left_x
    if width <= 0:
        return
    du = (right_u - left_u) / width
    dv = (right_v - left_v) / width
    x = math.ceil(left_x)
    u = left_u + (x - left_x) * du
    v = left_v + (x - left_x) * dv
    while x < right_x:
        target[x, y] = target.surface.map_rgb(sample_texture(texture, (u, v)))
        x = x + 1
        u = u + du
        v = v + dv

class Triangle:
    def __init__(self, texture: pygame.surface.Surface, vertices: tuple[Vertex, Vertex, Vertex]):
        self.__texture = texture
        self.__pixels = pygame.PixelArray(self.__texture)
        self.__vertices = sorted(vertices, key=lambda vertex: vertex.y)
    def draw(self, target: pygame.surface.Surface) -> None:
        pixels = pygame.PixelArray(target)
        v0, v1, v2 = self.__vertices
        y = math.ceil(v0.y)
        while y < v1.y:
            left = interpolate_on_edge(v0, v2, y)
            right = interpolate_on_edge(v0, v1, y)
            draw_affine_scanline(pixels, self.__pixels, y, left, right)
            y = y + 1
        y = math.ceil(v1.y)
        while y < v2.y:
            left = interpolate_on_edge(v0, v2, y)
            right = interpolate_on_edge(v1, v2, y)
            draw_affine_scanline(pixels, self.__pixels, y, left, right)
            y = y + 1
        del pixels

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
triangle = Triangle(pygame.image.load("blue.webp"), (Vertex(WIDTH // 2 - WIDTH // 4, HEIGHT - 1, 0, 0), Vertex(WIDTH // 2, 0, 0.5, 1), Vertex(WIDTH // 2 + WIDTH // 4, HEIGHT - 1, 1, 0)))
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
    screen.fill(pygame.Color(51, 51, 51))
    triangle.draw(screen)
    pygame.display.flip()
pygame.quit()
