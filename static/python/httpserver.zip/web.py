import socket
import select
import datetime

CONNECT_BUFFER_COUNT = 5

def listen(port):
    """
    Create a server socket listening on the desired port.

    @type port: int
    @param port: The port to accept data on. Ideally, this should be >1024 (unprivileged).
    @rtype: socket
    @returns: A newly allocated server socket bound to any address on the system and the desired port.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("", port))
    sock.listen(CONNECT_BUFFER_COUNT)
    return sock

def close(sock):
    """
    Close a socket opened with listen().

    @type sock: socket
    @param sock: The socket to close. This must have been created using listen().
    """
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except:
        pass
    finally:
        sock.close()

def is_readable(sock, timeout = 0.4):
    """
    Check if a socket is readable.

    @type sock: socket
    @param sock: The socket to inspect.
    @type timeout: float
    @param timeout: A timeout in seconds. Numbers (0, 1] indicate a fractional number of seconds. For example, 0.001
                    indicates a timeout of 1 millisecond. Defaults to 400 milliseconds.
    @rtype: bool
    @returns: True if the socket is readable before the timeout elapses. False if the socket isn't readable in the
              desired time.
    """
    readable, _, _ = select.select([ sock ], [ ] , [ ], timeout)
    return sock in readable

def parse_request(request):
    """
    Convert an HTTP request in string form to useful data. This only inspects the method, path, and protocol fields.
    In a more complete HTTP server you would want a more thorough routine.

    @type request: str
    @param request: An HTTP request as a string.
    @rtype: tuple
    @returns: A 3-tuple of method, path, and protocol information from the request. If the request is bad in some way,
              (None, None, None) is returned.
    """
    lines = request.split("\r\n")
    if len(lines) == 0 or len(lines[0]) == 0:
        return (None, None, None)
    start_line = lines[0].split()
    if len(start_line) < 3:
        return (None, None, None)
    return (start_line[0], start_line[1], start_line[2])

def response_headers():
    headers = { }
    headers["Server"] = "httpserver.py"
    headers["Date"] = datetime.datetime.now().strftime("%a, %d %b %Y %H:%M:%S %Z")
    headers["Connection"] = "close"
    return headers
