import web

PORT = 8080
RECEIVE_CHUNK_SIZE = 1024

def receive_request(sock):
    """
    Receive an entire HTTP request as a string.

    @type sock: socket.socket
    @param sock: The socket to receive a request from
    @rtype: str
    @returns: The string representation of the incoming request.
    """
    request = bytearray()
    finished = False
    # Here we need to receive our entire HTTP request. We don't know how long
    # the request will be so we need to keep receiving until there aren't any
    # bytes left. We can check if there are more bytes to read by using
    # web.is_readable(sock). If we receive all the bytes we will get a final
    # empty receive so we need to check for that too.
    pass
    print("REQUEST:\n" + request.decode("utf-8"))
    return request.decode("utf-8")

def send_response(client, status, headers, body):
    """
    Send an HTTP response.

    @type client: socket.socket
    @param client: The client socket to send data on.
    @type status: str
    @param status: The HTTP status line. This is made up of the the HTTP version (e.g., "HTTP/1.1"), the status code
                   (e.g., "200"), and the name of the response code (e.g., "OK").
    @type headers: dict
    @param headers: A dictionary with HTTP header names as keys and their corresponding values.
    @type body: bytes|bytearray|None
    @param body: The binary representation of the response body. The body can be None if there is no body data. In
                 this case, nothing will be sent.
    """
    response = bytearray()
    # Here we need to pack up our HTTP response as bytes. We need to start with the response status line. Then, we
    # need to handle the headers, we don't know how many headers there will be so we have to be sure to process all
    # of them! Last, we need to append all of the body data. Body data comes to use as bytes already so we don't need
    # to encode it.
    pass
    print("RESPONSE:\n" + response.decode("utf-8"))
    client.send(response)

def send_bad_request(client):
    """
    Send an HTTP 400 Bad Request response.

    @type client: socket.socket
    @param client: The client socket to send the response through.
    """
    status = "HTTP/1.1 400 Bad Request"
    headers = web.response_headers()
    body = "<!DOCTYPE html><html><head><meta charset=\"utf-8\" /><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" /><title>400 - Bad Request</title></head><body><p>Bad Request</p></body></html>\r\n".encode("utf-8")
    headers["Content-Length"] = len(body)
    headers["Content-Type"] = "text/html; charset=utf-8"
    send_response(client, status, headers, body)

def send_file_not_found(method, client):
    """
    Send an HTTP 404 File Not Found response.

    @type method: str
    @param method: The HTTP method requested. If this is "HEAD", the message body is discarded.
    @type client: socket.socket
    @param client: The client socket to send the response through.
    """
    status = "HTTP/1.1 404 File Not Found"
    headers = web.response_headers()
    body = "<!DOCTYPE html><html><head><meta charset=\"utf-8\" /><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" /><title>404 - File Not Found</title></head><body><p>File Not Found</p></body></html>\r\n".encode("utf-8")
    headers["Content-Length"] = len(body)
    headers["Content-Type"] = "text/html; charset=utf-8"
    if method == "HEAD":
        body = None
    send_response(client, status, headers, body)

def send_content(method, client, content):
    """
    Send an HTTP 200 OK response with HTML content.

    @type method: str
    @param method: The HTTP method requested. If this is "HEAD", the message body is discarded.
    @type client: socket.socket
    @param client: The client socket to send the response through.
    @type content: str
    @param content: The content of the response. This should be HTML.
    """
    status = "HTTP/1.1 200 OK"
    headers = web.response_headers()
    body = content.encode("utf-8")
    headers["Content-Length"] = len(body)
    headers["Content-Type"] = "text/html; charset=utf-8"
    if method == "HEAD":
        body = None
    send_response(client, status, headers, body)

quitting = False
server = web.listen(PORT)
print("Ready on port " + str(PORT))
content = """
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>My First Web Page</title>
    </head>
    <body>
        <p>Hello, world!</p>
    </body>
</html>
"""
while not quitting:
    try:
        client, address = server.accept()
        # Implement the main functionality here. First we need to receive a request from the client socket.
        # Next, we must get the method, path, and protocol from the request. Then we need to validate the information.
        # If there are errors, we need to send the correct error response (400 for bad protocols or methods and 404
        # for paths other than "/"). Finally, we need to send content if everything is good.
        pass
    finally:
        client.close()
    print("")
