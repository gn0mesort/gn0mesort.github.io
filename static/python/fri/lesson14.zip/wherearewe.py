from pathlib import Path

def main():
    print("We are located in " + str(Path.cwd()))

if __name__ == "__main__":
    main()
