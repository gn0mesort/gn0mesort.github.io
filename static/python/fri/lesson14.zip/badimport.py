while True:
    print("PWNED")

def primes(n):
    is_prime = [ True ] * 8192
    found = 0
    current = 0
    primes = [ ]
    while found < n:
        if current < 2:
            is_prime[current] = False
        if is_prime[current]:
            primes.append(current)
            found += 1
            for i in range(current + current, len(is_prime), current):
                is_prime[i] = False
        current += 1
    return primes
