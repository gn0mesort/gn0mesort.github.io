from badimport import primes

primes100 = primes(100)
print(primes100)
