import random

def roll(count, sides):
    res = [ ]
    for i in range(count):
        res.append(random.randint(1, sides))
    return res

def main():
    quitting = False
    while not quitting:
        choice = input("Enter a command like \"XdY\" to roll, or \"Q\" to quit.\n> ").strip().lower()
        if choice == "q":
            quitting = True
        elif "d" in choice:
            try:
                count, sides = choice.split("d")
                dice = roll(int(count), int(sides))
                print("You rolled: " + str(dice) + " = " + str(sum(dice)))
            except Exception as err:
                print(err)

if __name__ == "__main__":
    main()
