def main():
    for i in range(1, 101):
        text = ""
        if i % 3 == 0:
            text += "Fizz"
        if i % 5 == 0:
            text += "Buzz"
        if len(text) == 0:
            print(i)
        else:
            print(text)

if __name__ == "__main__":
    main()
