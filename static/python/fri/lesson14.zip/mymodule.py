# mymodule.py
def hello():
    print("Hello, world!")
