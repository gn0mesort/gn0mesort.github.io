import http.server
import uuid
import json
import mimetypes
from urllib.parse import parse_qsl
from pathlib import Path

def color(c):
    return "<span style=\"color: " + c + ";\">"
def endcolor():
    return "</span>"

class Handler(http.server.BaseHTTPRequestHandler):
    def __path_parts(self):
        parts = self.path.split("?")
        hier = ""
        query = ""
        if len(parts) == 2:
            hier, query = parts
        else:
            hier = parts[0]
        return hier, query
    def __send_file(self, hier, query, headers_only=False):
        path = Path(hier).relative_to("/").absolute()
        mimetypes.init()
        if path.is_dir():
            path = path / "index.html"
        if not path.exists():
            self.send_error(404)
            return
        self.send_response(200)
        content_type, _ = mimetypes.guess_type(path)
        self.send_header("Content-Type", content_type)
        self.end_headers()
        self.flush_headers()
        if not headers_only:
            file = open(path, "rb")
            data = file.read()
            file.close()
            if content_type == "text/html":
                data = data.decode("utf-8")
                file = open("guestbook.json", "rb")
                guestbook = json.loads(file.read().decode("utf-8"))
                file.close()
                guestbook_html = [ ]
                for comment in guestbook:
                    guestbook_html.extend("<div class=\"guestbook-entry\" id=\"")
                    guestbook_html.extend(str(comment["uuid"]))
                    guestbook_html.extend("\"><p class=\"guestbook-name\"><a href=\"#")
                    guestbook_html.extend(str(comment["uuid"]))
                    guestbook_html.extend("\">")
                    guestbook_html.extend(str(comment["name"]))
                    guestbook_html.extend("</a></p><p class=\"guestbook-message\">")
                    guestbook_html.extend(str(eval(comment["color"])))
                    guestbook_html.extend(str(comment["message"]))
                    guestbook_html.extend(endcolor())
                    guestbook_html.extend("</p></div>")
                guestbook_html = "".join(guestbook_html)
                if len(guestbook_html) == 0:
                    guestbook_html = "<p>Nothing Yet!</p>"
                data = data.replace("<!--PYSI guestbook -->", "".join(guestbook_html))
                data = data.encode("utf-8")
            self.wfile.write(data)
    def do_HEAD(self):
        hier, query = self.__path_parts()
        self.__send_file(hier, query, headers_only=True)
    def do_GET(self):
        hier, query = self.__path_parts()
        if hier == "/guestbook":
            hier = "/"
        self.__send_file(hier, query)
    def do_POST(self):
        hier, query = self.__path_parts()
        if hier != "/guestbook":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length"))
        entry = { }
        for kvp in parse_qsl(self.rfile.read(length)):
            key, value = kvp
            entry[key.decode("utf-8").strip()] = value.decode("utf-8").strip()
        entry["uuid"] = uuid.uuid4().hex
        entry["color"] = "color(\"" + entry["color"] + "\")"
        entry["message"] = entry["message"]
        file = open("guestbook.json", "rb")
        guestbook = json.loads(file.read().decode("utf-8"))
        file.close()
        guestbook.append(entry)
        file = open("guestbook.json", "wb")
        file.write(json.dumps(guestbook).encode("utf-8"))
        file.close()
        self.__send_file("/", "")

def main():
    try:
        server = http.server.ThreadingHTTPServer(("", 8000), Handler)
        server.serve_forever()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
