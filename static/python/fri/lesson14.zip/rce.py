# FIXME: We need two imports for this program
# First we need to import HTTPConnection from the http.client module.
# Second we need to import the urlencode function from the urllib.parse module.
pass

HOST = "localhost"
PORT = 8000

def version(v):
    parts = [ ]
    while v > 0:
        parts.append(str(v % 10))
        v = v // 10
    return ".".join(reversed(parts))

def main():
    # FIXME: We need to write our exploit code here.
    # Most of this is about sending the correct data using HTTPConnection to the server.
    # We also need to load our payload file (payload.py) and display the resulting HTTP
    # response.
    pass

if __name__ == "__main__":
    main()
