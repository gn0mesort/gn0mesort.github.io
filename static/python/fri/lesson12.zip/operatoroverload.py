class Cat:
    def __init__(self):
        pass
    def __add__(self, other):
        if isinstance(other, Dog):
            return CatDog()
        if isinstance(other, Cat):
            return CatCat()
        raise RuntimeError("You can only add cats and dogs, obviously!")

class Dog:
    def __init__(self):
        pass
    def __add__(self, other):
        if isinstance(other, Dog):
            return DogDog()
        if isinstance(other, Cat):
            return CatDog()
        raise RuntimeError("You can only add cats and dogs, obviously!")

class CatCat:
    def __init__(self):
        pass

class CatDog:
    def __init__(self):
        pass

class DogDog:
    def __init__(self):
        pass

animals = [ Cat(), Dog() ]

print("Mad Science: ")
for first in animals:
    for second in animals:
        print(type(first).__name__ + " + " + type(second).__name__ + " = " + type(first + second).__name__)
