class Matrix:
    def __init__(self, size):
        self.__width = size[0]
        self.__height = size[1]
        self.__data = [ ]
        for i in range(self.__width * self.__height):
            self.__data.append(None)
    def width(self):
        return self.__width
    def height(self):
        return self.__height
    def size(self):
        return (self.__width, self.__height)
    def get(self, coords):
        x, y = coords
        return self.__data[y * self.__width + x]
    def set(self, coords, value):
        x, y = coords
        self.__data[y * self.__width + x] = value

matrix = Matrix((4, 4))
for i in range(matrix.height()):
    for j in range(matrix.width()):
        matrix.set((j, i), 0)
matrix.set((0, 0), 1)
matrix.set((1, 1), 1)
matrix.set((2, 2), 1)
matrix.set((3, 3), 1)
for i in range(matrix.height()):
    for j in range(matrix.width()):
        print(str(matrix.get((j, i))) + " ", end="")
    print("")
