class Foo:
    def __init__(self):
        self.__data = { }
    def data(self):
        return self.__data
