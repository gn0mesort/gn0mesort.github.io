class Object:
    def __init__(self):
        pass
    def method(self):
        pass
