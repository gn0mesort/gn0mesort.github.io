import math

class Rectangle:
    def __init__(self, base, height):
        self.__base = base
        self.__height = height
    def area(self):
        return self.__base * self.__height

class Circle:
    def __init__(self, radius):
        self.__radius = radius
    def area(self):
        return self.__radius * self.__radius * math.pi

class Triangle:
    def __init__(self, base, height):
        self.__base = base
        self.__height = height
    def area(self):
        return self.__base * self.__height / 2

rectangle = Rectangle(5, 10)
circle = Circle(5)
triangle = Triangle(7, 10)

for shape in (rectangle, circle, triangle):
    print(shape.area())
