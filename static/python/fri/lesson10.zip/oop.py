class Car:
    def __init__(self, make, model, year):
        self.__make = make
        self.__model = model
        self.__year = year
    def make(self):
        return self.__make
    def model(self):
        return self.__model
    def year(self):
        return self.__year

camry = Car("Toyota", "Camry", 1998)
taurus = Car("Ford", "Taurus", 2013)
europa_s = Car("Lotus", "Europa S", 2010)

for car in (camry, taurus, europa_s):
    print("Car: " + str(car.year()) + " " + car.make() + " " + car.model())
