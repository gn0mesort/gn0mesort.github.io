COLOR_WHITE = 0
COLOR_BLACK = 1

PIECE_PAWN = 0
PIECE_ROOK = 1
PIECE_KNIGHT = 2
PIECE_BISHOP = 3
PIECE_QUEEN = 4
PIECE_KING = 5

class Piece:
    # FIXME: It's our job to implement the chess piece object here. A chess piece has a kind (pawn, knight, etc.) and
    # a color. We need to be able to retrieve this information and also convert the piece to a string.
    pass

class Board:
    BOARD_WIDTH = 8
    BOARD_HEIGHT = 8
    @staticmethod
    def algebraic_to_coords(algebraic):
        column, row = algebraic
        row = int(row) - 1
        column = ord(column.lower()) - ord("a")
        return (column, row)
    @staticmethod
    def index(algebraic):
        x, y = Board.algebraic_to_coords(algebraic)
        return y * Board.BOARD_WIDTH + x
    def __init__(self):
        self.__board = [ 0 ] * (Board.BOARD_WIDTH * Board.BOARD_HEIGHT)
        for i in range(len(self.__board)):
            self.__board[i] = None
        for i in range(Board.BOARD_WIDTH):
            column = chr(ord("a") + i)
            self.__board[Board.index((column, 2))] = Piece(PIECE_PAWN, COLOR_WHITE)
            self.__board[Board.index((column, 7))] = Piece(PIECE_PAWN, COLOR_BLACK)
        self.__board[Board.index(("a", 1))] = Piece(PIECE_ROOK, COLOR_WHITE)
        self.__board[Board.index(("a", 8))] = Piece(PIECE_ROOK, COLOR_BLACK)
        self.__board[Board.index(("h", 1))] = Piece(PIECE_ROOK, COLOR_WHITE)
        self.__board[Board.index(("h", 8))] = Piece(PIECE_ROOK, COLOR_BLACK)
        self.__board[Board.index(("b", 1))] = Piece(PIECE_KNIGHT, COLOR_WHITE)
        self.__board[Board.index(("b", 8))] = Piece(PIECE_KNIGHT, COLOR_BLACK)
        self.__board[Board.index(("g", 1))] = Piece(PIECE_KNIGHT, COLOR_WHITE)
        self.__board[Board.index(("g", 8))] = Piece(PIECE_KNIGHT, COLOR_BLACK)
        self.__board[Board.index(("c", 1))] = Piece(PIECE_BISHOP, COLOR_WHITE)
        self.__board[Board.index(("c", 8))] = Piece(PIECE_BISHOP, COLOR_BLACK)
        self.__board[Board.index(("f", 1))] = Piece(PIECE_BISHOP, COLOR_WHITE)
        self.__board[Board.index(("f", 8))] = Piece(PIECE_BISHOP, COLOR_BLACK)
        self.__board[Board.index(("e", 1))] = Piece(PIECE_KING, COLOR_WHITE)
        self.__board[Board.index(("e", 8))] = Piece(PIECE_KING, COLOR_BLACK)
        self.__board[Board.index(("d", 1))] = Piece(PIECE_QUEEN, COLOR_WHITE)
        self.__board[Board.index(("d", 8))] = Piece(PIECE_QUEEN, COLOR_BLACK)
    def at(self, algebraic):
        return self.__board[Board.index(algebraic)]
    def move(self, src, dst):
        src = Board.index(src)
        piece = self.__board[src]
        self.__board[src] = None
        dst = Board.index(dst)
        self.__board[dst] = piece
    def print(self):
        print("   a  b  c  d  e  f  g  h ")
        for i in range(Board.BOARD_HEIGHT - 1, -1, -1):
            print(str(i + 1) + " ", end="")
            for j in range(Board().BOARD_WIDTH):
                bgcolor = "\x1b[40m"
                if i % 2 == 0:
                    if j % 2 == 0:
                        bgcolor = "\x1b[47m"
                else:
                    if j % 2 != 0:
                        bgcolor = "\x1b[47m"
                piece = self.__board[i * Board.BOARD_WIDTH + j]
                if piece is None:
                    piece = " "
                else:
                    piece = str(piece)
                print(bgcolor + " " + piece + " \x1b[0m", end="")
            print("")

board = Board()
quitting = False
turn = COLOR_WHITE
while not quitting:
    print("CHESS")
    board.print()
    if turn == COLOR_WHITE:
        print("WHITE'S TURN")
    else:
        print("BLACK'S TURN")
    src = input("From: ").strip().lower()
    if len(src) != 2 or src[0] not in "abcdefgh" or src[1] not in "12345678":
        print("BAD INPUT")
        continue
    src = (src[0], int(src[1]))
    piece = board.at(src)
    if piece is None:
        print("EMPTY SPACE")
        continue
    if piece.color() != turn:
        print("NOT YOUR PIECE")
        continue
    dst = input("To: ").strip().lower()
    if len(dst) != 2 or dst[0] not in "abcdefgh" or dst[1] not in "12345678":
        print("BAD INPUT")
        continue
    dst = (dst[0], int(dst[1]))
    piece = board.at(dst)
    if piece is not None and piece.color() == turn:
        print("SPACE OCCUPIED")
        continue
    board.move(src, dst)
    turn = (turn + 1) % 2
