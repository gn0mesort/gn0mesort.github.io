class Tile:
    def __init__(self):
        self.__red = True
    def print(self):
        if self.__red:
            print("\x1b[41m  \x1b[0m")
        else:
            print("\x1b[44m  \x1b[0m")
    def flip(self):
        self.__red = not self.__red


tile = Tile()
tile.print()
tile.flip()
tile.print()
