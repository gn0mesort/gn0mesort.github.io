class Object:
    def __init__(self, foo, bar):
        self.__foo = foo
        self.bar = bar
    def foobar(self):
        return self.__foo + self.bar

obj = Object(10, 20)
print(obj.bar)
# print(obj.__foo)
print(obj.foobar())
