import math

def area(shape):
    if "radius" in shape:
        return shape["radius"] * shape["radius"] * math.pi
    else:
        return shape["base"] * shape["height"]

rectangle = { "base": 5, "height": 10 }
circle = { "radius": 5 }
triangle = { "base": 7, "height": 10 }

for shape in (rectangle, circle, triangle):
    print(area(shape))
