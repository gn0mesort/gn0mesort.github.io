from pathlib import Path

import random
import os

def generate_key(length):
    # FIXME: We must generate length many random bytes for our key. Otherwise the encryption will not work!
    pass

def file_len(file):
    # FIXME: We need some way to get the length of a file. The safest way to do this is to jump to the end of the file
    # that we're reading and examine how many bytes we are from the beginning. However, most operating systems have
    # better methods for this.
    pass

def otp(key, text):
    # FIXME: The "one time pad" algorithm is simple we will XOR one entire byte of key with one entire byte of text.
    pass

def write_all_bytes(path, data):
    # FIXME: This is a simple function. We must write all the bytes in data to a file at path.
    pass

def memclear(dst):
    # FIXME: This is another simple function. We must clear all the data in dst. Each byte of dst must become 0!
    pass

def encrypt_a_file():
    # FIXME: We need to encrypt a file here. To encrypt a file we need to know where it is in the file system (path)
    # as well as a key. Then we need to encrypt the entire file and write it back to the disk as bytes!
    pass

def decrypt_a_file():
    # FIXME: Decryption works a lot like encryption except that you need to read the key from a file and then
    # decrypt using that rather than generating the key.
    pass

quitting = False
while not quitting:
    print("One Time Pad Encryption")
    print("0. Quit")
    print("1. Encrypt a file")
    print("2. Decrypt a file")
    choice = int(input("> "))
    if choice == 0:
        quitting = True
    elif choice == 1:
        encrypt_a_file()
    elif choice == 2:
        decrypt_a_file()
