b = bytes((0, 1, 2, 4, 8, 16, 32, 64, 128, 255))
for byte in b:
    print(byte)
print("")
b = b"\x00\x01\x02\x04\x08\x10\x20\x40\x80\xff"
for byte in b:
    print(byte)
