import random

data = bytearray()
for i in range(10):
    data.append(random.randint(0, 255))
print(data)
print("")
for byte in data:
    print(byte)
