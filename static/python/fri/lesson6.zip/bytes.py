import sys
import math

x = int(input("Enter a number: "))
byte_count = math.ceil(x.bit_length() / 8)
binary = x.to_bytes(byte_count, byteorder=sys.byteorder)
print("Python bytes() representation: " + str(binary))
print("Binary Number: " + format(x, "b"))
