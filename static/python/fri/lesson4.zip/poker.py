import random

CARD_VALUES = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13)
CARD_NAMES = ("Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King")
CARD_SUITS = ("\u2665", "\u2660", "\u2666", "\u2663")

def create_deck():
    deck = [ ]
    for suit in CARD_SUITS:
        for value in CARD_VALUES:
            deck.append((suit, value))
    return deck

def shuffle_deck(deck):
    random.shuffle(deck)

def draw_hand(deck, count):
    hand = [ ]
    for i in range(count):
        hand.append(deck.pop())
    return hand

def card_value(card):
    return card[1]

def is_flush(hand):
    # FIXME: We need to detect a flush, that's a hand where all the cards have the same suit.
    pass

def is_straight(hand):
    # FIXME: We need to detect a straight, that's a hand where all of the cards are in ascending order.
    pass

def is_royal(hand):
    # FIXME: We need to detect if a hand is royal, that's if all the cards are 10 or higher.
    pass

def is_royal_flush(hand):
    return is_flush(hand) and is_straight(hand) and is_royal(hand)

def is_straight_flush(hand):
    return is_straight(hand) and is_flush(hand)

def card_groups(hand):
    # FIXME: We need to group cards so that we can detect two, three, or four of a kind.
    pass

def is_four_of_a_kind(hand):
    # FIXME: We need to figure out if a hand has four of the same value in it.
    pass

def is_full_house(hand):
    # FIXME: We need to detect a full house, which is a hand with three of a kind and a pair. We need to see exactly
    # one pair and one three of a kind.
    pass

def is_three_of_a_kind(hand):
    groups = card_groups(hand)
    for group in groups:
        if len(group) == 3:
            return True
    return False

def is_two_pair(hand):
    groups = card_groups(hand)
    pairs = 0
    for group in groups:
        if len(group) == 2:
            pairs = pairs + 1
    return pairs == 2

def is_jacks_or_better(hand):
    groups = card_groups(hand)
    return len(groups[10]) == 2 or len(groups[11]) == 2 or len(groups[12]) == 2 or len(groups[0]) == 2

def print_card(card):
    if card[1] == 1 or card[1] > 10:
        print(card[0] + CARD_NAMES[card[1] - 1] + " ", end="")
    else:
        print(card[0] + str(card[1]) + " ", end="")


bank = 100
bet = 0
quitting = False
while not quitting:
    print("POKER")
    print("YOUR HAND IS:")
    deck = create_deck()
    shuffle_deck(deck)
    hand = draw_hand(deck, 5)
    for card in hand:
        print_card(card)
    print("")
    print("You have $" + str(bank))
    choice = int(input("Bet? "))
    if choice > 0 and choice <= bank:
        bet = choice
        bank = bank - bet
    else:
        continue
    # FIXME: This game is 5 card draw poker, so we need to implement the discard phase here. The player is allowed to
    # discard up to 5 cards and draw new ones. We need to display a menu to he player and accept input to determine
    # the player's choice. Then we need to discard the correct card.
    pass
    if len(hand) < 5:
        newcards = draw_hand(deck, 5 - len(hand))
        hand.extend(newcards)
    print("YOUR HAND IS:")
    for card in hand:
        print_card(card)
    print("")
    print("You have $" + str(bank))
    print("Your bet is $" + str(bet))
    if is_royal_flush(hand):
        print("ROYAL FLUSH")
        bank = bank + bet * 800
    elif is_straight_flush(hand):
        print("STRAIGHT FLUSH")
        bank = bank + bet * 50
    elif is_four_of_a_kind(hand):
        print("FOUR OF A KIND")
        bank = bank + bet * 25
    elif is_full_house(hand):
        print("FULL HOUSE")
        bank = bank + bet * 9
    elif is_flush(hand):
        print("FLUSH")
        bank = bank + bet * 6
    elif is_straight(hand):
        print("STRAIGHT")
        bank = bank + bet * 4
    elif is_three_of_a_kind(hand):
        print("THREE OF A KIND")
        bank = bank + bet * 3
    elif is_two_pair(hand):
        print("TWO PAIR")
        bank = bank + bet * 2
    elif is_jacks_or_better(hand):
        print("JACKS OR BETTER")
        bank = bank + bet
    else:
        print("YOU LOSE")
        bet = 0
    if bank < 1:
        print("BANKRUPT")
        quitting = True

