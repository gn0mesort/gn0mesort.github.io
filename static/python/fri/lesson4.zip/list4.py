data = [ 0, 1, 2, 3 ]
data.extend((5, 6, 7, 8, 9))
print(data)
