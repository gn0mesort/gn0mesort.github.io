data = [ 2, 3, 4, 5, 6 ]
for i in data:
    # Simple way to check if a number is even.
    # There are many better ways
    if int(i / 2) == i / 2:
        data.remove(i)
print(data)
