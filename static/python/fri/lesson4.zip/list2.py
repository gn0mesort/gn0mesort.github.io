# An empty list
data = [ ]

for i in range(10):
    data.append(i * i)
print(data)
