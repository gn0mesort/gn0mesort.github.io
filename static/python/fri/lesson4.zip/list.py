data = [ 0, 0, 0, 0 ]

for i in data:
    print(i)
data[1] = 17
for i in data:
    print(i)
