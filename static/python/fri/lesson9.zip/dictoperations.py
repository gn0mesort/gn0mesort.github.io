data = { }
data["name"] = "Stanley"
data["age"] = 209
data["income"] = 2000.42
data["alive"] = True
print(data)

data["alive"] = False
print(data)

if "income" in data:
    del data["income"]
print(data)
