from datetime import datetime, timedelta
from pathlib import Path
import time

SECONDS = 1
MINUTES = 60
HOURS = 3600

def set_cookie(jar, key, value, expires = 5 * SECONDS):
    # FIXME: We need to be able to create a new cookie in our jar. This requires figuring out when the cookie should
    # expire (the current time plus the amount of time for it to expire) and structuring our data properly!
    pass

def get_cookie(jar, key):
    return jar[key]["value"]

def get_expires(jar, key):
    return jar[key]["expires"]

def delete_cookie(jar, key):
    del jar[key]

def is_expired(jar, key):
    return jar[key]["expires"] < datetime.now()

def delete_expired_cookies(jar):
    # FIXME: We must be able to delete cookies that have expired. To do this we have to iterate through our dict
    # very carefully!
    pass

def print_cookie(jar, key):
    print("[" + str(key) + "] = " + str(get_cookie(jar, key)) + " (expires at " + str(get_expires(jar, key)) + ")")

def load_jar(jar, path):
    # FIXME: This function should load all of the cookies out of a file. We have to pay special attention to the format
    # each cookie is stored on a single line with all of its data separated by commas.
    pass

def save_jar(jar, path):
    # FIXME: This function is the opposite of loading. We have to be careful to store our cookies in the correct format
    # too!
    pass

def list_cookies(jar):
    for key in jar:
        print_cookie(jar, key)

jar = { }
load_jar(jar, Path("cookiejar.dat"))
quitting = False
duration = 1 * MINUTES
while not quitting:
    print("Cookie Jar")
    delete_expired_cookies(jar)
    print("Current Duration: " + str(duration) + " seconds")
    print("0. Quit")
    print("1. Set Cookie")
    print("2. Delete Cookie")
    print("3. List Cookies")
    print("4. Set Duration")
    choice = int(input("> "))
    if choice == 0:
        quitting = True
    elif choice == 1:
        # FIXME: We need to be able to set a cookie. To do this, we can use the set_cookie function, but we need to
        # collect some inputs first!
        pass
    elif choice == 2:
        # FIXME: We need to be able to delete our cookies too! Before we delete a cookie, we need to be sure that it
        # exists to begin with!
        pass
    elif choice == 3:
        list_cookies(jar)
    elif choice == 4:
        units = { "seconds": SECONDS, "minutes": MINUTES, "hours": HOURS }
        unit = input("Choose a unit (seconds, minutes, or hours): ").lower().strip()
        if unit in units:
            count = int(input("How many " + unit + ": "))
            duration = count * units[unit]
        else:
            print("The unit " + unit + " isn't recognized.")
    else:
        print("Invalid option.")
save_jar(jar, Path("cookiejar.dat"))
