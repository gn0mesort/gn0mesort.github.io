info = { "temp": 75.2, "weather": "partly cloudy" }

for key in info:
    print(str(key) + " -> " + str(info[key]))

keys = set(info.keys())
for key in keys:
    if key != "vanilla":
        del info[key]
print(info)
