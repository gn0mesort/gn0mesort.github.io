import socketserver
import select
import math
import socket
import sys
import time
import datetime
import os

PORT = 2504

class Color:
    """
    A class representing a single RGB color.
    """
    def __init__(self, r: int, g: int, b: int):
        """
        Construct a color from red, green, and blue channels. Channels will be mod 256.

        @type r: int
        @param r: The red channel.
        @type g: int
        @param g: The green channel.
        @type b: int
        @param b: The blue channel.
        """
        self.__r = r & 0xff
        self.__g = g & 0xff
        self.__b = b & 0xff
    def red(self) -> int:
        """
        Retrieve the color's red channel.

        @rtype: int
        @returns: The red channel intensity.
        """
        return self.__r
    def green(self) -> int:
        """
        Retrieve the color's green channel.

        @rtype: int
        @returns: The green channel intensity.
        """
        return self.__g
    def blue(self) -> int:
        """
        Retrieve the color's blue channel.

        @rtype: int
        @returns: The blue channel intensity.
        """
        return self.__b

class User:
    """
    A class representing a client user.
    """
    def __init__(self, name: str, color: Color|None = None):
        """
        Construct a new client user.

        @type name: str
        @param name: A unique name for the new user.
        @type color: Color|None
        @param color: The user's message color. If this is None, the color will be the default. Defaults to None.
        """
        self.__socket = socket
        self.__name = name
        self.__color = color
    def name(self) -> str:
        """
        Retrieve the User's name.

        @rtype: str
        @returns: The User's name string.
        """
        return self.__name
    def rename(self, name: str) -> None:
        """
        Rename the User.

        @type name: str
        @param name: The new name for the User.
        """
        self.__name = name
    def color(self) -> Color|None:
        """
        Retrieve the User's message color.

        @rtype: Color|None
        @returns: The User's current message color or None if no color is set.
        """
        return self.__color
    def change_color(self, color: Color|None) -> None:
        """
        Change the User's message color.

        @type color: Color|None
        @param color: The new message color, or None to unset the color.
        """
        self.__color = color

def log(message: str, sinks: tuple = (sys.stdout)) -> None:
    """
    Log a message to multiple sinks via print().

    @type message: str
    @param message: The message to be logged.
    @type sinks: tuple
    @param sinks: A tuple of file-like objects to log to. Defaults to sys.stdout.
    """
    now = datetime.datetime.now()
    for sink in sinks:
        print(f"[{now.strftime('%c')}] {message}", file=sink)

def flushlogs(sinks: tuple = (sys.stdout)) -> None:
    """
    Manually flush all sink logs.

    @type sinks: tuple
    @param sinks: A tuple of file-like objects to log to. Defaults to sys.stdout.
    """
    for sink in sinks:
        sink.flush()

class ChatServer:
    """
    A class representing the server-side operations of a chat application.
    """
    def __init__(self):
        """
        Construct a new ChatServer and begin listening on PORT.
        """
        if socket.has_dualstack_ipv6():
            self.__server = socket.create_server(("", PORT), family=socket.AF_INET6, dualstack_ipv6=True)
        else:
            self.__server = socket.create_server(("", PORT))
        self.__server.setblocking(False)
        self.__clients = { }
        self.__users = { }
        self.__next_user = 0
        now = datetime.datetime.now()
        self.__logfile = open(f"chatserver.{os.getpid()}.{now.strftime('%c').replace(' ', '.').replace(':', '.')}.log", "w")
        host, port = socket.getnameinfo(self.__server.getsockname(), socket.NI_NUMERICHOST | socket.NI_NUMERICSERV)
        log(f"Listening on {host}:{port}.", sinks=(self.__logfile, sys.stderr))
    def __is_name_valid(self, name: str) -> bool:
        """
        Determine if a name is in use or not.

        @type name: str
        @param name: The name to check.
        @rtype: bool
        @returns: True if the name is available. False if the name is in use or reserved.
        """
        if name == "server":
            return False
        for user in self.__users.values():
            if name == user.name():
                return False
            return True
    def __send_client_message(self, client: socket.socket, message: str, author: User|None = None) -> None:
        """
        Send a message to chat client.

        @type client: socket.socket
        @param client: The client socket to message.
        @type message: str
        @param message: The message to send to the client.
        @type author: User|None
        @param author: The User who sent the message or None for server messages.
        """
        buffer = bytearray("MEGATECH\r\n".encode("ascii"))
        buffer.extend(int(time.time()).to_bytes(8, byteorder="big"))
        if author is None or author.color() is None:
            buffer.extend(int(0).to_bytes(1, byteorder="big"))
            buffer.extend(b"\x00\x00\x00")
        else:
            buffer.extend(int(1).to_bytes(1, byteorder="big"))
            color = author.color().red() << 16
            color |= author.color().green() << 8
            color |= author.color().blue()
            buffer.extend(color.to_bytes(3, byteorder="big"))
        name = "server"
        if author is not None:
            name = author.name()
        name = name.encode("utf-8")
        buffer.extend(len(name).to_bytes(8, byteorder="big"))
        buffer.extend(name)
        message = message.encode("utf-8")
        buffer.extend(len(message).to_bytes(8, byteorder="big"))
        buffer.extend(message)
        client.send(buffer)
    def __broadcast_client_message(self, message: str, author: User|None = None) -> None:
        """
        Broadcast a message to all connected clients.

        @type message: str
        @param message: The message to send.
        @type author: User|None
        @param author: The message's author or None for server messages.
        """
        for client in self.__clients.values():
            self.__send_client_message(client, message, author=author)
    def close(self) -> None:
        """
        Close the server connection.
        """
        if self.__server is not None:
            for addr in self.__clients:
                try:
                    self.__clients[addr].shutdown(socket.SHUT_RDWR)
                    self.__clients[addr].close()
                except:
                    pass
            self.__server.shutdown(socket.SHUT_RDWR)
            self.__server.close()
            log(f"Closing server.", sinks=(self.__logfile, sys.stderr))
            self.__logfile.close()
            self.__server = None
    def drain_new_connections(self) -> None:
        """
        Accept all new connections available to the server.
        """
        readable, _, _ = select.select([ self.__server ], [ ], [ ], 0)
        while self.__server in readable:
            host = None
            port = 0
            addr = None
            try:
                client, addr = self.__server.accept()
                client.setblocking(False)
                self.__clients[addr] = client
                self.__users[addr] = User(f"Guest {self.__next_user + 1}")
                self.__next_user += 1
                host, port = socket.getnameinfo(addr, socket.NI_NUMERICHOST | socket.NI_NUMERICSERV)
                log(f"Client connected on {host}:{port} as {self.__users[addr].name()}", sinks=(self.__logfile, sys.stderr))
                self.__broadcast_client_message(f"{self.__users[addr].name()} ({host}) has connected.")
            except Exception as error:
                log(f"ERROR: \"{error}\" while processing connection from {host}:{port}.", sinks=(self.__logfile, sys.stderr))
                if addr in self.__clients:
                    del self.__clients[addr]
                if addr in self.__users:
                    del self.__users[addr]
            readable, _, _ = select.select([ self.__server ], [ ], [ ], 0)
        flushlogs((sys.stderr, self.__logfile))
    def drain_new_messages(self) -> None:
        """
        Handle all new messages to the server.
        """
        readable, _, _ = select.select(self.__clients.values(), [ ], [ ], 0)
        for client in readable:
            try:
                magic = client.recv(10).decode("ascii")
                if len(magic) < 1:
                    addr = None
                    host = None
                    port = 0
                    try:
                        addr = client.getpeername()
                        host, port = socket.getnameinfo(addr, socket.NI_NUMERICHOST | socket.NI_NUMERICSERV)
                        log(f"Client {host}:{port} known as {self.__users[addr].name()} disconnected.", sinks=(self.__logfile, sys.stderr))
                    except:
                        pass
                    finally:
                        client.close()
                    if addr in self.__clients:
                        del self.__clients[addr]
                    if addr in self.__users and host is not None:
                        self.__broadcast_client_message(f"{self.__users[addr].name()} ({host}) has disconnected.")
                    if addr in self.__users:
                        del self.__users[addr]
                    continue
                if magic != "MEGATECH\r\n":
                    raise RuntimeError(f"Invalid message. Expected \"MEGATECH\\r\\n\", but got \"{magic}\". Is your client bad?")
                message_type = int.from_bytes(client.recv(1), byteorder="big")
                # The user sent a message.
                if message_type == 0:
                    message_size = int.from_bytes(client.recv(8), byteorder="big")
                    message = client.recv(message_size).decode("utf-8").strip()
                    log(f"MESSAGE: {self.__users[client.getpeername()].name()}: {message}", sinks=(self.__logfile, sys.stderr))
                    # Broadcast the message to all connected clients.
                    self.__broadcast_client_message(message, author=self.__users[client.getpeername()])
                # The user is requesting a rename.
                elif message_type == 1:
                    name_size = int.from_bytes(client.recv(8), byteorder="big")
                    name = client.recv(name_size).decode("utf-8")
                    log(f"RENAME: {self.__users[client.getpeername()].name()} to {name}", sinks=(self.__logfile, sys.stderr))
                    if self.__is_name_valid(name):
                        old = self.__users[client.getpeername()].name()
                        self.__users[client.getpeername()].rename(name)
                        log(f"RENAME: {old} is now {self.__users[client.getpeername()].name()}", sinks=(self.__logfile, sys.stderr))
                        self.__broadcast_client_message(f"{old} is now known as {name}.")
                    else:
                        log(f"RENAME: {name} is already taken.", sinks=(self.__logfile, sys.stderr))
                        self.__send_client_message(client, f"The name \"{name}\" is already in use.")
                # The user is changing their text color.
                elif message_type == 2:
                    colordata = int.from_bytes(client.recv(3), byteorder="big")
                    log(f"RECOLOR: {self.__users[client.getpeername()].name()} to \"#{colordata:06x}\".", sinks=(self.__logfile, sys.stderr))
                    color = Color((colordata & 0xff0000) >> 16, (colordata & 0xff00) >> 8, colordata & 0xff)
                    self.__users[client.getpeername()].change_color(color)
                # The user is clearing their text color.
                elif message_type == 3:
                    log(f"CLEARCOLOR: {self.__users[client.getpeername()].name()} cleared their color.", sinks=(self.__logfile, sys.stderr))
                    self.__users[client.getpeername()].change_color(None)
                else:
                    raise RuntimeError(f"Invalid message type. Expected one of (0, 1, 2, 3), but got \"{message_type}\". Is your client bad?")
            except OSError as error:
                    addr = None
                    host = None
                    port = 0
                    try:
                        addr = client.getpeername()
                        host, port = socket.getnameinfo(addr, socket.NI_NUMERICHOST | socket.NI_NUMERICSERV)
                        log(f"Client {host}:{port} known as {self.__users[addr].name()} disconnected due to a socket error.", sinks=(self.__logfile, sys.stderr))
                    except:
                        pass
                    finally:
                        client.close()
                    if addr in self.__clients:
                        del self.__clients[addr]
                    if addr in self.__users and host is not None:
                        self.__broadcast_client_message(f"{self.__users[addr].name()} ({host}) has disconnected.")
                    if addr in self.__users:
                        del self.__users[addr]
            except Exception as error:
                log(f"ERROR: {error}", sinks=(self.__logfile, sys.stderr))
        flushlogs((sys.stderr, self.__logfile))

def main() -> None:
    """
    The main functionality of the chat server.
    """
    chat = ChatServer()
    try:
        quitting = False
        while not quitting:
            chat.drain_new_connections()
            chat.drain_new_messages()
            time.sleep(0.0001)
    except KeyboardInterrupt:
        pass
    except Exception as error:
        now = datetime.datetime.now()
        with open(f"chatserver.{os.getpid()}.error.{now.strftime('%c').replace(' ', '.').replace(':', '.')}.log", "w+") as file:
            print(error, file=file)
    finally:
        chat.close()

# Guard against importing the file by accident!
if __name__ == "__main__":
    main()
