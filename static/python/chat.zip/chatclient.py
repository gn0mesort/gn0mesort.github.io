import chat

HOST = "home.megate.ch"
PORT = 2504

def display_messages(room):
    """
    Display all the messages received in a ChatClient to the screen. This will only display messages that fit on
    the screen.

    @type room: ChatClient
    @param room: The ChatClient that will has its message log displayed.
    """
    messages = room.messages()
    for i in range(size[1]):
        index = i
        if len(messages) >= size[1]:
            index = (len(messages) - size[1]) + i
        if index < len(messages):
            print(messages[index] + (" " * (size[0] - len(messages[index]) - 1)))
        else:
            print("")

def handle_events(room):
    """
    Handle events received by a ChatClient. This handles special commands locally and issues them through the
    ChatClient.

    @type room: ChatClient
    @param room: The ChatClient that will be operated on.
    @rtype: bool
    @returns: True if the program received a quit signal. False otherwise.
    """
    ev = chat.poll_event()
    if ev == "\r" or ev == "\n":
        line = room.linebuffer().strip().split()
        if len(line) > 0:
            if line[0].lower() == "/quit":
                room.clearline()
                return True
            # Implement a command to change your name here.
            # ChatClient.rename() will send a rename message to the server, but how do we know which name to pick?
            pass
            # Implement a command to change your color here.
            # ChatClient.change_color() will send a color change message to the server. Like with the name, we need
            # to figure out what color was input. We also need to ensure the color is valid (all channels between 0
            # and 255), because the server will just interpret whatever we send as a color. Getting this wrong will
            # lead to weird stuff!
            pass
            # Implement a command to clear your color here.
            # ChatClient.clear_color() will send a color clear message to the server. This is how we say, "return to
            # the terminal's default color." This one is easy, because there aren't any parameters. Look at the
            # "/quit" command. Is this similar?
            pass
            # We can implement extra commands here. Can you think of any extra commands that we should add?
    room.type_key(ev)
    return False

size = chat.screen_size()
room = chat.ChatClient(HOST, PORT)
quitting = False
try:
    chat.init()
    while not quitting and room.is_connected():
        room.receive_messages()
        chat.goto(0, 0)
        display_messages(room)
        quitting = handle_events(room)
        chat.goto(0, size[1])
        linebuffer = room.linebuffer().strip()
        print(linebuffer + (" " * (size[0] - len(linebuffer))), end="")
except KeyboardInterrupt:
    pass
finally:
    room.close()
    chat.quit()
