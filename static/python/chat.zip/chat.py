import platform
import sys
import os
import math
import time
from enum import Enum
import socket
import select
import datetime

if platform.system() == "Windows":
    import msvcrt
elif platform.system() == "Linux" or platform.system() == "Darwin":
    import tty
    import termios
else:
    raise RuntimeError("Your system is unsupported by chat.py.")

def _srgb_gamma(l):
    """
    Gamma encode/transfer a linear normalized color value into sRGB colorspace.

    @type l: float
    @param l: A linear color value in the range [0, 1].
    @rtype: float
    @returns: An sRGB encoded color value matching the input linear value.
    """
    if math.fabs(l - 0.0031308) > 1e-10 and l < 0.0031308:
        return 12.92 * l
    else:
        return 1.055 * l ** (1 / 2.4) - 0.055

def _remap(a, b, c, d, x):
    """
    Remap a value from one range to another. This is useful for taking colors into normalized [0, 1] space or into
    binary [0, 255] space.

    @type a: float
    @param a: The minimum value of the source range.
    @type b: float
    @param b: The maximum value of the source range.
    @type c: float
    @param c: The minimum value of the destination range.
    @type d: float
    @param d: The maximum value of the destination range.
    @type x: float
    @param x: The value to remap.
    @rtype: float
    @returns: A floating point value in the new range that is equivalent to the source range value.
    """
    return c + (x - a) * (d - c) / (b - a)

class ChatClient:
    """
    A type representing a connection to an internet chat server over TCP.
    """
    @staticmethod
    def __magic():
        """
        Get the magic header value for chat messages.

        @rtype: bytearray
        @returns: A bytearray containing the ASCII encoded text "MEGATECH\r\n".
        """
        return bytearray("MEGATECH\r\n".encode("ascii"))
    def __init__(self, host, port):
        """
        Construct a new ChatClient and connect on the given host and port.

        @type host: str
        @param host: The name of the server to connect to. This can be an IP address, or a domain name.
        @type port: int
        @param port: The port to connect to on the host server. This must be a number between 1 and 65535.
        """
        self.__connection = socket.create_connection((host, port))
        self.__messages = [ ]
        self.__linebuffer = [ ]
    def close(self):
        """
        Close the ChatClient's connection to the host. This should be called just before quitting.
        """
        if self.__connection is not None:
            try:
                self.__connection.shutdown(socket.SHUT_RDWR)
            except:
                pass
            finally:
                self.__connection.close()
            self.__connection = None
    def is_connected(self):
        """
        Determine if the ChatClient is closed or not.

        @rtype: bool
        @returns: True if there is an active connection. False otherwise.
        """
        return self.__connection is not None
    def send_message(self, message):
        """
        Send a message to the server and all connected users.

        @type message: str
        @param message: The message to send to the server. This will be stripped and encoded as UTF-8.
        """
        buffer = ChatClient.__magic()
        buffer.extend(int(0).to_bytes(1, byteorder="big"))
        message = message.strip().encode("utf-8")
        buffer.extend(len(message).to_bytes(8, byteorder="big"))
        buffer.extend(message)
        self.__connection.send(buffer)
    def rename(self, name):
        """
        Send a rename command to the server. If the new name is available, the client will be renamed.

        @type name: str
        @param name: The desired name for this client.
        """
        buffer = ChatClient.__magic()
        buffer.extend(int(1).to_bytes(1, byteorder="big"))
        name = name.strip().encode("utf-8")
        buffer.extend(len(name).to_bytes(8, byteorder="big"))
        buffer.extend(name)
        self.__connection.send(buffer)
    def change_color(self, red, green, blue):
        """
        Send a change color command to the server. Colors must be validated externally or indeterminate behavior may
        be observed.

        @type red: int
        @param red: The red value. This must be between 0 and 255.
        @type green: int
        @param green: The green value. This must be between 0 and 255.
        @type blue: int
        @param blue: The blue value. This must be between 0 and 255.
        """
        buffer = ChatClient.__magic()
        buffer.extend(int(2).to_bytes(1, byteorder="big"))
        color = ((red & 0xff) << 16) | ((green & 0xff) << 8) | (blue & 0xff)
        buffer.extend(color.to_bytes(3, byteorder="big"))
        self.__connection.send(buffer)
    def clear_color(self):
        """
        Send a clear color command to the server.
        """
        buffer = ChatClient.__magic()
        buffer.extend(int(3).to_bytes(1, byteorder="big"))
        self.__connection.send(buffer)
    def messages(self):
        """
        Retrieve all the messages currently stored in the client.

        @rtype: tuple
        @returns: An n-tuple of messages received from the server.
        """
        return tuple(self.__messages)
    def receive_messages(self):
        """
        Receive new messages from the server. This must be called regularly to check for new data.
        """
        readable, _, _ =  select.select([ self.__connection ], [ ], [ ], 0)
        while self.__connection in readable:
            try:
                # Check for message magic
                magic = self.__connection.recv(10).decode("ascii")
                # An empty message means we lost the connection
                if len(magic) < 1:
                    try:
                        addr = self.__connection.getpeername()
                        host, port = socket.getnameinfo(addr, 0)
                    except:
                        pass
                    finally:
                        self.close()
                    self.__messages.append("Server disconnected.")
                    break
                if magic != "MEGATECH\r\n":
                    raise RuntimeError(f"Invalid message. Expected \"MEGATECH\\r\\n\", but got \"{magic}\". Is your server bad?")
                # Decode the time
                time = datetime.datetime.fromtimestamp(int.from_bytes(self.__connection.recv(8), byteorder="big"))
                # Check if the message has a color
                has_color = bool(int.from_bytes(self.__connection.recv(1), byteorder="big"))
                # Decode the color. If there isn't a color this will be 0
                color = int.from_bytes(self.__connection.recv(3), byteorder="big")
                # Decode the name
                name_len = int.from_bytes(self.__connection.recv(8), byteorder="big")
                name = self.__connection.recv(name_len).decode("utf-8")
                # Decode the message
                message_len = int.from_bytes(self.__connection.recv(8), byteorder="big")
                message = self.__connection.recv(message_len).decode("utf-8")
                # sRGB encoding
                if has_color:
                    red = _remap(0, 255, 0, 1, (color & 0xff0000) >> 16)
                    red = _srgb_gamma(red)
                    red = int(_remap(0, 1, 0, 255, red))
                    green = _remap(0, 255, 0, 1, (color & 0xff00) >> 8)
                    green = _srgb_gamma(green)
                    green = int(_remap(0, 1, 0, 255, green))
                    blue = _remap(0, 255, 0, 1, color & 0xff)
                    blue = _srgb_gamma(blue)
                    blue = int(_remap(0, 1, 0, 255, blue))
                    self.__messages.append(f"[{time.strftime("%c")}] {name}:\x1b[38;2;{red};{green};{blue}m {message}\x1b[0m")
                else:
                    self.__messages.append(f"[{time.strftime("%c")}] {name}: {message}")
            except socket.error:
                try:
                    addr = self.__connection.getpeername()
                    host, port = socket.getnameinfo(addr, socket.NI_NUMERICHOST | socket.NI_NUMERICSERV)
                except:
                    pass
                finally:
                    self.close()
                self.__messages.append("Server disconnected.")
                break
            readable, _, _ =  select.select([ self.__connection ], [ ], [ ], 0)
    def linebuffer(self):
        """
        Retrieve the local linebuffer. This is where input characters are stored before they're sent to the server.

        @rtype: str
        @returns: The string representation of the current linebuffer.
        """
        return "".join(self.__linebuffer)
    def clearline(self):
        """
        Erase the linebuffer.
        """
        self.__linebuffer.clear()
    def type_key(self, key):
        """
        Update the ChatClient's state based on an input key.

        @type key: str
        @param key: The typed key. Characters are inserted into the line buffer. Delete and backspace are handled by
                    popping a character off the buffer. Enter (either "\n" or "\r" depending on the system) will submit
                    a message to the server and clear the linebuffer.
        """
        if type(key) is not str:
            return
        if platform.system() == "Windows":
            if key == "\b" and len(self.__linebuffer) > 0:
                self.__linebuffer.pop()
            elif key == "\r" and len(self.__linebuffer) > 0:
                self.send_message(("".join(self.__linebuffer).strip()))
                self.__linebuffer.clear()
            else:
                self.__linebuffer.append(key)
        elif platform.system() == "Linux" or platform.system() == "Darwin":
            if (key == "\b" or key == "\x7f") and len(self.__linebuffer) > 0:
                self.__linebuffer.pop()
            elif key == "\n" and len(self.__linebuffer) > 0:
                self.send_message(("".join(self.__linebuffer).strip()))
                self.__linebuffer.clear()
            else:
                self.__linebuffer.append(key)

class SpecialKey(Enum):
    """
    A type representing all of the possible special keys on a keyboard.
    """
    Invalid = 0
    Up = 1
    Down = 2
    Left = 3
    Right = 4
    Home = 5
    End = 6
    Function1 = 7
    Function2 = 8
    Function3 = 9
    Function4 = 10
    Function5 = 11
    Function6 = 12
    Function7 = 13
    Function8 = 14
    Function9 = 15
    Function10 = 16
    Function11 = 17
    Function12 = 18
    NumpadSpace = 19
    NumpadTab = 20
    NumpadEnter = 21
    NumpadPF1 = 22
    NumpadPF2 = 22
    NumpadPF3 = 23
    NumpadPF4 = 24
    NumpadMultiply = 25
    NumpadAdd = 26
    NumpadComma = 27
    NumpadMinus = 28
    NumpadPeriod = 29
    NumpadDivide = 30
    Numpad0 = 31
    Numpad1 = 32
    Numpad2 = 33
    Numpad3 = 34
    Numpad4 = 35
    Numpad5 = 36
    Numpad6 = 37
    Numpad7 = 38
    Numpad8 = 39
    Numpad9 = 40
    NumpadEqual = 41
    Insert = 42
    Delete = 43
    PageUp = 44
    PageDown = 45
    Escape = 46
    def __str__(self):
        return self.name

_terminal_settings = None
_polling = None
_keymap = None

if platform.system() == "Windows":
    _keymap = { b"\x48": SpecialKey.Up, b"\x50": SpecialKey.Down, b"\x4b": SpecialKey.Left,
                 b"\x4d": SpecialKey.Right, b"\x47": SpecialKey.Home, b"\x4f": SpecialKey.End }
elif platform.system() == "Linux" or platform.system() == "Darwin":
    _keymap = { b"\x1bOA": SpecialKey.Up, b"\x1bOB": SpecialKey.Down, b"\x1bOC": SpecialKey.Right,
                 b"\x1bOD": SpecialKey.Left, b"\x1bOH": SpecialKey.Home, b"\x1bOF": SpecialKey.End, }

def poll_event():
    """
    Retrieve a keyboard event.

    @rtype: str|SpecialKey|None
    @returns: Most keys return a string with the corresponding character (e.g., "q"). Special keys (e.g., F1) return
              the corresponding SpecialKey value if they're handled. Otherwise None is returned.
    """
    global __keymap
    if platform.system() == "Windows":
        if msvcrt.kbhit():
            data = msvcrt.getch()
            if data in b"\x00\xe0":
                key = msvcrt.getch()
                if key in _keymap:
                    return _keymap[key]
            return data.decode("ascii")
    else:
        global _polling
        available = _polling.poll(1)
        data = sys.stdin.buffer.read(1)
        if len(data) == 0:
            return None
        if data != b"\x1b":
            return data.decode("ascii")
        else:
            sequence = bytearray(5)
            sequence[0] = 0x1b
            index = 1
            buffer = bytearray(1)
            count = sys.stdin.buffer.readinto(buffer)
            while count and index < len(sequence):
                sequence[index] = buffer[0]
                index += 1
                key = bytes(sequence[:index])
                if key in _keymap:
                    return _keymap[key]
                count = sys.stdin.buffer.readinto(buffer)
            return SpecialKey.Escape
    return None

def init():
    """
    Setup the screen. This must be called before any screen manipulation is done by the application.
    """
    if not sys.stdin.isatty():
        raise RuntimeError("chat.py requires an interactive terminal.")
    print("\x1b[?1049h\x1b=\x1b[?1h\x1b[?25l\x1b[2J\x1b[3J\x1b[0;0H", end="", flush=True)
    if platform.system() == "Linux" or platform.system() == "Darwin":
        global _terminal_settings
        global _polling
        _terminal_settings = termios.tcgetattr(sys.stdin.fileno())
        settings = _terminal_settings.copy()
        settings[3] &= ~(termios.ICANON | termios.ECHO)
        settings[3] |= termios.ISIG
        settings[6][termios.VMIN] = 0
        settings[6][termios.VTIME] = 0
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, settings)
        _polling = select.poll()
        _polling.register(sys.stdin.fileno(), select.POLLIN)

def quit():
    """
    Restore the screen back to its original state. This must be done before exitting the application.
    """
    if platform.system() == "Linux" or platform.system() == "Darwin":
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, _terminal_settings)
    print("\x1b[?1l\x1b>\x1b[?1049l\x1b[?25h", end="", flush=True)

def goto(x, y):
    """
    Move the screen's cursor to the position (x, y).

    @type x: int
    @param x: The x-axis coordinate of the position.
    @type y: int
    @param y: The y-axis coordinate of the position.
    """
    print(f"\x1b[{y + 1};{x + 1}H", end="", flush=True)

def clear():
    """
    Fill the screen with blank spaces.
    """
    print("\x1b[2J", end="", flush=True)

def screen_size():
    """
    Retrieve the size of the screen as a 2-tuple.

    @rtype: tuple
    @returns: A 2-tuple of (width, height).
    """
    size = os.get_terminal_size()
    return (size[0], size[1] - 1)
