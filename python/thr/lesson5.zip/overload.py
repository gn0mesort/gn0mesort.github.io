class Foo:
    def __init__(self):
        self._value = 0
    def value(self) -> int:
        return self._value

class Bar(Foo):
    def __init__(self):
        super().__init__()
        self._value = 100

b = Bar()
print(b.value())


