class FinalState:
    def __init__(self, result):
        self.__result = result
    def update(self, input):
        return self
    def result(self) -> bool:
        return self.__result
    def is_final(self) -> bool:
        return True

class NumberMatcherState:
    def __init__(self, input):
        self.__radix_points = 0
        self.__digits = 0
        if input is not None:
            self.update(input)
    def update(self, input):
        if input == "":
            return FinalState(self.__digits > 0 and self.__radix_points <= 1)
        elif input == "." and self.__radix_points <= 1:
            self.__radix_points = self.__radix_points + 1
            return self
        elif input in "0123456789":
            self.__digits = self.__digits + 1
            return self
        else:
            return FinalState(False)
    def is_final(self) -> bool:
        return False
    def result(self):
        pass

class SignMatcherState:
    def __init__(self):
        pass
    def update(self, input):
        if input == "":
            return FinalState(False)
        elif input in "+-":
            return NumberMatcherState(None)
        elif input in ".0123456789":
            return NumberMatcherState(input)
        else:
            return FinalState(False)
    def is_final(self) -> bool:
        return False
    def result(self):
        pass

def match_number(inputseq: str) -> bool:
    state = SignMatcherState()
    i = 0
    while not state.is_final():
        if i < len(inputseq):
            state = state.update(inputseq[i])
        else:
            state = state.update("")
        i = i + 1
    return state.result()

print(f"+0.123 is a number? {match_number("+0.123")}")
print(f"++0.123 is a number? {match_number("++0.123")}")
print(f"-.1 is a number? {match_number("-.1")}")
print(f"--.1 is a number? {match_number("--.1")}")
print(f"\"\" is a number? {match_number("")}")
print(f"1234 is a number? {match_number("1234")}")
