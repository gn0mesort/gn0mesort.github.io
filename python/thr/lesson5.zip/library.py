import pygame
import pygame.freetype
import sys
import random
import math
from pathlib import Path
from dataclasses import dataclass
from abc import abstractmethod

@dataclass
class Extent2D:
    """
    A dataclass that represents a two dimensional extent (width and height).
    """
    width: int = 1
    height: int = 1
    def copy(self):
        """
        Copy an Extent2D.

        @rtype: Extent2D
        @returns: A copy of the Extent2D.
        """
        return Extent2D(self.width, self.height)
    def __eq__(self, other) -> bool:
        return self.width == other.width and self.height == other.height

@dataclass
class Offset2D:
    """
    A dataclass that represents a two dimensional offset (coordinate).
    """
    x: int = 0
    y: int = 0
    def copy(self):
        """
        Copy an Offset2D.

        @rtype: Offset2D
        @returns: A copy of the Offset2D.
        """
        return Offset2D(self.x, self.y)
    def __eq__(self, other) -> bool:
        return self.x == other.x and self.y == other.y

@dataclass
class Vector2:
    x: float = 0
    y: float = 0
    def copy(self):
        return Vector2(float(x), float(y))

class SpriteMap:
    """
    A SpriteMap is an image containing many sprites for a game. Each sprite has a consistent width and height.
    """
    def __init__(self, path: Path|str, tile_extent: Extent2D):
        """
        Construct a SpriteMap by loading the image indicated by path and dividing it into tile_extent.width by
        tile_extent.height tiles

        @type path: Path|str
        @param path: A file path that indicates the image to load. The resulting image will be converted for optimal
                     blitting to the display. This must not be None.
        @type tile_extent: Extent2D
        @param tile_extent: The extent of a single tile in the map. The width and height should both be positive
                            integer values less than the corresponding extent of the loaded image. If the extent is
                            less or equal to 0 or greater than the size of the loaded image in either dimension the
                            extent will be the entire image. This must not be None.
        """
        self.__spritemap = pygame.image.load(path).convert_alpha()
        self.__tile_extent = tile_extent.copy()
        if self.__tile_extent.width > self.__spritemap.get_width() or tile_extent.width <= 0:
            self.__tile_extent.width = self.__spritemap.get_width()
        if self.__tile_extent.height > self.__spritemap.get_height() or tile_extent.height <= 0:
            self.__tile_extent.height = self.__spritemap.get_height()
    def get(self, x: int, y: int) -> pygame.surface.Surface:
        """
        Get a sprite image from the SpriteMap.

        @type x: int
        @param x: The x position of the image to retrieve. This is measured in tiles and not pixels. This must not be
                  None.
        @type y: The y position of the image to retrieve. This is measured in tiles and not pixels. This must not be
                 None.
        @rtype: pygame.surface.Surface
        @returns: A subsurface of the SpriteMap that matches the desired tile data and position.
        """
        if x < 0 or x >= self.width() or y < 0 or y >= self.height():
            raise ValueError(f"The tile ({x}, {y}) is not a valid tile in this SpriteMap.")
        return self.__spritemap.subsurface(pygame.Rect(self.__tile_extent.width * x, self.__tile_extent.height * y,
                                                       self.__tile_extent.width, self.__tile_extent.height))
    def tile_extent(self) -> Extent2D:
        """
        Get the extent of each tile in the SpriteMap in pixels.

        @rtype: Extent2D
        @returns: A 2D extent containing the width and height of each tile in the SpriteMap measured in pixels. The
                  returned value is a always a copy of the value in the SpriteMap, so mutating it is safe.
        """
        return self.__tile_extent.copy()
    def width(self) -> int:
        """
        Get the width of the SpriteMap in tiles.

        @rtype: int
        @returns: The width of the map in tiles.
        """
        return self.__spritemap.get_width() // self.__tile_extent.width
    def height(self) -> int:
        """
        Get the height of the SpriteMap in tiles.

        @rtype: int
        @returns: The height of the map in tiles.
        """
        return self.__spritemap.get_height() // self.__tile_extent.height


def min(a: float|int, b: float|int) -> float|int:
    """
    Get the minimum of two numbers.

    @type a: float|int
    @param a: The first value.
    @type b: float|int
    @param b: The second value.
    @rtype: float|int
    @returns: a if a is less than b. Otherwise b in all cases.
    """
    return a if a < b else b

def max(a: float|int, b: float|int) -> float|int:
    """
    Get the maximum of two numbers.

    @type a: float|int
    @param a: The first value.
    @type b: float|int
    @param b: The second value.
    @rtype: float|int
    @returns: a if a is greater than b. Otherwise b in all cases.
    """
    return a if a > b else b

def clamp(v: float|int, lo: float|int, hi: float|int) -> float|int:
    """
    Clamp a value into a range.

    @type v: float|int
    @param v: The value to clamp.
    @type lo: float|int
    @param lo: The lower bound of the range. This is inclusive.
    @type hi: float|int
    @param hi: The upper bound of the range. This is inclusive.
    @rtype: float|int
    @returns: v if v >= lo and v <= hi. Otherwise lo if v < lo or hi if v > hi.
    """
    return min(max(v, lo), hi)

def remap(x: int|float, a: int|float, b: int|float, c: int|float, d: int|float) -> int|float:
    """
    Remap a value from one range to another range.

    @type x: int|float
    @param x: The value to remap.
    @type a: int|float
    @param a: The minimum value (inclusive) of the current range.
    @type b: int|float
    @param b: The maximum value (inclusive) of the current range.
    @type c: int|float
    @param c: The minimum value (inclusive) of the new range.
    @type d: int|float
    @param d: The maximum value (inclusive) of the new range.
    @rtype: int|float
    @returns: The value of x remapped from [a, b] to [c, d].
    """
    return c + (x - a) * (d - c) / (b - a)

def fequal(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    """
    Compare two floating point values for equality with an epsilon. This is useful for finding two values that are
    almost but not exactly equal. Such situations commonly arise from floating point math and it's crucial to handle
    them.

    @type a: float
    @param a: The first value to compare.
    @type b: float
    @param b: The second value to compare.
    @type epsilon: float
    @param epsilon: A small acceptable difference between a and b. In mathematics, epsilon is usually used to represent
                    very small (often infinitely small) differences between two numbers. Here, we use it to mean that
                    two float values off by this amount are "close enough to equal". This defaults to
                    sys.float_info.epsilon, which is appropriate for comparing numbers near 0. In general, you should
                    specify your own epsilon with an appropriate value for your situation.
    @rtype: bool
    @returns: True if a and b are equal within the epsilon range. False otherwise.
    """
    abs_a = math.fabs(a)
    abs_b = math.fabs(b)
    difference = math.fabs(a - b)
    if a == b:
        return True
    elif a == 0 or b == 0 or (abs_a + abs_b < sys.float_info.min):
        return difference < (epsilon * sys.float_info.min)
    else:
        return difference / min(abs_a + abs_b, sys.float_info.max) < epsilon

def flessthan(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    """
    Determine if a < b with an epsilon.

    @type a: float
    @param a: The first value to compare.
    @type b: float
    @param b: The second value to compare.
    @type epsilon: float
    @param epsilon: A small acceptable difference between a and b. In mathematics, epsilon is usually used to represent
                    very small (often infinitely small) differences between two numbers. Here, we use it to mean that
                    two float values off by this amount are "close enough to equal". This defaults to
                    sys.float_info.epsilon, which is appropriate for comparing numbers near 0. In general, you should
                    specify your own epsilon with an appropriate value for your situation.
    @rtype: bool
    @returns: True if a < b and a != b within the epsilon range. False otherwise.
    """
    return a < b and not fequal(a, b, epsilon)

def fgreaterthan(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    """
    Determine if a > b with an epsilon.

    @type a: float
    @param a: The first value to compare.
    @type b: float
    @param b: The second value to compare.
    @type epsilon: float
    @param epsilon: A small acceptable difference between a and b. In mathematics, epsilon is usually used to represent
                    very small (often infinitely small) differences between two numbers. Here, we use it to mean that
                    two float values off by this amount are "close enough to equal". This defaults to
                    sys.float_info.epsilon, which is appropriate for comparing numbers near 0. In general, you should
                    specify your own epsilon with an appropriate value for your situation.
    @rtype: bool
    @returns: True if a > b and a != b within the epsilon range. False otherwise.
    """
    return a > b and not fequal(a, b, epsilon)

class Entity:
    @abstractmethod
    def aabb(self) -> pygame.Rect:
        pass
    @abstractmethod
    def collideentity(self, other) -> bool:
        pass
    @abstractmethod
    def render(self, target: pygame.surface.Surface) -> None:
        pass

class Treasure(Entity):
    def __init__(self, sprite: pygame.surface.Surface, position: Offset2D, sound: pygame.mixer.Sound):
        super().__init__()
        self.__sprite = sprite
        self.__position = position
        self.__sound = sound
    def aabb(self) -> pygame.Rect:
        return pygame.Rect(self.__position.x, self.__position.y, self.__sprite.get_width(), self.__sprite.get_height())
    def render(self, target: pygame.surface.Surface) -> None:
        target.blit(self.__sprite, (self.__position.x, self.__position.y))
    def collideentity(self, other: Entity) -> bool:
        return self.aabb().colliderect(other.aabb())
    def sound(self) -> pygame.mixer.Sound:
        return self.__sound

class Level:
    __WALL: int = 0
    __PASSAGE: int = 1
    __TREASURE: int = 2
    __START: int = 3
    __MONSTER: int = 4
    def __init__(self, path: Path|str, passage: pygame.surface.Surface, wall: pygame.surface.Surface,
                 treasuremap: SpriteMap, monstermap:SpriteMap, treasure_sound: pygame.mixer.Sound|None,
                 bgm: pygame.mixer.Sound|None):
        surface = pygame.image.load(path)
        self.__extent = Extent2D(surface.get_width(), surface.get_height())
        if (passage.get_width(), passage.get_height()) != (wall.get_width(), wall.get_height()):
            raise ValueError("Passage and wall tiles must have equal sizes.")
        self.__passage = passage
        self.__wall = wall
        self.__tiles = bytearray()
        self.__tiles.extend([ Level.__WALL ] * (self.__extent.width * self.__extent.height))
        self.__surface = None
        self.__treasures = [ ]
        self.__start_tiles = [ ]
        self.__monsters = [ ]
        self.__treasuremap = treasuremap
        self.__monstermap = monstermap
        self.__treasure_sound = treasure_sound
        self.__bgm = bgm
        for i in range(self.__extent.height):
            for j in range(self.__extent.width):
                color = surface.get_at((j, i))
                if color == pygame.Color(255, 255, 255):
                    self.__tiles[i * self.__extent.width + j] = Level.__PASSAGE
                elif color == pygame.Color(255, 0, 0):
                    self.__tiles[i * self.__extent.width + j] = Level.__START
                    self.__start_tiles.append(Offset2D(j, i))
                elif color == pygame.Color(0, 0, 255):
                    self.__tiles[i * self.__extent.width + j] = Level.__MONSTER
                elif color != pygame.Color(0, 0, 0):
                    self.__tiles[i * self.__extent.width + j] = Level.__TREASURE
        self.__prerender()
        self.initialize()
    def width(self) -> int:
        return self.__extent.width
    def height(self) -> int:
        return self.__extent.height
    def tile_width(self) -> int:
        return self.__passage.get_width()
    def tile_height(self) -> int:
        return self.__passage.get_height()
    def pixel_width(self) -> int:
        return self.__extent.width * self.__passage.get_width()
    def pixel_height(self) -> int:
        return self.__extent.height * self.__passage.get_height()
    def nearest_integer_scale_factor(self, display_resolution: Extent2D) -> int:
        width = display_resolution.width // self.pixel_width()
        height = display_resolution.height // self.pixel_height()
        return min(width, height)
    def nearest_integer_resolution(self, display_resolution: Extent2D) -> Extent2D:
        factor = self.nearest_integer_scale_factor(display_resolution)
        return Extent2D(factor * self.pixel_width(), factor * self.pixel_height())
    def index_from_coordinates(self, x: float, y: float) -> tuple:
        x = remap(x, 0, (self.__extent.width - 1) * self.__passage.get_width(), 0, self.__extent.width - 1)
        y = remap(y, 0, (self.__extent.height - 1) * self.__passage.get_height(), 0, self.__extent.height - 1)
        return (int(x), int(y))
    def is_passable(self, bounds: pygame.Rect) -> bool:
        x0, y0 = self.index_from_coordinates(bounds.x, bounds.y)
        x1, y1 = self.index_from_coordinates(bounds.x + bounds.width - 1, bounds.y + bounds.height - 1)
        return (self.__tiles[y0 * self.__extent.width + x0] != Level.__WALL and
                self.__tiles[y0 * self.__extent.width + x1] != Level.__WALL and
                self.__tiles[y1 * self.__extent.width + x0] != Level.__WALL and
                self.__tiles[y1 * self.__extent.width + x1] != Level.__WALL)
    def __prerender(self) -> None:
        self.__surface = pygame.surface.Surface((self.pixel_width(), self.pixel_height()), flags=pygame.SRCALPHA)
        self.__surface = self.__surface.convert_alpha()
        for i in range(self.__extent.height):
            for j in range(self.__extent.width):
                x = j * self.__passage.get_width()
                y = i * self.__passage.get_height()
                if self.__tiles[i * self.__extent.width + j] != Level.__WALL:
                    self.__surface.blit(self.__passage, (x, y))
                else:
                    self.__surface.blit(self.__wall, (x, y))
    def initialize(self) -> None:
        if self.__bgm is not None:
            self.__bgm.play(loops=-1)
        self.__treasures.clear()
        self.__start_tiles.clear()
        for i in range(self.__extent.height):
            for j in range(self.__extent.width):
                x = j * self.__passage.get_width()
                y = i * self.__passage.get_height()
                if self.__tiles[i * self.__extent.width + j] == Level.__TREASURE:
                    sprite = self.__treasuremap.get(random.randint(0, self.__treasuremap.width() - 1),
                                                    random.randint(0, self.__treasuremap.height() - 1))
                    self.__treasures.append(Treasure(sprite, Offset2D(x, y), self.__treasure_sound))
                elif self.__tiles[i * self.__extent.width + j] == Level.__MONSTER:
                    row = random.randint(0, self.__monstermap.height() - 1)
                    self.__monsters.append(Monster(self.__monstermap.get(0, row), self.__monstermap.get(1, row)))
                    self.__monsters[-1].teleport_to(x, y)
                elif self.__tiles[i * self.__extent.width + j] == Level.__START:
                    self.__start_tiles.append(Offset2D(x, y))
    def debug_print_tiles(self) -> None:
        for i in range(self.__extent.height):
            for j in range(self.__extent.width):
                print(f" {self.__tiles[i * self.__extent.width + j]} ", end="")
            print("")
    def treasures(self) -> list[Treasure]:
        return self.__treasures
    def start_tiles(self) -> tuple:
        return tuple(self.__start_tiles)
    def monsters(self) -> list:
        return self.__monsters
    def render(self, target: pygame.surface.Surface) -> None:
        target.blit(self.__surface, (0, 0))

class Animation:
    def __init__(self, framestep: float, frames: list|tuple,
                 repeat: bool = True):
        self.__framestep = framestep
        self.__frames = frames
        self.__repeat = repeat
        self.__acc = 0
        self.__index = 0
        self.__should_stop = False
        self.__playing = False
    def get_surface(self) -> pygame.surface.Surface:
        return self.__frames[self.__index]
    def reset(self) -> None:
        self.__index = 0
        self.__acc = 0
        self.__should_stop = False
        self.__playing = False
    def play(self) -> None:
        self.__playing = True
        self.__should_stop = False
    def should_stop(self) -> None:
        self.__should_stop = True
    def update(self, dt: float) -> None:
        if not self.__playing:
            return
        self.__acc = self.__acc + dt
        while self.__acc >= self.__framestep:
            self.__acc = self.__acc - self.__framestep
            if self.__should_stop:
                self.reset()
            elif self.__index < len(self.__frames) - 1:
                self.__index = self.__index + 1
            elif self.__index == len(self.__frames) - 1 and self.__repeat:
                self.__index = 0

class Actor(Entity):
    def __init__(self, base: pygame.surface.Surface):
        super().__init__()
        self.__animations = { }
        self.__current_animation = None
        self.__playing = False
        self.__screen_position = Vector2()
        self.__velocity = Vector2()
        self.__logical_position = Offset2D()
        self.__move_speed = 0
    def teleport_to(self, x: float, y: float) -> None:
        self.__logical_position.x = int(x)
        self.__logical_position.y = int(y)
        self.__screen_position.x = x
        self.__screen_position.y = y
    def position(self) -> Vector2:
        return self.__screen_position
    def width(self) -> int:
        return self.__animations[self.__current_animation].get_surface().get_width()
    def height(self) -> int:
        return self.__animations[self.__current_animation].get_surface().get_height()
    def add_animation(self, name: str, animation: Animation) -> None:
        self.__animations[name] = animation
        if self.__current_animation is None:
            self.__current_animation = name
    def play_animation(self, name: str) -> None:
        if name != self.__current_animation:
            self.__animations[name].reset()
        self.__animations[name].play()
        self.__current_animation = name
        self.__playing = True
    def stop_animation(self) -> None:
        self.__animations[self.__current_animation].should_stop()
        self.__playing = False
    def is_animating(self) -> bool:
        return self.__playing
    def animation(self) -> str:
        return self.__current_animation
    def velocity(self) -> Vector2:
        return Vector2(self.__velocity.x, self.__velocity.y)
    def set_velocity(self, v: Vector2) -> None:
        self.__velocity = v
    def update(self, dt: float, level: Level) -> None:
        self.__animations[self.__current_animation].update(dt)
        surface = self.__animations[self.__current_animation].get_surface()
        dir_x = 0
        if self.__velocity.x < 0:
            dir_x = -1
        elif self.__velocity.x > 0:
            dir_x = 1
        dir_y = 0
        if self.__velocity.y < 0:
            dir_y = -1
        elif self.__velocity.y > 0:
            dir_y = 1
        is_equal = fequal(self.__screen_position.x, self.__logical_position.x, 1e-2)
        is_equal = is_equal and fequal(self.__screen_position.y, self.__logical_position.y, 1e-2)
        if is_equal:
            self.__screen_position.x = self.__logical_position.x
            self.__screen_position.y = self.__logical_position.y
            if dir_x != 0 or dir_y != 0:
                if dir_x < 0:
                    self.play_animation("walk_left")
                elif dir_x > 0:
                    self.play_animation("walk_right")
                elif dir_y < 0:
                    self.play_animation("walk_up")
                elif dir_y > 0:
                    self.play_animation("walk_down")
                bounds = pygame.Rect(0, 0, surface.get_width(), surface.get_height())
                bounds.x = self.__logical_position.x + dir_x * level.tile_width()
                bounds.y = self.__logical_position.y + dir_y * level.tile_height()
                if level.is_passable(bounds):
                    self.__logical_position.x = self.__logical_position.x + dir_x * level.tile_width()
                    self.__logical_position.y = self.__logical_position.y + dir_y * level.tile_height()
                    self.__move_speed = math.hypot(self.__velocity.x, self.__velocity.y)
            else:
                self.stop_animation()
        dx = self.__logical_position.x - self.__screen_position.x
        dy = self.__logical_position.y - self.__screen_position.y
        step_x = self.__velocity.x * dt
        step_y = self.__velocity.y * dt
        if math.fabs(dx) <= self.__move_speed * dt:
            self.__screen_position.x = self.__logical_position.x
        else:
            self.__screen_position.x = self.__screen_position.x + math.copysign(self.__move_speed * dt, dx)
        if math.fabs(dy) <= math.fabs(step_y):
            self.__screen_position.y = self.__logical_position.y
        else:
            self.__screen_position.y = self.__screen_position.y + math.copysign(self.__move_speed * dt, dy)
    def aabb(self) -> pygame.Rect:
        sprite = self.__animations[self.__current_animation].get_surface()
        return pygame.Rect(self.__screen_position.x, self.__screen_position.y, sprite.get_width(), sprite.get_height())
    def collideentity(self, other: Entity) -> bool:
        return self.aabb().colliderect(other.aabb())
    def render(self, target: pygame.surface.Surface) -> None:
        location = (int(self.__screen_position.x), int(self.__screen_position.y))
        target.blit(self.__animations[self.__current_animation].get_surface(), location)

class Monster(Entity):
    def __init__(self, left: pygame.surface.Surface, right: pygame.surface.Surface):
        super().__init__()
        self.__left = left
        self.__right = right
        self.__current = self.__left
        self.__screen_position = Vector2()
        self.__velocity = Vector2()
        self.__logical_position = Offset2D()
        self.__move_speed = 0
    def teleport_to(self, x: float, y: float) -> None:
        self.__logical_position.x = int(x)
        self.__logical_position.y = int(y)
        self.__screen_position.x = x
        self.__screen_position.y = y
    def update(self, dt: float, level: Level) -> None:
        surface = self.__current
        dir_x = 0
        dir_y = 0
        if random.randint(0, 1) == 0:
            dir_x = random.randint(-1, 1)
            self.__velocity = Vector2(2 * dir_x * level.tile_width(), 0)
        else:
            dir_y = random.randint(-1, 1)
            self.__velocity = Vector2(0, 2 * dir_y * level.tile_height())
        is_equal = fequal(self.__screen_position.x, self.__logical_position.x, 1e-2)
        is_equal = is_equal and fequal(self.__screen_position.y, self.__logical_position.y, 1e-2)
        if is_equal:
            self.__screen_position.x = self.__logical_position.x
            self.__screen_position.y = self.__logical_position.y
            if dir_x != 0 or dir_y != 0:
                if dir_x < 0:
                    self.__current = self.__left
                elif dir_x > 0:
                    self.__current = self.__right
                bounds = pygame.Rect(0, 0, surface.get_width(), surface.get_height())
                bounds.x = self.__logical_position.x + dir_x * level.tile_width()
                bounds.y = self.__logical_position.y + dir_y * level.tile_height()
                if level.is_passable(bounds):
                    self.__logical_position.x = self.__logical_position.x + dir_x * level.tile_width()
                    self.__logical_position.y = self.__logical_position.y + dir_y * level.tile_height()
                    self.__move_speed = math.hypot(self.__velocity.x, self.__velocity.y)
        dx = self.__logical_position.x - self.__screen_position.x
        dy = self.__logical_position.y - self.__screen_position.y
        step_x = self.__velocity.x * dt
        step_y = self.__velocity.y * dt
        if math.fabs(dx) <= self.__move_speed * dt:
            self.__screen_position.x = self.__logical_position.x
        else:
            self.__screen_position.x = self.__screen_position.x + math.copysign(self.__move_speed * dt, dx)
        if math.fabs(dy) <= math.fabs(step_y):
            self.__screen_position.y = self.__logical_position.y
        else:
            self.__screen_position.y = self.__screen_position.y + math.copysign(self.__move_speed * dt, dy)
    def aabb(self) -> pygame.Rect:
        return pygame.Rect(self.__screen_position.x, self.__screen_position.y, self.__current.get_width(),
                           self.__current.get_height())
    def collideentity(self, other: Entity) -> bool:
        return self.aabb().colliderect(other.aabb())
    def render(self, target: pygame.surface.Surface) -> None:
        location = (int(self.__screen_position.x), int(self.__screen_position.y))
        target.blit(self.__current, location)

class State:
    @abstractmethod
    def load(self) -> None:
        pass
    @abstractmethod
    def unload(self) -> None:
        pass
    @abstractmethod
    def quit_requested(self) -> bool:
        pass
    @abstractmethod
    def update(self, controls: dict, dt: float):
        pass
    @abstractmethod
    def render(self, target: pygame.surface.Surface) -> None:
        pass
