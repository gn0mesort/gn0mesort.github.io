class Animal:
    def __init__(self, name: str):
        self.__name = name
    def name(self) -> str:
        return self.__name

class LoudAnimal(Animal):
    def __init__(self, name: str, sound: str):
        super().__init__(name)
        self.__sound = sound
    def speak(self) -> None:
        print(self.__sound)

class Lemur(LoudAnimal):
    def __init__(self):
        super().__init__("Lemur", "Screech!")

class Snake(LoudAnimal):
    def __init__(self):
        super().__init__("Snake", "Hiss!")

class Lion(LoudAnimal):
    def __init__(self):
        super().__init__("Lion", "Roar!")

class Turtle(Animal):
    def __init__(self):
        super().__init__("Turtle")

class Fish(Animal):
    def __init__(self):
        super().__init__("Fish")

class Giraffe(Animal):
    def __init__(self):
        super().__init__("Giraffe")

zoo = (Lemur(), Snake(), Lion(), Turtle(), Fish(), Giraffe())
for animal in zoo:
    print(animal.name(), end=": ")
    if isinstance(animal, LoudAnimal):
        animal.speak()
    else:
        print("doesn't say anything.")
