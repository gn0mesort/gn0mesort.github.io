from library import *
import pygame
import pygame.freetype
from dataclasses import dataclass
from pathlib import Path

WIDTH = 1920
HEIGHT = 1080
DEBUG = True

# FIXME: We need a state class for any of the end game states.

class MainMenuState(State):
    __PLAY: int = 0
    __QUIT: int = 1
    def __init__(self, typeface:pygame.freetype.Font, next: State):
        super().__init__()
        self.__typeface = typeface
        self.__play = [ ]
        self.__quit = [ ]
        self.__next = next
        self.__quitting = False
        self.__cursor = MainMenuState.__PLAY
        self.__timeout = 0
        self.__backbuffer = None
    def load(self) -> None:
        self.__play.append(self.__typeface.render("Play!", fgcolor=(255, 255, 255))[0])
        self.__play.append(self.__typeface.render("Play!", fgcolor=(128, 128, 128))[0])
        self.__quit.append(self.__typeface.render("Quit!", fgcolor=(255, 255, 255))[0])
        self.__quit.append(self.__typeface.render("Quit!", fgcolor=(128, 128, 128))[0])
    def unload(self) -> None:
        self.__play.clear()
        self.__quit.clear()
    def quit_requested(self) -> bool:
        return self.__quitting
    def update(self, controls: dict, dt):
        # FIXME: We need to implement the update routine for the main menu. This is how we change which
        # option is selected, and decide how long it should take to change options. If we allow the user
        # to change options too quickly, it will be impossible to use the menu!
        pass
    def render(self, target: pygame.surface.Surface) -> None:
        first = None
        if self.__cursor == MainMenuState.__PLAY:
            position = Offset2D((target.get_width() - self.__play[0].get_width()) // 2,
                                (target.get_height() // 2) - self.__play[0].get_height())
            first = target.blit(self.__play[0], (position.x, position.y))
        else:
            position = Offset2D((target.get_width() - self.__play[0].get_width()) // 2,
                                (target.get_height() // 2) - self.__play[0].get_height())
            first = target.blit(self.__play[1], (position.x, position.y))
        if self.__cursor == MainMenuState.__QUIT:
            target.blit(self.__quit[0], first.bottomleft)
        else:
            target.blit(self.__quit[1], first.bottomleft)

@dataclass
class LevelStateDescription:
    levelpath: Path|str = None
    floormap: SpriteMap = None
    wallmap: SpriteMap = None
    playermap: SpriteMap = None
    treasuremap: SpriteMap = None
    monstermap: SpriteMap = None
    pickupsound: pygame.mixer.Sound = None
    diesound: pygame.mixer.Sound = None
    bgmsound: pygame.mixer.Sound = None
    typeface: pygame.freetype.Font = None
    def copy(self):
        return LevelStateDescription(self.levelpath, self.floormap, self.wallmap, self.playermap, self.treasuremap,
                                     self.monstermap, self.pickupsound, self.diesound, self.bgmsound, self.typeface)

class LevelState(State):
    def __init__(self, description: LevelStateDescription, next: State, lose: State):
        super().__init__()
        self.__description = description
        self.__level = None
        self.__player = None
        self.__renderres = Extent2D()
        self.__scaleres = Extent2D()
        self.__backbuffer = None
        self.__scalebuffer = None
        self.__next = next
        self.__lose = lose
    def load(self) -> None:
        passage = self.__description.floormap.get(1, 19)
        wall = self.__description.wallmap.get(1, 19)
        description = self.__description
        self.__level = Level(description.levelpath, passage, wall, description.treasuremap, description.monstermap,
                             description.pickupsound, description.bgmsound)
        self.__backbuffer = pygame.surface.Surface((self.__level.pixel_width(), self.__level.pixel_height()),
                                                   flags=pygame.SRCALPHA).convert_alpha()
        playermap = self.__description.playermap
        player = Actor(playermap.get(0, 0))
        dur = 1.0 / 4.0
        player_down = Animation(dur, (playermap.get(0, 0), playermap.get(1, 0), playermap.get(2, 0),
                                      playermap.get(3, 0)))
        player_up = Animation(dur,  (playermap.get(0, 3), playermap.get(1, 3), playermap.get(2, 3),
                                     playermap.get(3, 3)))
        player_left = Animation(dur, (playermap.get(0, 1), playermap.get(1, 1), playermap.get(2, 1),
                                      playermap.get(3, 1)))
        player_right = Animation(dur, (playermap.get(0, 2), playermap.get(1, 2), playermap.get(2, 2),
                                       playermap.get(3, 2)))
        player.add_animation("walk_down", player_down)
        player.add_animation("walk_up", player_up)
        player.add_animation("walk_left", player_left)
        player.add_animation("walk_right", player_right)
        start = random.choice(self.__level.start_tiles())
        player.teleport_to(start.x, start.y)
        self.__player = player
    def unload(self) -> None:
        self.__player = None
        self.__level = None
    def update(self, controls: dict, dt: float) -> None:
        if self.__player is None:
            self.__description.bgmsound.fadeout(1)
            return self.__lose
        if len(self.__level.treasures()) == 0:
            self.__description.bgmsound.stop()
            return self.__next
        if controls[pygame.K_w]:
            self.__player.set_velocity(Vector2(0, -2 * self.__level.tile_height()))
        if controls[pygame.K_s]:
            self.__player.set_velocity(Vector2(0, 2 * self.__level.tile_height()))
        if controls[pygame.K_a]:
            self.__player.set_velocity(Vector2(-2 * self.__level.tile_width(), 0))
        if controls[pygame.K_d]:
            self.__player.set_velocity(Vector2(2 * self.__level.tile_width(), 0))
        if not controls[pygame.K_w] and not controls[pygame.K_a] and not controls[pygame.K_s] and not controls[pygame.K_d]:
            self.__player.set_velocity(Vector2())
        for monster in self.__level.monsters():
            if self.__player is not None and monster.collideentity(self.__player):
                self.__description.diesound.play()
                self.__player = None
            monster.update(dt, self.__level)
        if self.__player is not None:
            self.__player.update(dt, self.__level)
        for treasure in self.__level.treasures():
            if self.__player is not None and treasure.collideentity(self.__player):
                self.__level.treasures().remove(treasure)
                if treasure.sound().get_num_channels() == 0:
                    treasure.sound().play()
        return self
    def render(self, target: pygame.surface.Surface) -> None:
        if self.__scalebuffer is None or self.__renderres != Extent2D(target.get_width(), target.get_height()):
            self.__renderres = Extent2D(target.get_width(), target.get_height())
            self.__scaleres = self.__level.nearest_integer_resolution(self.__renderres)
            self.__scalebuffer = pygame.surface.Surface((self.__scaleres.width, self.__scaleres.height),
                                                        flags=pygame.SRCALPHA).convert_alpha()
        self.__level.render(self.__backbuffer)
        for treasure in self.__level.treasures():
            treasure.render(self.__backbuffer)
        if self.__player is not None:
            self.__player.render(self.__backbuffer)
        for monster in self.__level.monsters():
            monster.render(self.__backbuffer)
        pygame.transform.scale(self.__backbuffer, (self.__scaleres.width, self.__scaleres.height),
                               dest_surface=self.__scalebuffer)
        if self.__renderres.width < self.__level.pixel_width() or self.__renderres.height < self.__level.pixel_height():
            typeface = self.__description.typeface
            size = typeface.size
            rect = typeface.get_rect("Get a 486 :-)")
            while rect.width >= self.__renderres.width or rect.height >= self.__renderres.height:
                size -= 1
                rect = typeface.get_rect("Get a 486 :-)", size=size)
            target.blit(typeface.render(None, (255, 255, 255))[0],
                        ((self.__renderres.width - rect.width) // 2, (self.__renderres.height - rect.height) // 2))
        else:
            x = 0
            y = 0
            if self.__scaleres.width != self.__renderres.width:
                x = (self.__renderres.width - self.__scaleres.width) // 2
            if self.__scaleres.height != self.__renderres.height:
                y = (self.__renderres.height - self.__scaleres.height) // 2
            target.blit(self.__scalebuffer, (x, y))

def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
    description = LevelStateDescription()
    # FIXME: We need to set up our states here and select one to be the initial state! The level states accept a
    # LevelStateDescription, so they'll need a not of resources to be loaded. The menu and end game states are simpler.
    # We also need to consider the order in which states are initialized. Since earlier states (main menu, gameplay)
    # need to reference later states (game over, game complete) they need to be created in reverse order!
    pass
    state.load()
    quitting = False
    clock = pygame.time.Clock()
    dt = 0.0
    controls = { pygame.K_w: False, pygame.K_a: False, pygame.K_s: False, pygame.K_d: False, pygame.K_RETURN: False }
    typeface = pygame.freetype.Font("nec.ttf", 16)
    framerate = description.typeface.render(f"{clock.get_fps():.02f} Hz", fgcolor=(255, 255, 255), bgcolor=(0, 0, 0, 128))[0]
    while not quitting and not state.quit_requested():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quitting = True
            if event.type == pygame.KEYDOWN or event.type == pygame.KEYUP:
                controls[event.key] = event.type == pygame.KEYDOWN
        newstate = state.update(controls, dt)
        if newstate is not state:
            state.unload()
            newstate.load()
            state = newstate
        screen.fill(pygame.Color(0, 0, 0))
        state.render(screen)
        if DEBUG:
            description.typeface.render_to(framerate, (0, 0), f"{clock.get_fps():.02f} Hz", fgcolor=(255, 255, 255),
                                           bgcolor=(0, 0, 0, 128))
            screen.blit(framerate, (5, 5))
        pygame.display.update()
        dt = clock.tick() / 1000.0
    pygame.quit()

if __name__ == "__main__":
    main()
