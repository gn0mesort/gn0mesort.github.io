class Foo:
    def __init__(self):
        pass

class Bar(Foo):
    def __init__(self):
        super().__init__()

class Qux:
    def __init__(self):
        self.__bar = Bar()
    def bar(self) -> Bar:
        return self.__bar

for value in (Foo(), Bar(), Qux()):
    if isinstance(value, Foo):
        print(f"{value} is a Foo.")
    else:
        print(f"{value} is not a Foo.")
    if hasattr(value, "bar") and isinstance(value.bar(), Bar):
        print(f"{value} has a Bar.")
    else:
        print(f"{value} does not have a Bar.")
