import pygame

pygame.init()

pygame.mixer.music.load("prelude.ogg")
pygame.mixer.music.play()
while pygame.mixer.music.get_busy():
    pass
pygame.quit()
