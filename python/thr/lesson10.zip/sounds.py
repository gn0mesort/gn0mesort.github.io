import pygame

pygame.init()

sound = pygame.mixer.Sound("victory.ogg")
sound.play()
while sound.get_num_channels() > 0:
    pass
pygame.quit()
