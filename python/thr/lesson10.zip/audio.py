from pathlib import Path

import magic
import pygame
import pygame.freetype

from library import *

WIDTH = 640
HEIGHT = 480

def all_music_files(path: Path|str, types: list[str]) -> list[Path]:
    # FIXME: We need to list all of the music files in the given directory. To do this, we need to iterate through
    # all of the files in the directory and list the ones with types that match the input list.
    pass

def to_human_readable(size: int) -> str:
    UNITS = "KMGTPE"
    if size < 1024:
        return f"{size} B"
    bits = size.bit_length()
    zeroes = (bits - 1) // 10
    divisor = 1 << (zeroes * 10)
    return f"{size / divisor:.02f} {UNITS[zeroes - 1]}iB"

class FileInfo:
    def __init__(self, path: Path|str):
        # FIXME:
        # This structure is responsible for displaying information about our audio files. We want to get the type
        # information using the magic module, the size (in bytes), and the file's path relative to the current
        # directory
        pass
    def filetype(self) -> str:
        return self.__filetype
    def size(self) -> int:
        if self.__stat is not None:
            return self.__stat.st_size
        return 0
    def path(self) -> Path:
        return self.__path

def render_file_list(files: list[Path], typeface: pygame.freetype.Font, boxmap: SpriteMap, bgcolor = pygame.Color(0, 0, 255)) -> pygame.surface.Surface:
    # FIXME: We need to render the list of files in the current directory that are music files. We need to display
    # each file name in its own row.
    pass

def render_info(info: FileInfo, typeface: pygame.freetype.Font, boxmap: SpriteMap, bgcolor = pygame.Color(0, 0, 255)) -> pygame.surface.Surface:
    # FIXME: We need to render the info for the currently selected file for display on the screen. Then we need to
    # return the finished dialogue surface for blitting. We can use the linewrap library function to help us here.
    pass

def render_now_playing(file: Path, typeface: pygame.freetype.Font, boxmap: SpriteMap, bgcolor = pygame.Color(0, 0, 255)) -> pygame.surface.Surface:
    # FIXME: We need to render the now playing box so that we can see what's playing.
    pass

pygame.init()
boxmap = SpriteMap("box.webp", 4, 4)
screen = pygame.display.set_mode((WIDTH, HEIGHT))
typeface = pygame.freetype.Font("nec.ttf", 12)
typeface.fgcolor = pygame.Color(255, 255, 255)
clock = pygame.time.Clock()
cursor = pygame.image.load("pointer.webp")
index = 0
selected = None
quitting = False
dt = 0
em = typeface.get_rect("M")
music_files = all_music_files(Path.cwd(), (".ogg", ".mp3", ".wav", ".mid", ".flac"))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP or event.key == pygame.K_w:
                index = index - 1
            elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                index = index + 1
            elif event.key == pygame.K_RETURN or event.key == pygame.K_e:
                pygame.mixer.music.load(music_files[index])
                pygame.mixer.music.play()
                selected = music_files[index]
    music_files = all_music_files(Path.cwd(), (".ogg", ".mp3", ".wav", ".mid", ".flac"))
    if index < 0:
        index = 0
    elif index >= len(music_files):
        index = len(music_files) - 1
    file_list = render_file_list(music_files, typeface, boxmap)
    info_box = render_info(FileInfo(music_files[index]), typeface, boxmap)
    now_playing = render_now_playing(selected, typeface, boxmap)
    screen.fill(pygame.Color(0, 0, 0))
    screen.blit(file_list, (10, 10))
    screen.blit(info_box, (screen.get_width() - info_box.get_width() - 10, 10))
    screen.blit(now_playing, (10, screen.get_height() - 10 - now_playing.get_height()))
    screen.blit(cursor, (10 + file_list.get_width() + 5, (10 + cursor.get_height() * index) - (5 * index + 1)))
    pygame.display.flip()
    dt = clock.tick() / 1000
pygame.quit()
