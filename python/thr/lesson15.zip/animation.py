import math

import pygame

class Animation:
    def __init__(self, frames: list, duration: float, loop: bool = False):
        self.__frames = frames
        self.__frame = 0
        self.__acc = 0
        self.__duration = duration
        self.__per_frame = duration / len(self.__frames)
        self.__loop = loop
        self.__playing = False
    def copy(self):
        return Animation(self.__frames, self.__duration, loop=self.__loop)
    def update(self, dt: float) -> None:
        self.__acc = self.__acc + dt
        while not math.isclose(self.__acc, self.__per_frame, rel_tol=0, abs_tol=1e-6) and self.__acc > self.__per_frame:
            if self.__playing:
                self.__frame = (self.__frame + 1) % len(self.__frames)
                if self.__frame == 0 and not self.__loop:
                    self.__playing = False
            self.__acc = self.__acc - self.__per_frame
    def frame(self):
        return self.__frames[self.__frame]
    def is_playing(self) -> bool:
        return self.__playing
    def play(self) -> None:
        if not self.__playing:
            self.__playing = True
    def looping(self) -> bool:
        return self.__loop
    def stop(self) -> None:
        self.__playing = False
    def reset(self) -> None:
        self.stop()
        self.__frame = 0
    def set_frame(self, frame: int) -> None:
        self.__frame = frame % len(self.__frames)
    def __len__(self) -> int:
        return len(self.__frames)

