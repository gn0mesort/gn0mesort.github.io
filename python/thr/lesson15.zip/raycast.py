from __future__ import annotations

import math
from pathlib import Path
from dataclasses import dataclass
from abc import abstractmethod

import numpy

import pygame
import pygame.surfarray

from animation import Animation

LIGHTING = True
COLLISION = True

def radians(degrees: float) -> float:
    return degrees * math.pi / 180

def degrees(radians: float) -> float:
    return radians * 180 / math.pi

def sub(a: tuple[float, float], b: tuple[float, float]) -> tuple[float, float]:
    return (a[0] - b[0], a[1] - b[1])

def dot(a: tuple[float, float], b: tuple[float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1]

def clamp(v, lo, hi):
    return min(max(v, lo), hi)

def lerp(a: float, b: float, t: float) -> float:
    return a + t * (b - a)

def rotate(direction: tuple[float, float], theta: float) -> tuple[float, float]:
    x = direction[0] * math.cos(theta) - direction[1] * math.sin(theta)
    y = direction[0] * math.sin(theta) + direction[1] * math.cos(theta)
    return (x, y)

def walk(position: tuple[float, float], direction: tuple[float, float], speed: float = 0.1):
    return (position[0] + direction[0] * speed, position[1] + direction[1] * speed)

def darken(color: tuple[int, int, int], factor: float, min_brightness: float = 0.25) -> tuple[int, int, int]:
    r, g, b = color
    nr = int(clamp(r * factor, r * min_brightness, r))
    ng = int(clamp(g * factor, g * min_brightness, g))
    nb = int(clamp(b * factor, b * min_brightness, b))
    return (nr, ng, nb)

class RayQueryable:
    def __init__(self) -> RayQueryable:
        self.__seen = False
    @abstractmethod
    def is_solid(self) -> bool:
        pass
    @abstractmethod
    def is_physics_solid(self) -> bool:
        pass
    def is_seen(self) -> bool:
        return self.__seen
    def hit(self) -> None:
        self.__seen = True

class Nothing(RayQueryable):
    def __init__(self) -> Nothing:
        super().__init__()
    def is_solid(self) -> bool:
        return False
    def is_physics_solid(self) -> bool:
        return False

class Something(RayQueryable):
    def __init__(self) -> Something:
        super().__init__()
    def is_solid(self) -> bool:
        return True

class Wall(Something):
    def __init__(self, color) -> Wall:
        super().__init__()
        self._color = color
    def is_physics_solid(self) -> bool:
        return True
    def color(self) -> pygame.Color:
        return self._color
    def __repr__(self) -> str:
        return f"Wall({self._color})"

class Object(Something):
    def __init__(self, position: tuple[float, float], texture_id: int,
                 world_scale: tuple[float, float] = (1, 1), vertical_offset: float = 0) -> Object:
        super().__init__()
        self._position = position
        self._texture_id = texture_id
        self._scale = world_scale
        self.__vertical_offset = vertical_offset
    def position(self) -> tuple[float, float]:
        return self._position
    def texture_id(self) -> int:
        return self._texture_id
    def width(self) -> float:
        return self._scale[0]
    def height(self) -> float:
        return self._scale[1]
    def vertical_offset(self) -> float:
        return self.__vertical_offset

class Obstacle(Object):
    def __init__(self, position: tuple[float, float], texture_id: int,
                 world_scale: tuple[float, float] = (1, 1), vertical_offset: float = 0) -> Obstacle:
        super().__init__(position, texture_id, world_scale, vertical_offset)
    def is_physics_solid(self) -> bool:
        return True

class Actor(Something):
    def __init__(self, position: tuple[float, float], fov: float = 90, world_scale: tuple[float, float] = (1, 1),
                 vertical_offset: float = 0.5) -> Actor:
        super().__init__()
        self._hp = 0
        self._scale = world_scale
        self._vertical_offset = vertical_offset
        self._direction = rotate((-1, 0), radians(180))
        self._plane = rotate((0, -math.sin(radians(fov))), radians(180))
        self._position = position
        self.__light = False
    def width(self) -> float:
        return self._scale[0]
    def height(self) -> float:
        return self._scale[1]
    def vertical_offset(self) -> float:
        return self._vertical_offset
    def position(self) -> tuple[float, float]:
        return self._position
    def set_position(self, position: tuple[float, float]) -> None:
        self._position = position
    def direction(self) -> tuple[float, float]:
        return self._direction
    def yaw(self) -> float:
        rads = math.atan2(self._direction[1], self._direction[0])
        if rads < 0:
            return 2 * math.pi + rads
        return rads
    def plane(self) -> tuple[float, float]:
        return self._plane
    def position(self) -> tuple[float, float]:
        return self._position
    def pivot(self, theta: float) -> None:
        self._direction = rotate(self._direction, theta)
        self._plane = rotate(self._plane, theta)
    def walk(self, speed) -> None:
        self._position = walk(self._position, self._direction, speed=speed)
    def strafe(self, speed) -> None:
        direction = rotate(self._direction, radians(90))
        self._position = walk(self._position, direction, speed=speed)
    def toggle_light(self) -> None:
        self.__light = not self.__light
    def is_using_light(self) -> bool:
        return self.__light
    def is_physics_solid(self) -> bool:
        return True
    def update(self, dt: float) -> None:
        pass

MAP_LAYER_NONE = 0x0
MAP_LAYER_TILES = 0x1
MAP_LAYER_OBJECT = 0x2
MAP_LAYER_ACTOR = 0x4
MAP_LAYER_ALL = 0xff_ff

class Map:
    CELL_SIZE: int = 7
    def __init__(self, path: str|Path) -> Map:
        pygame.init()
        self.__start = (0, 0)
        image = pygame.image.load(path)
        self.__size = image.get_size()
        self.__tiles = [ ]
        self.__objects = [ ]
        self.__actors = [ ]
        pixels = pygame.PixelArray(image)
        for i in range(image.get_height()):
            for j in range(image.get_width()):
                color = pygame.Color(image.unmap_rgb(pixels[j, i]))
                if color == pygame.Color(255, 255, 255):
                    self.__tiles.append(Nothing())
                elif color == pygame.Color(255, 0, 0):
                    self.__start = (j, i)
                    self.__tiles.append(Nothing())
                else:
                    self.__tiles.append(Wall(color))
    def width(self) -> int:
        return self.__size[0]
    def height(self) -> int:
        return self.__size[1]
    def add_actor(self, actor: Actor) -> None:
        self.__actors.append(actor)
    def add_object(self, obj: Object) -> None:
        self.__objects.append(obj)
    def sprites(self) -> tuple[Actor|Object]:
        return tuple(self.__actors + self.__objects)
    def at(self, coords: tuple[int, int], layers: int = MAP_LAYER_ALL):
        x, y = coords
        if layers & MAP_LAYER_ACTOR != 0:
            for actor in self.__actors:
                position = (int(actor.position()[0]), int(actor.position()[1]))
                if position == tuple(coords):
                    return (actor, MAP_LAYER_ACTOR)
        if layers & MAP_LAYER_OBJECT != 0:
            for obj in self.__objects:
                position = (int(obj.position()[0]), int(obj.position()[1]))
                if position == tuple(coords):
                    return (obj, MAP_LAYER_OBJECT)
        if layers & MAP_LAYER_TILES != 0:
            return (self.__tiles[y * self.width() + x], MAP_LAYER_TILES)
        return (Nothing(), MAP_LAYER_NONE)
    def start(self) -> tuple[float, float]:
        return (self.__start[0] + 0.5, self.__start[1] + 0.5)
    def update(self, dt: float) -> None:
        for actor in self.__actors:
            actor.update(dt)

class Player(Actor):
    def __init__(self, position: tuple[float, float], world_scale: tuple[float, float] = (1, 1),
                 vertical_offset: float = 0.5, fov: float = 90) -> Player:
        super().__init__(position, world_scale=world_scale, vertical_offset=vertical_offset, fov=fov)
        self.__weapon = None
    def attach_weapon_animation(self, weapon: Animation) -> None:
        self.__weapon = weapon
    def weapon(self) -> Animation:
        return self.__weapon
    def update(self, dt: float) -> None:
        self.__weapon.update(dt)

class Enemy(Actor):
    STATE_WALKING = 0
    STATE_HIT = 1
    STATE_DYING = 2
    STATE_DEAD = 3
    def __init__(self, position: tuple[float, float], world_scale: tuple[float, float] = (1, 1),
                 vertical_offset: float = 0.5, fov: float = 90) -> Player:
        super().__init__(position, world_scale=world_scale, vertical_offset=vertical_offset, fov=fov)
        self._hp = 4
        self.__current = None
        self.__walking = None
        self.__dying = None
        self.__dying_sound = None
        self.__hit = None
        self.__state = Enemy.STATE_WALKING
    def attach_walking_animation(self, walking: Animation) -> None:
        self.__walking = walking
    def attach_dying_animation(self, dying: Animation) -> None:
        self.__dying = dying
    def attach_hit_animation(self, hit: Animation) -> None:
        self.__hit = hit
    def attach_dying_sound(self, dying: pygame.mixer.Sound) -> None:
        self.__dying_sound = dying
    def walking(self) -> Animation:
        return self.__walking
    def dying(self) -> Animation:
        return self.__dying
    def hit(self) -> Animation:
        return self.__hit
    def set_state(self, state: int) -> None:
        self.__state = state
        if self.__current is not None:
            self.__current.reset()
        if self.__state == Enemy.STATE_WALKING:
            self.__current = self.__walking
        elif self.__state == Enemy.STATE_DYING:
            self.__current = self.__dying
            self.__dying_sound.play()
        elif self.__state == Enemy.STATE_HIT:
            self.__current = self.__hit
        elif self.__state == Enemy.STATE_DEAD:
            self.__current = self.__dying
            self.__current.stop()
            self.__current.set_frame(len(self.__dying) - 1)
        else:
            self.__current = None
        if self.__current is not None and self.__state != Enemy.STATE_DEAD:
            self.__current.play()
    def state(self) -> int:
        return self.__state
    def update(self, dt: float) -> None:
        if self.__current is not None:
            self.__current.update(dt)
        if not self.__current.is_playing():
            if self.__state == Enemy.STATE_HIT:
                self.set_state(Enemy.STATE_WALKING)
            elif self.__state == Enemy.STATE_DYING:
                self.set_state(Enemy.STATE_DEAD)
    def texture_id(self) -> int:
        return self.__current.frame()
    def is_physics_solid(self) -> bool:
        return self.__state != Enemy.STATE_DEAD
    def damage(self) -> None:
        self._hp = self._hp - 1
        if self._hp > 0:
            self.set_state(Enemy.STATE_HIT)
        else:
            self.set_state(Enemy.STATE_DYING)

class Ray:
    def __init__(self, origin: tuple[float, float], direction: tuple[float, float], max_distance: float = float("inf"),
                 layers: int = MAP_LAYER_ALL, automaps: bool = True) -> Ray:
        self.__origin = origin
        self.__direction = direction
        self.__max_distance = max_distance
        self.__layers = layers & MAP_LAYER_ALL
        self.__automaps = automaps
    def origin(self) -> tuple[float, float]:
        return self.__origin
    def direction(self) -> tuple[float, float]:
        return self.__direction
    def max_distance(self) -> float:
        return self.__max_distance
    def layers(self) -> int:
        return self.__layers
    def automaps(self) -> bool:
        return self.__automaps

@dataclass
class RayHit:
    distance: float = 0.0
    perspective_distance: float = 0.0
    layer: int  = MAP_LAYER_NONE
    point: tuple[float, float] = (0.0, 0.0)
    side: int = 0
    queryable: RayQueryable = None

SIDE_X = 0
SIDE_Y = 1

@dataclass
class DDAInfo:
    side_distance: tuple[float, float]
    delta: tuple[float, float]
    index: tuple[int, int]
    step: tuple[int, int]

def dda(ray: Ray, map: Map, info: DDAInfo) -> RayHit:
    queryable = Nothing()
    side = SIDE_X
    distance = 0
    steps = 0
    while not queryable.is_solid():
        if info.side_distance[SIDE_X] < info.side_distance[SIDE_Y]:
            side = SIDE_X
        else:
            side = SIDE_Y
        info.side_distance[side] = info.side_distance[side] + info.delta[side]
        info.index[side] = info.index[side] + info.step[side]
        distance = distance + min(info.side_distance)
        if (info.index[SIDE_X] >= 0 and info.index[SIDE_X] < map.width() and info.index[SIDE_Y] >= 0 and
            info.index[SIDE_Y] < map.height() and distance < ray.max_distance()):
            queryable, layer = map.at(info.index, layers=ray.layers())
            if ray.automaps():
                queryable.hit()
        else:
            queryable = Something()
            layer = MAP_LAYER_NONE
        steps = steps + 1
        if steps > 40:
            queryable = Something()
            layer = MAP_LAYER_NONE
            break
    if side == SIDE_X:
        perspective_distance = (info.index[SIDE_X] - ray.origin()[SIDE_X] + (1 - info.step[SIDE_X]) / 2)
        perspective_distance = perspective_distance / ray.direction()[SIDE_X]
    else:
        perspective_distance = (info.index[SIDE_Y] - ray.origin()[SIDE_Y] + (1 - info.step[SIDE_Y]) / 2)
        perspective_distance = perspective_distance / ray.direction()[SIDE_Y]
    perspective_distance = math.fabs(perspective_distance)
    hx = ray.origin()[SIDE_X] + ray.direction()[SIDE_X] * perspective_distance
    hy = ray.origin()[SIDE_Y] + ray.direction()[SIDE_Y] * perspective_distance
    return RayHit(distance, perspective_distance, layer, (hx, hy), side, queryable)

def raycast(ray: Ray, map: Map) -> RayHit|None:
    index = [ int(ray.origin()[0]), int(ray.origin()[1]) ]
    delta = [ 1e30, 1e30 ]
    if ray.direction()[0] != 0:
        delta[0] = math.fabs(1 / ray.direction()[0])
    if ray.direction()[1] != 0:
        delta[1] = math.fabs(1 / ray.direction()[1])
    step = [ 0, 0 ]
    side_distance = [ 0, 0 ]
    if ray.direction()[0] < 0:
        step[0] = -1
        side_distance[0] = (ray.origin()[0] - index[0]) * delta[0]
    else:
        step[0] = 1
        side_distance[0] = (index[0] + 1.0 - ray.origin()[0]) * delta[0]
    if ray.direction()[1] < 0:
        step[1] = -1
        side_distance[1] = (ray.origin()[1] - index[1]) * delta[1]
    else:
        step[1] = 1
        side_distance[1] = (index[1] + 1.0 - ray.origin()[1]) * delta[1]
    info = DDAInfo(side_distance, delta, index, step)
    return dda(ray, map, info)

class Texture:
    def __init__(self, path: str|Path|pygame.Surface) -> Texture:
        if isinstance(path, pygame.Surface):
            texture = path
        else:
            texture = pygame.image.load(path)
        self.__surface = pygame.surface.Surface(texture.get_size(), flags=pygame.SRCALPHA)
        self.__surface.blit(texture, (0, 0))
        self.__r = pygame.surfarray.pixels_red(self.__surface)
        self.__g = pygame.surfarray.pixels_green(self.__surface)
        self.__b = pygame.surfarray.pixels_blue(self.__surface)
        self.__a = pygame.surfarray.pixels_alpha(self.__surface)
    def width(self) -> int:
        return self.__surface.get_width()
    def height(self) -> int:
        return self.__surface.get_height()
    def sample(self, coords: tuple[float, float]) -> tuple[int, int, int, int]:
        u, v = coords
        u = clamp(u, 0.0, 1.0)
        v = clamp(v, 0.0, 1.0)
        tx = int(u * (self.__surface.get_width() - 1))
        ty = int(v * (self.__surface.get_height() - 1))
        r = self.__r[tx, ty]
        g = self.__g[tx, ty]
        b = self.__b[tx, ty]
        a = self.__a[tx, ty]
        return (int(r), int(g), int(b), int(a))
    def affine_map(self, pixels: numpy.ndarray, x: int, y0: float, y1: float, u: float, top: float, height: float, brightness: float|None = None, radius: float|None = None) -> None:
        if y0 >= y1:
            return
        start = max(int(y0), 0)
        end = min(int(y1), pixels.shape[1] - 1)
        if start > end:
            return
        t = 1.0 / height
        v = (start - top) * t
        for i in range(start, end + 1):
            r, g, b, a = self.sample((u, max(0.0, v)))
            v = v + t
            if a == 0:
                continue
            if LIGHTING:
                if brightness is not None:
                    if (radius is None or
                        not (x - pixels.shape[0] // 2) ** 2 + (i - pixels.shape[1] // 2) ** 2 <= radius ** 2):
                        r, g, b = darken((r, g, b), brightness, 0.1)
            pixels[x, i] = (a << 24) | (r << 16) | (g << 8) | b

class World:
    def __init__(self, map: Map, sky: pygame.Color, floor: pygame.Color, fov: float = 90) -> World:
        self.__map = map
        self.__sky = sky
        self.__floor = floor
        self.__player = Player(self.__map.start(), fov=fov)
        self.__map.add_actor(self.__player)
        self.__textures = [ ]
        self.__atlas = { }
        self.__show_map = False
    def player(self) -> Player:
        return self.__player
    def map(self) -> Map:
        return self.__map
    def toggle_map(self) -> None:
        self.__show_map = not self.__show_map
    def load_texture(self, path: str|Path|pygame.Surface) -> int:
        res = len(self.__textures)
        self.__textures.append(Texture(path))
        return res
    def update(self, dt: float) -> None:
        self.__map.update(dt)
    def use_texture_atlas(self, atlas: dict[pygame.Color, int]) -> None:
        self.__atlas = atlas
    def physics_collides(self, actor: Actor) -> bool:
        layers = MAP_LAYER_TILES | MAP_LAYER_OBJECT | MAP_LAYER_ACTOR
        direction = (actor.direction()[0] + actor.plane()[0], actor.direction()[1] + actor.plane()[1])
        forward = direction
        left = rotate(direction, 3 * math.pi / 2)
        right = rotate(direction, math.pi / 2)
        backward = rotate(direction, math.pi)
        ray = Ray(actor.position(), forward, layers=layers, automaps=False)
        hit = raycast(ray, self.__map)
        res = hit.queryable.is_physics_solid() and hit.perspective_distance < 0.125
        ray = Ray(actor.position(), backward, layers=layers, automaps=False)
        hit = raycast(ray, self.__map)
        res = res or (hit.queryable.is_physics_solid() and hit.perspective_distance < 0.125)
        ray = Ray(actor.position(), left, layers=layers, automaps=False)
        hit = raycast(ray, self.__map)
        res = res or (hit.queryable.is_physics_solid() and hit.perspective_distance < 0.125)
        ray = Ray(actor.position(), right, layers=layers, automaps=False)
        hit = raycast(ray, self.__map)
        res = res or (hit.queryable.is_physics_solid() and hit.perspective_distance < 0.125)
        return res
    def draw(self, target: pygame.surface.Surface) -> None:
        direction = self.__player.direction()
        plane = self.__player.plane()
        position = self.__player.position()

        target.fill(self.__sky, pygame.Rect((0, 0), (target.get_width(), target.get_height() // 2)))
        target.fill(self.__floor,
                    pygame.Rect((0, target.get_height() // 2), (target.get_width(), target.get_height() // 2)))
        zbuffer = [ float("inf") ] * target.get_width()
        sprites = self.__map.sprites()
        billboards = [ ]
        for sprite in sprites:
            if sprite is self.__player:
                continue
            dx, dy = sub(sprite.position(), position)
            transform_y = dot((dx, dy), direction)
            if transform_y <= 0.3 or transform_y >= 32:
                continue
            transform_x = dot((dx, dy), plane)
            billboards.append((sprite, (transform_x, transform_y)))
        billboards.sort(key=lambda billboard: billboard[1][1], reverse=True)
        pixels = pygame.surfarray.pixels2d(target)
        rad = min(target.get_size()) // 4
        if LIGHTING:
            if self.player().is_using_light():
                bb = pygame.Rect(0, 0, rad * 2, rad * 2)
                bb.center = target.get_rect().center
                for i in range(bb.top, bb.bottom):
                    for j in range(bb.left, bb.right):
                        if (j - bb.centerx) ** 2 + (i - bb.centery) ** 2 <= rad ** 2:
                            a = ((pixels[j, i] & 0xff_00_00_00) >> 24)
                            r = ((pixels[j, i] & 0xff_00_00) >> 16) << 2
                            g = ((pixels[j, i] & 0xff_00) >> 8) << 2
                            b = (pixels[j, i] & 0xff) << 2
                            pixels[j, i] = (a << 24) | (r << 16) | (g << 8) | b
        for i in range(target.get_width()):
            x = 2 * i / target.get_width() - 1
            ray = Ray(position, (direction[0] + plane[0] * x, direction[1] + plane[1] * x), layers=MAP_LAYER_TILES, max_distance=256)
            hit = raycast(ray, self.__map)
            zbuffer[i] = hit.perspective_distance
            if not hasattr(hit.queryable, "color"):
                continue
            color = pygame.Color(hit.queryable.color())
            column_height = target.get_height() // hit.perspective_distance
            top = target.get_height() / 2 - column_height / 2
            begin = -column_height // 2 + target.get_height() // 2
            if begin < 0:
                begin = 0
            end = column_height // 2 + target.get_height() // 2
            if end >= target.get_height():
               end = target.get_height() - 1
            texture = self.__textures[self.__atlas[int(color)]]
            hx, hy = hit.point
            u = 0.0
            if hit.side == SIDE_X:
                u = hy - math.floor(hy)
            else:
                u = hx - math.floor(hx)
            if ((hit.side == SIDE_X and ray.direction()[SIDE_X] < 0) or
                (hit.side == SIDE_Y and ray.direction()[SIDE_Y] > 0)):
                u = 1.0 - u
            brightness = 1 / (4 + 0.5 * hit.perspective_distance)
            if self.player().is_using_light():
                mrad = rad
            else:
                mrad = None
            texture.affine_map(pixels, i, begin, end, u, top, column_height, brightness, mrad)
        for billboard in billboards:
            sprite, (tx, ty) = billboard
            sx = (target.get_width() / 2) * (1 + tx / ty)
            height = math.fabs(target.get_height() / ty) * sprite.height()
            width = math.fabs(target.get_height() / ty) * sprite.width()
            bottom = (target.get_height() / 2) + (target.get_height() / ty) * sprite.vertical_offset()
            top = bottom - height
            begin_y = clamp(top, 0, target.get_height() - 1)
            end_y = clamp(bottom, 0, target.get_height() - 1)
            begin_x = clamp(sx - width / 2, 0, target.get_width() - 1)
            end_x = clamp(sx + width / 2, 0, target.get_width() - 1)
            for i in range(int(begin_x), int(end_x) + 1):
                if ty > zbuffer[i]:
                    continue
                zbuffer[i] = ty
                texture = self.__textures[sprite.texture_id()]
                u = (i - (sx - width / 2)) / width
                brightness = 1 / (4 + 0.5 * ty)
                if self.player().is_using_light():
                    mrad = rad
                else:
                    mrad = None
                texture.affine_map(pixels, i, top, bottom, u, top, height, brightness, mrad)
        del pixels
        target.blit(self.__player.weapon().frame(),
                    (target.get_width() // 2 - self.__player.weapon().frame().get_width() // 6,
                     target.get_height() - self.__player.weapon().frame().get_height()))
        if self.__show_map:
            minimap = pygame.surface.Surface((self.__map.width(), self.__map.height()), flags=pygame.SRCALPHA)
            minimap.fill(pygame.Color(0, 0, 0))
            pixels = pygame.surfarray.pixels2d(minimap)
            for i in range(self.__map.height()):
                for j in range(self.__map.width()):
                    tile, _ = self.__map.at((j, i), layers=MAP_LAYER_TILES)
                    a = 0
                    r = 0
                    g = 0
                    b = 0
                    if tile.is_seen():
                        a = 191
                        r = 255
                        g = 255
                        b = 255
                        if tile.is_solid():
                            r = tile.color().r
                            g = tile.color().g
                            b = tile.color().b
                    pixels[j, i] = (a << 24) | (r << 16) | (g << 8) | b
            x, y = position
            if x < self.__map.width() and x >= 0 and y < self.__map.height() and y >= 0:
                pixels[int(x), int(y)] = (191 << 24) | (0xff << 16)
            del pixels
            scaleby = min(target.get_size()) // min(minimap.get_size())
            scaled = pygame.transform.scale_by(minimap, scaleby)
            target.blit(scaled, (target.get_width() // 2 - scaled.get_width() // 2,  target.get_height() // 2 - scaled.get_height() // 2))
    def hitscan(self, ray: Ray) -> RayHit:
        return raycast(ray, self.__map)
