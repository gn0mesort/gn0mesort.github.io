import pygame

WIDTH = 640
HEIGHT = 480
STEP_TIME = 1 / 24

def remap(x: float, start: tuple[float, float], end: tuple[float, float]) -> float:
    a, b = start
    c, d = end
    return c + (x - a) * (d - c) / (b - a)

def dda(target: pygame.surface.Surface, start: tuple[float, float], end: tuple[float, float]) -> None:
    pixels = pygame.PixelArray(target)
    x1, y1 = start
    x2, y2 = end
    dx = x2 - x1
    dy = y2 - y1
    steps = max(abs(dx), abs(dy))
    xinc = dx / steps
    yinc = dy / steps
    x, y = start
    for i in range(steps + 1):
        pixels[int(x), int(y)] = pygame.Color(255, 0, 255)
        x = x + xinc
        y = y + yinc
    pixels[x1, y1] = pygame.Color(0, 0, 255)
    pixels.close()

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
target = pygame.surface.Surface((64, 64))
target.fill(pygame.Color(255, 255, 255))
quitting = False
start = target.get_rect().center
clock = pygame.time.Clock()
i = 0
dt = 0
acc = 0
paused = True
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_r:
                target.fill(pygame.Color(255, 255, 255))
        if event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                x, y = event.pos
                if x < 0 or x >= screen.get_width() or y < 0 or y >= screen.get_height():
                    continue
                x = remap(x, (0, screen.get_width() - 1), (0, target.get_width() - 1))
                y = remap(y, (0, screen.get_height() - 1), (0, target.get_height() - 1))
                dda(target, start, (int(x), int(y)))
    scaled = pygame.transform.scale(target, screen.get_size())
    screen.blit(scaled, (0, 0))
    pygame.display.flip()
    dt = clock.tick() / 1000
    acc = acc + dt
pygame.quit()


