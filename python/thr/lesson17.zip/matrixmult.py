from __future__ import annotations

class Matrix:
    def __init__(self, width: int, height: int):
        self.__data = [ 0 ] * (width * height)
        self.__pitch = width
        self.__height = height
    def set_all(self, iterable) -> None:
        x = 0
        y = 0
        for value in iterable:
            self[(x, y)] = value
            x = x + 1
            if x >= self.__pitch:
                x = 0
                y = y + 1
            if y >= self.__height:
                return
    def width(self) -> int:
        return self.__pitch
    def height(self) -> int:
        return self.__height
    def __getitem__(self, index: tuple[int, int]) -> int:
        x, y = index
        return self.__data[y * self.__pitch + x]
    def __setitem__(self, index: tuple[int, int], value: int) -> None:
        x, y = index
        self.__data[y * self.__pitch + x] = value
    def __mul__(self, rhs: Matrix) -> Matrix:
        res = Matrix(rhs.width(), self.__height)
        total = 0
        for i in range(self.__height):
            for j in range(self.__pitch):
                total = 0
                for k in range(self.__height):
                    total = total + self[(k, i)] * rhs[(j, k)]
                res[(j, i)] = total
        return res
    def __matmul__(self, rhs: Matrix) -> Matrix:
        return self * rhs
    def __repr__(self) -> str:
        temp = [ "[ " ]
        for i in range(self.__height):
            for j in range(self.__pitch):
                if i > 0 and j == 0:
                    temp.append("  ")
                temp.append(str(self[(j, i)]))
                if j + 1 <  self.__pitch or (j + 1 == self.__pitch and i + 1 < self.__height):
                    temp.append(", ")
            if i + 1 < self.__height:
                temp.append("\n")
        temp.append(" ]")
        return "".join(temp)

a = Matrix(2, 2)
a.set_all((1, 2, 3, 4))
b = Matrix(2, 2)
b.set_all((5, 6, 7, 8))
print(a * b)
print(b @ a)
