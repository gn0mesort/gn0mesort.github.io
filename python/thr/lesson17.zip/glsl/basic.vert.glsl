#version 450 core
// FIXME: We need to declare our uniforms, inputs, and outputs here.

void main() {
    // FIXME: We need to determine where our object is in the world first.
    // Then, we need to output that position, and the input color to the fragment shader.
    // Then, we need to calculate the final position of our object on the screen.
}
