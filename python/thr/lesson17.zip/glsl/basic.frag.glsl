#version 450 core
// FIXME: We need to declare our uniforms, inputs, and outputs here.

bool is_almost_equal(const float a, const float b, const float absolute_tolerance) {
    if (a == b)
    {
        return true;
    }
    else if (isinf(a) || isinf(b))
    {
        return false;
    }
    return abs(b - a) <= absolute_tolerance;
}

float gamma(const float l) {
    if (l > 0.0031308 && !is_almost_equal(l, 0.0031308, 1e-8))
    {
        return 1.055 * pow(l, 1.0 / 2.4) - 0.055;
    }
    return 12.92 * l;
}

vec4 gamma(const vec4 l) {
    return vec4(gamma(l.r), gamma(l.g), gamma(l.b), l.a);
}

void main() {
    // FIXME: We need to determine how far away our camera is from the rendered object
    // Then, we need to calculate how bright the object should be based on that distance.
    // Finally, we multiply the input color by the brightness to get the output color.
}
