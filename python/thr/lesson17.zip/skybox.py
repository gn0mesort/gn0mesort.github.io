from pathlib import Path

import numpy
import moderngl
import pygame
from pyglm import glm

from camera import Camera

_skybox = numpy.array((
        -1.0, -1.0, -1.0,
         1.0,  1.0, -1.0,
         1.0, -1.0, -1.0,
         1.0,  1.0, -1.0,
        -1.0, -1.0, -1.0,
        -1.0,  1.0, -1.0,

        -1.0, -1.0,  1.0,
         1.0, -1.0,  1.0,
         1.0,  1.0,  1.0,
         1.0,  1.0,  1.0,
        -1.0,  1.0,  1.0,
        -1.0, -1.0,  1.0,

        -1.0,  1.0,  1.0,
        -1.0,  1.0, -1.0,
        -1.0, -1.0, -1.0,
        -1.0, -1.0, -1.0,
        -1.0, -1.0,  1.0,
        -1.0,  1.0,  1.0,

        1.0,  1.0,  1.0,
        1.0, -1.0, -1.0,
        1.0,  1.0, -1.0,
        1.0, -1.0, -1.0,
        1.0,  1.0,  1.0,
        1.0, -1.0,  1.0,

        -1.0, -1.0, -1.0,
         1.0, -1.0, -1.0,
         1.0, -1.0,  1.0,
         1.0, -1.0,  1.0,
        -1.0, -1.0,  1.0,
        -1.0, -1.0, -1.0,

        -1.0,  1.0, -1.0,
         1.0,  1.0,  1.0,
         1.0,  1.0, -1.0,
         1.0,  1.0,  1.0,
        -1.0,  1.0, -1.0,
        -1.0,  1.0,  1.0))
_ready = False
_shader = None
_vertex_src = """
#version 450 core
layout (location = 0) uniform mat4 model;
layout (location = 1) uniform mat4 view;
layout (location = 2) uniform mat4 projection;

layout (location = 0) in vec3 i_position;

layout (location = 0) out vec3 o_direction;

void main() {
    o_direction = normalize(i_position);
    gl_Position = (projection * mat4(mat3(view)) * vec4(i_position, 1));
}
""".strip()
_fragment_src = """
#version 450 core
#define PI 3.1415926538

layout (location = 3) uniform sampler2D panorama;

layout (location = 0) in vec3 i_direction;

layout (location = 0) out vec4 color_0;

void main() {
    const vec3 direction = i_direction;
    const float u = 0.5 + atan(direction.z, direction.x) / (2.0 * PI);
    const float v = 0.5 - asin(direction.y) / PI;
    color_0 = vec4(texture(panorama, vec2(u, v)).rgb, 1);
}
""".strip()
_vbo = None
_vao = None
_panorama = None

def load(gl: moderngl.Context, path: str|Path) -> None:
    global _panorama
    surface = pygame.image.load(path)
    bin = pygame.image.tobytes(surface, "RGBA")
    _panorama = gl.texture(surface.get_size(), 4, bin)
    _panorama.filter = (moderngl.NEAREST, moderngl.LINEAR)
    _panorama.repeat_x = False
    _panorama.repeat_y = False
    _panorama.anisotropy = 4


def render(gl: moderngl.Context, camera: Camera, projection: glm.mat4) -> None:
    global _ready
    global _shader
    global _vbo
    global _vao
    global _panorama
    if not _ready:
        _shader = gl.program(vertex_shader=_vertex_src, fragment_shader=_fragment_src)
        _vbo = gl.buffer(_skybox.astype("f4").tobytes())
        _vao = gl.vertex_array(_shader, _vbo, "i_position")
        _ready = True
    prev_cull = gl.cull_face
    gl.cull_face = "front"
    gl.disable(moderngl.DEPTH_TEST)
    _shader["view"].write(camera.look())
    _shader["projection"].write(projection)
    _panorama.use()
    _vao.render()
    gl.enable(moderngl.DEPTH_TEST)
    gl.cull_face = prev_cull
