#version 450 core

layout(location = 1) in vec3 i_color;

layout(location = 0) out vec4 color_0;

void main() {
  color_0 = vec4(i_color, 1);
}
