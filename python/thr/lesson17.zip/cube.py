from pathlib import Path

import pygame
import numpy
import moderngl
from pyglm import glm

from camera import Camera
from controller import Controller
import glu
import skybox

WIDTH = 640
HEIGHT = 360
CAMERA_SPEED = 1
CAMERA_ROTATION_THETA = 90

def load_shader(path: str|Path) -> str:
    res = None
    try:
        file = open(path, "rb")
        res = file.read().decode("utf-8").strip()
    finally:
        file.close()
    return res

vertex_src = load_shader("glsl/basic.vert.glsl")

fragment_src = load_shader("glsl/basic.frag.glsl")

vertices = numpy.array((
        -0.5, -0.5, -0.5, 1.0, 0.0, 0.0,
         0.5,  0.5, -0.5, 1.0, 0.0, 0.0,
         0.5, -0.5, -0.5, 1.0, 0.0, 0.0,
         0.5,  0.5, -0.5, 1.0, 0.0, 0.0,
        -0.5, -0.5, -0.5, 1.0, 0.0, 0.0,
        -0.5,  0.5, -0.5, 1.0, 0.0, 0.0,

        -0.5, -0.5,  0.5, 0.0, 1.0, 0.0,
         0.5, -0.5,  0.5, 0.0, 1.0, 0.0,
         0.5,  0.5,  0.5, 0.0, 1.0, 0.0,
         0.5,  0.5,  0.5, 0.0, 1.0, 0.0,
        -0.5,  0.5,  0.5, 0.0, 1.0, 0.0,
        -0.5, -0.5,  0.5, 0.0, 1.0, 0.0,

        -0.5,  0.5,  0.5, 0.0, 0.0, 1.0,
        -0.5,  0.5, -0.5, 0.0, 0.0, 1.0,
        -0.5, -0.5, -0.5, 0.0, 0.0, 1.0,
        -0.5, -0.5, -0.5, 0.0, 0.0, 1.0,
        -0.5, -0.5,  0.5, 0.0, 0.0, 1.0,
        -0.5,  0.5,  0.5, 0.0, 0.0, 1.0,

        0.5,  0.5,  0.5, 1.0, 0.0, 1.0,
        0.5, -0.5, -0.5, 1.0, 0.0, 1.0,
        0.5,  0.5, -0.5, 1.0, 0.0, 1.0,
        0.5, -0.5, -0.5, 1.0, 0.0, 1.0,
        0.5,  0.5,  0.5, 1.0, 0.0, 1.0,
        0.5, -0.5,  0.5, 1.0, 0.0, 1.0,

        -0.5, -0.5, -0.5, 1.0, 1.0, 0.0,
         0.5, -0.5, -0.5, 1.0, 1.0, 0.0,
         0.5, -0.5,  0.5, 1.0, 1.0, 0.0,
         0.5, -0.5,  0.5, 1.0, 1.0, 0.0,
        -0.5, -0.5,  0.5, 1.0, 1.0, 0.0,
        -0.5, -0.5, -0.5, 1.0, 1.0, 0.0,

        -0.5,  0.5, -0.5, 0.0, 1.0, 1.0,
         0.5,  0.5,  0.5, 0.0, 1.0, 1.0,
         0.5,  0.5, -0.5, 0.0, 1.0, 1.0,
         0.5,  0.5,  0.5, 0.0, 1.0, 1.0,
        -0.5,  0.5, -0.5, 0.0, 1.0, 1.0,
        -0.5,  0.5,  0.5, 0.0, 1.0, 1.0))
controller = Controller()
controller.map_action("left", (pygame.K_a, pygame.K_LEFT))
controller.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controller.map_action("forward", (pygame.K_w, pygame.K_UP))
controller.map_action("backward", (pygame.K_s, pygame.K_DOWN))
controller.map_action("turnl", (pygame.K_q,))
controller.map_action("turnr", (pygame.K_e,))
pygame.init()
footstep = pygame.mixer.Sound("step.ogg")
footstep.set_volume(1 / 3)
hmm = pygame.mixer.Sound("hmm.ogg")
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 4)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 5)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE)
pygame.display.set_mode((WIDTH, HEIGHT), pygame.DOUBLEBUF | pygame.OPENGL)
gl = moderngl.get_context()
gl.enable(gl.DEPTH_TEST)
clock = pygame.time.Clock()
quitting = False
culling = False
shader = gl.program(vertex_shader=vertex_src, fragment_shader=fragment_src)
vbo = gl.buffer(vertices.astype("f4").tobytes())
vao = gl.vertex_array(shader, vbo, "i_position", "i_color")
projection = glm.perspective(glm.radians(60), WIDTH / HEIGHT, 0.1, 1000.0)
camera = Camera(glm.vec3(0.0, 0.0, 2.0))
model = glm.mat4()
skybox.load(gl, "sky.webp")
dt = 0.0
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE and hmm.get_num_channels() == 0:
                hmm.play()
            if event.key == pygame.K_TAB:
                gl.wireframe = not gl.wireframe
            if event.key == pygame.K_BACKQUOTE:
                if not culling:
                    gl.cull_face = "back"
                    gl.enable(moderngl.CULL_FACE)
                else:
                    gl.disable(moderngl.CULL_FACE)
                culling = not culling
        controller.update(event)
    if controller.is_action_pressed("forward"):
        camera.move_forward(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("backward"):
        camera.move_backward(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("left"):
        camera.move_left(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("right"):
        camera.move_right(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("turnl"):
        camera.turn_left(glm.radians(CAMERA_ROTATION_THETA * dt))
    if controller.is_action_pressed("turnr"):
        camera.turn_right(glm.radians(CAMERA_ROTATION_THETA * dt))
    model = glm.rotate(model, glm.radians(CAMERA_ROTATION_THETA * dt), glm.vec3(1, 0, 0))
    model = glm.rotate(model, glm.radians(CAMERA_ROTATION_THETA * dt), glm.vec3(0, 0, 1))
    gl.clear(glu.gamma(0.2), glu.gamma(0.2), glu.gamma(0.2), 1.0, depth=2.0)
    skybox.render(gl, camera, projection)
    shader["model"].write(model)
    shader["view"].write(camera.look())
    shader["projection"].write(projection)
    shader["camera_pos"].write(camera.position())
    vao.render()
    pygame.display.flip()
    dt = clock.tick() / 1000
vbo.release()
vao.release()
shader.release()
pygame.quit()
