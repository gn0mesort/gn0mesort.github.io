import pygame

WIDTH = 640
HEIGHT = 480
STEP_TIME = 1 / 24

def dda(target: pygame.surface.Surface, start: tuple[float, float], end: tuple[float, float]) -> None:
    pixels = pygame.PixelArray(target)
    x1, y1 = start
    x2, y2 = end
    dx = x2 - x1
    dy = y2 - y1
    steps = max(abs(dx), abs(dy))
    xinc = dx / steps
    yinc = dy / steps
    x, y = start
    for i in range(steps + 1):
        pixels[int(x), int(y)] = pygame.Color(255, 0, 255)
        x = x + xinc
        y = y + yinc
    pixels[x1, y1] = pygame.Color(0, 0, 255)
    pixels.close()

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
target = pygame.surface.Surface((64, 64))
quitting = False
start = target.get_rect().center
clock = pygame.time.Clock()
i = 0
dt = 0
acc = 0
paused = True
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_p:
                paused = not paused
    if i == 0:
        target.fill(pygame.Color(255, 255, 255))
    while acc >= STEP_TIME:
        if not paused:
            end = (i, 0)
            i = (i + 1) % target.get_width()
            dda(target, start, end)
        acc = acc - STEP_TIME
    scaled = pygame.transform.scale(target, screen.get_size())
    screen.blit(scaled, (0, 0))
    pygame.display.flip()
    dt = clock.tick() / 1000
    acc = acc + dt
pygame.quit()


