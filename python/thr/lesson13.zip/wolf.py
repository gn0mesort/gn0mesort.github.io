import pygame
import pygame.freetype

from raycast import *
from controller import Controller

WIDTH = 640
HEIGHT = 480
MAX_FPS = 300

TURN_THETA = 25 * 0.08726646
MOVE_SPEED = 4

ASPECT_4_3 = 0
ASPECT_16_9 = 1

def aspect() -> int:
    if WIDTH / 16 == WIDTH // 16 and HEIGHT / 9 == HEIGHT // 9:
        return ASPECT_16_9
    if WIDTH / 4 == WIDTH // 4 and HEIGHT / 3 == HEIGHT // 3:
        return ASPECT_4_3

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
ar = aspect()
fov = 106
if ar == ASPECT_4_3:
    fov = 75
typeface = pygame.freetype.Font("nec.ttf", 12)
typeface.bgcolor = pygame.Color(0, 0, 0, 128)
typeface.fgcolor = pygame.Color(255, 255, 0, 255)
clock = pygame.time.Clock()
dt = 0
fps, _ = typeface.render("0000.00 Hz")
location, _ = typeface.render("x = 0, y = 0, yaw = 0")
controls = Controller()
controls.map_action("forward", (pygame.K_w, pygame.K_UP))
controls.map_action("backward", (pygame.K_s, pygame.K_DOWN))
controls.map_action("left", (pygame.K_a, pygame.K_LEFT))
controls.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controls.map_action("turnl", (pygame.K_q,))
controls.map_action("turnr", (pygame.K_e,))
world = World(Map("e1m1.webp"), pygame.Color(56, 56, 56), pygame.Color(113, 113, 113), fov=fov)
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        controls.update(event)
    theta = 0
    if controls.is_action_pressed("turnl"):
        theta = -TURN_THETA
    elif controls.is_action_pressed("turnr"):
        theta = TURN_THETA
    world.player().pivot(theta * dt)
    speed = 0
    if controls.is_action_pressed("forward"):
        speed = MOVE_SPEED
    elif controls.is_action_pressed("backward"):
        speed = -MOVE_SPEED
    world.player().walk(speed * dt)
    speed = 0
    if controls.is_action_pressed("left"):
        speed = -MOVE_SPEED
    elif controls.is_action_pressed("right"):
        speed = MOVE_SPEED
    world.player().strafe(speed * dt)
    screen.fill(pygame.Color(51, 51, 51))
    world.draw(screen)
    screen.blit(fps, (5, 5))
    screen.blit(location, (5, 15))
    pygame.display.flip()
    dt = clock.tick(MAX_FPS) / 1000
    fps, _ = typeface.render(f"{clock.get_fps():04.02f} Hz")
    location, _ = typeface.render(f"x = {world.player().position()[0]:04.02f}, y = {world.player().position()[1]:04.02f}, yaw = {degrees(world.player().yaw()):04.02f}")
