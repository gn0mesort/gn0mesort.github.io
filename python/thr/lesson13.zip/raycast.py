from __future__ import annotations

import math
from pathlib import Path
from dataclasses import dataclass
from abc import abstractmethod

import pygame

def radians(degrees: float) -> float:
    return degrees * math.pi / 180

def degrees(radians: float) -> float:
    return radians * 180 / math.pi

def sub(a: tuple[float, float], b: tuple[float, float]) -> tuple[float, float]:
    return (a[0] - b[0], a[1] - b[1])

def dot(a: tuple[float, float], b: tuple[float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1]

def clamp(v, lo, hi):
    return min(max(v, lo), hi)

def rotate(direction: tuple[float, float], theta: float) -> tuple[float, float]:
    x = direction[0] * math.cos(theta) - direction[1] * math.sin(theta)
    y = direction[0] * math.sin(theta) + direction[1] * math.cos(theta)
    return (x, y)

def walk(position: tuple[float, float], direction: tuple[float, float], speed: float = 0.1):
    return (position[0] + direction[0] * speed, position[1] + direction[1] * speed)

class RayQueryable:
    def __init__(self) -> RayQueryable:
        self.__seen = False
    @abstractmethod
    def is_solid(self) -> bool:
        pass
    def is_seen(self) -> bool:
        return self.__seen
    def hit(self) -> None:
        self.__seen = True

class Nothing(RayQueryable):
    def __init__(self) -> Nothing:
        super().__init__()
    def is_solid(self) -> bool:
        return False

class Something(RayQueryable):
    def __init__(self) -> Something:
        super().__init__()
    def is_solid(self) -> bool:
        return True

class Wall(Something):
    def __init__(self, color) -> Wall:
        super().__init__()
        self._color = color
    def color(self) -> pygame.Color:
        return self._color
    def __repr__(self) -> str:
        return f"Wall({self._color})"

class Object(Something):
    def __init__(self, position: tuple[float, float], texture_id: int,
                 world_scale: tuple[float, float] = (1, 1), vertical_offset: float = 0) -> Object:
        super().__init__()
        self._position = position
        self._texture_id = texture_id
        self._scale = world_scale
        self.__vertical_offset = vertical_offset
    def position(self) -> tuple[float, float]:
        return self._position
    def texture_id(self) -> int:
        return self._texture_id
    def width(self) -> float:
        return self._scale[0]
    def height(self) -> float:
        return self._scale[1]
    def vertical_offset(self) -> float:
        return self.__vertical_offset

class Actor(Something):
    def __init__(self, position: tuple[float, float], fov: float = 90) -> Actor:
        super().__init__()
        self._direction = rotate((-1, 0), radians(180))
        self._plane = rotate((0, -math.sin(radians(fov))), radians(180))
        self._position = position
    def position(self) -> tuple[float, float]:
        return self._position
    def direction(self) -> tuple[float, float]:
        return self._direction
    def yaw(self) -> float:
        rads = math.atan2(self._direction[1], self._direction[0])
        if rads < 0:
            return 2 * math.pi + rads
        return rads
    def plane(self) -> tuple[float, float]:
        return self._plane
    def position(self) -> tuple[float, float]:
        return self._position
    def pivot(self, theta: float) -> None:
        self._direction = rotate(self._direction, theta)
        self._plane = rotate(self._plane, theta)
    def walk(self, speed) -> None:
        self._position = walk(self._position, self._direction, speed=speed)
    def strafe(self, speed) -> None:
        direction = rotate(self._direction, radians(90))
        self._position = walk(self._position, direction, speed=speed)

MAP_LAYER_NONE = 0x0
MAP_LAYER_TILES = 0x1
MAP_LAYER_OBJECT = 0x2
MAP_LAYER_ACTOR = 0x4
MAP_LAYER_ALL = 0xff_ff

class Map:
    CELL_SIZE: int = 7
    def __init__(self, path: str|Path) -> Map:
        pygame.init()
        self.__start = (0, 0)
        image = pygame.image.load(path)
        self.__size = image.get_size()
        self.__tiles = [ ]
        self.__objects = [ ]
        self.__actors = [ ]
        pixels = pygame.PixelArray(image)
        for i in range(image.get_height()):
            for j in range(image.get_width()):
                color = pygame.Color(image.unmap_rgb(pixels[j, i]))
                if color == pygame.Color(255, 255, 255):
                    self.__tiles.append(Nothing())
                elif color == pygame.Color(255, 0, 0):
                    self.__start = (j, i)
                    self.__tiles.append(Nothing())
                else:
                    self.__tiles.append(Wall(color))
    def width(self) -> int:
        return self.__size[0]
    def height(self) -> int:
        return self.__size[1]
    def add_actor(self, actor: Actor) -> None:
        self.__actors.append(actor)
    def add_object(self, obj: Object) -> None:
        self.__objects.append(obj)
    def sprites(self) -> tuple[Actor|Object]:
        return tuple(self.__actors + self.__objects)
    def at(self, coords: tuple[int, int], layers: int = MAP_LAYER_ALL):
        x, y = coords
        res = None
        layer = MAP_LAYER_NONE
        if layers & MAP_LAYER_TILES != 0:
            res = self.__tiles[y * self.width() + x]
            layer = MAP_LAYER_TILES
        return (res, layer)
    def start(self) -> tuple[float, float]:
        return (self.__start[0] + 0.5, self.__start[1] + 0.5)

class Player(Actor):
    def __init__(self, position: tuple[float, float], fov: float = 90) -> Player:
        super().__init__(position, fov=fov)

class Ray:
    def __init__(self, origin: tuple[float, float], direction: tuple[float, float], max_distance: float = float("inf"),
                 layers: int = MAP_LAYER_ALL) -> Ray:
        self.__origin = origin
        self.__direction = direction
        self.__max_distance = max_distance
        self.__layers = layers & MAP_LAYER_ALL
    def origin(self) -> tuple[float, float]:
        return self.__origin
    def direction(self) -> tuple[float, float]:
        return self.__direction
    def max_distance(self) -> float:
        return self.__max_distance
    def layers(self) -> int:
        return self.__layers

@dataclass
class RayHit:
    distance: float = 0.0
    perspective_distance: float = 0.0
    layer: int  = MAP_LAYER_NONE
    queryable: RayQueryable = None

SIDE_X = 0
SIDE_Y = 1

@dataclass
class DDAInfo:
    side_distance: tuple[float, float]
    delta: tuple[float, float]
    index: tuple[int, int]
    step: tuple[int, int]

def dda(ray: Ray, map: Map, info: DDAInfo) -> RayHit:
    # FIXME: We need to implement a version of the DDA algorithm here that uses the Ray, Map, and DDAInfo objects.
    # Unlike the version of DDA in dda.py, this version should be distance based rather having an end point.
    # Instead the ray should continue until it reaches the boundary of the map or hit something solid. When the ray
    # hits a solid object, we should stop and return information about how far the ray traveled, what we hit,
    # and what map layer the hit was on.
    #
    # This algorithm does not need to decide what to do when a ray hits something! We just need to correctly
    # pack and return a RayHit object. The World.draw() method will do the actual decision making about colors and
    # shapes.
    pass

def raycast(ray: Ray, map: Map) -> RayHit|None:
    index = [ int(ray.origin()[0]), int(ray.origin()[1]) ]
    delta = [ 1e30, 1e30 ]
    if ray.direction()[0] != 0:
        delta[0] = math.fabs(1 / ray.direction()[0])
    if ray.direction()[1] != 0:
        delta[1] = math.fabs(1 / ray.direction()[1])
    step = [ 0, 0 ]
    side_distance = [ 0, 0 ]
    if ray.direction()[0] < 0:
        step[0] = -1
        side_distance[0] = (ray.origin()[0] - index[0]) * delta[0]
    else:
        step[0] = 1
        side_distance[0] = (index[0] + 1.0 - ray.origin()[0]) * delta[0]
    if ray.direction()[1] < 0:
        step[1] = -1
        side_distance[1] = (ray.origin()[1] - index[1]) * delta[1]
    else:
        step[1] = 1
        side_distance[1] = (index[1] + 1.0 - ray.origin()[1]) * delta[1]
    info = DDAInfo(side_distance, delta, index, step)
    return dda(ray, map, info)

class Texture:
    def __init__(self, path: str|Path) -> Texture:
        texture = pygame.image.load(path)
        self.__surface = pygame.surface.Surface(texture.get_size(), flags=pygame.SRCALPHA)
        self.__surface.blit(texture, (0, 0))
        self.__pixels = pygame.PixelArray(self.__surface)
    def width(self) -> int:
        return self.__surface.get_width()
    def height(self) -> int:
        return self.__surface.get_height()
    def at(self, coords: tuple[int, int]) -> pygame.Color:
        return self.__surface.unmap_rgb(self.__pixels[coords[0], coords[1]])

class World:
    def __init__(self, map: Map, sky: pygame.Color, floor: pygame.Color, fov: float = 90) -> World:
        self.__map = map
        self.__sky = sky
        self.__floor = floor
        self.__player = Player(self.__map.start(), fov=fov)
        self.__map.add_actor(self.__player)
        self.__textures = [ ]
    def player(self) -> Player:
        return self.__player
    def map(self) -> Map:
        return self.__map
    def load_texture(self, path: str|Path) -> int:
        res = len(self.__textures)
        self.__textures.append(Texture(path))
        return res
    def draw(self, target: pygame.surface.Surface) -> None:
        target.fill(self.__sky, pygame.Rect((0, 0), (target.get_width(), target.get_height() // 2)))
        target.fill(self.__floor,
                    pygame.Rect((0, target.get_height() // 2), (target.get_width(), target.get_height() // 2)))
        direction = self.__player.direction()
        plane = self.__player.plane()
        position = self.__player.position()
        zbuffer = [ float("inf") ] * target.get_width()
        sprites = self.__map.sprites()
        billboards = [ ]
        for sprite in sprites:
            if sprite is self.__player:
                continue
            dx, dy = sub(sprite.position(), position)
            transform_y = dot((dx, dy), direction)
            if transform_y <= 0 or transform_y >= 32:
                continue
            transform_x = dot((dx, dy), plane)
            billboards.append((sprite, (transform_x, transform_y)))
        billboards.sort(key=lambda billboard: billboard[1][1], reverse=True)
        for i in range(target.get_width()):
            x = 2 * i / target.get_width() - 1
            ray = Ray(position, (direction[0] + plane[0] * x, direction[1] + plane[1] * x), layers=MAP_LAYER_TILES)
            hit = raycast(ray, self.__map)
            zbuffer[i] = hit.perspective_distance
            darken = 1 / (1 + 0.5 * hit.perspective_distance)
            if not hasattr(hit.queryable, "color"):
                hit.queryable = Wall(pygame.Color(0, 0, 0))
            color = pygame.Color(hit.queryable.color())
            r = int(max(color.r * darken, color.r // 4))
            g = int(max(color.g * darken, color.g // 4))
            b = int(max(color.b * darken, color.b // 4))
            color.update(r, g, b)
            column_height = target.get_height() // hit.perspective_distance
            begin = -column_height // 2 + target.get_height() // 2
            if begin < 0:
                begin = 0
            end = column_height // 2 + target.get_height() // 2
            if end >= target.get_height():
               end = target.get_height() - 1
            pygame.draw.line(target, color, (i, begin), (i, end))
        pixels = pygame.PixelArray(target)
        for billboard in billboards:
            sprite, (tx, ty) = billboard
            sx = (target.get_width() / 2) * (1 + tx / ty)
            height = math.fabs(target.get_height() / ty) * sprite.height()
            width = math.fabs(target.get_height() / ty) * sprite.width()
            bottom = (target.get_height() / 2) + (target.get_height() / ty) * sprite.vertical_offset()
            top = bottom - height
            begin_y = clamp(top, 0, target.get_height() - 1)
            end_y = clamp(bottom, 0, target.get_height() - 1)
            begin_x = clamp(sx - width / 2, 0, target.get_width() - 1)
            end_x = clamp(sx + width / 2, 0, target.get_width() - 1)
            for i in range(int(begin_x), int(end_x) + 1):
                if ty > zbuffer[i]:
                    continue
                zbuffer[i] = ty
                texture = self.__textures[sprite.texture_id()]
                u = clamp((i - (sx - width / 2)) * texture.width() / width, 0, texture.width() - 1)
                for j in range(int(begin_y), int(end_y) + 1):
                    v = clamp((j - top) * texture.height() / height, 0, texture.height() - 1)
                    color = pygame.Color(texture.at((int(u), int(v))))
                    if color.a == 0:
                        continue
                    darken = 1 / (1 + 0.05 * ty)
                    r = int(max(color.r * darken, color.r // 4))
                    g = int(max(color.g * darken, color.g // 4))
                    b = int(max(color.b * darken, color.b // 4))
                    color.update(r, g, b)
                    pixels[i, j] = color
        pixels.close()

