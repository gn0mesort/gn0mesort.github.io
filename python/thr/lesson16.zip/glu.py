import math

def gamma(l: float) -> float:
    if l > 0.0031308 and not math.isclose(l, 0.0031308, rel_tol=0, abs_tol=1e-8):
        return 1.055 * math.pow(l, 1 / 2.4) - 0.055
    return 12.92 * l
