import pygame
import moderngl
import numpy

WIDTH = 640
HEIGHT = 480

vertices = numpy.array((-1, -1, 0, 1, 0, 0,
                         0,  1, 0, 0, 1, 0,
                         1, -1, 0, 0, 0, 1))

vertex_shader = """
#version 450 core

layout(location = 0) in vec3 i_position;
layout(location = 1) in vec3 i_color;

layout(location = 0) out vec4 o_color;

void main() {
    gl_Position = vec4(i_position, 1);
    o_color = vec4(i_color, 1);
}
""".strip()

fragment_shader = """
#version 450 core

layout(location = 0) in vec4 i_color;

layout(location = 0) out vec4 color_0;

void main() {
    color_0 = i_color;
}
"""

pygame.init()
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 4)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 5)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE)
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.DOUBLEBUF | pygame.OPENGL)
gl = moderngl.get_context()
shader = gl.program(vertex_shader=vertex_shader, fragment_shader=fragment_shader)
vbo = gl.buffer(vertices.astype("f4").tobytes())
vao = gl.vertex_array(shader, vbo, "i_position", "i_color")
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_TAB:
                gl.wireframe = not gl.wireframe
    gl.clear(0.2, 0.2, 0.2, 1)
    vao.render()
    pygame.display.flip()
pygame.quit()
