import pygame
import moderngl

WIDTH = 640
HEIGHT = 480

pygame.init()
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 4)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 5)
pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE)
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.OPENGL)
gl = moderngl.get_context()
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
    gl.clear(1, 0, 0, 1)
    gl.finish()
    pygame.display.flip()
pygame.quit()
