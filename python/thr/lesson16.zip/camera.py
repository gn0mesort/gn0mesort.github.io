from pyglm import glm

# We don't strictly need a camera class, and this camera is simplistic compared a camera object for a 3d game.
# However, it's much easier to manage movement through a class like this than to try and manage it directly. When
# you add the complication of rotating the camera (i.e., mouse look) with respect to the world axes this simplifies
# the code significantly.
class Camera:
    """
    An object representing a 3D camera.
    """
    def __init__(self, position: glm.vec3 = glm.vec3(0, 0, 0)):
        """
        Construct a 3D camera at the given position.

        @type position: glm.vec3
        @param position: The initial position of the camera. This defaults to glm.vec3(0, 0, 0).
        """
        self.__UP = glm.vec3(0, 1, 0)
        self.__front = glm.vec3(0, 0, -1)
        self.__position = position
    def position(self) -> glm.vec3:
        return self.__position
    def turn_left(self, radians: float) -> None:
        self.__front = glm.rotate(self.__front, radians, glm.vec3(0, 1, 0))
    def turn_right(self, radians: float) -> None:
        self.__front = glm.rotate(self.__front, -radians, glm.vec3(0, 1, 0))
    def look(self) -> glm.mat4:
        """
        Produce a 4x4 view matrix using the camera's current position and direction.

        @rtype: glm.mat4
        @returns: A view matrix suitable for writing to a shader stage as the view transform of the world.
        """
        return glm.lookAt(self.__position, self.__position + self.__front, self.__UP)
    def move_forward(self, speed: float) -> None:
        """
        Move the camera forward by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move forward. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position + speed * self.__front
    def move_backward(self, speed: float) -> None:
        """
        Move the camera backward by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move backward. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position - speed * self.__front
    def move_left(self, speed: float) -> None:
        """
        Move the camera left by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move left. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position - speed * glm.normalize(glm.cross(self.__front, self.__UP))
    def move_right(self, speed: float) -> None:
        """
        Move the camera right by the desired number of world units.

        @type speed: float
        @param speed: The number of world units to move right. This isn't affected by time deltas, so you should
                      perform scaling prior to this call.
        """
        self.__position = self.__position + speed * glm.normalize(glm.cross(self.__front, self.__UP))
