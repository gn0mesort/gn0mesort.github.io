import pygame
import numpy
import moderngl
from pyglm import glm

from camera import Camera
from controller import Controller
import glu

WIDTH = 640
HEIGHT = 480
CAMERA_SPEED = 1
CAMERA_ROTATION_THETA = 90

vertex_src = """
#version 450 core
layout (location = 0) uniform mat4 model;
layout (location = 1) uniform mat4 view;
layout (location = 2) uniform mat4 projection;

layout (location = 0) in vec3 i_position;
layout (location = 1) in vec4 i_color;

layout (location = 0) out vec4 o_color;

void main() {
    o_color = i_color;
    gl_Position = projection * view * model * vec4(i_position, 1.0);
}
""".strip()

fragment_src = """
#version 450 core

layout (location = 0) in vec4 i_color;

layout (location = 0) out vec4 color_0;

bool is_almost_equal(const float a, const float b, const float absolute_tolerance) {
    if (a == b)
    {
        return true;
    }
    else if (isinf(a) || isinf(b))
    {
        return false;
    }
    return abs(b - a) <= absolute_tolerance;
}

float gamma(const float l) {
    if (l > 0.0031308 && !is_almost_equal(l, 0.0031308, 1e-8))
    {
        return 1.055 * pow(l, 1.0 / 2.4) - 0.055;
    }
    return 12.92 * l;
}

vec4 gamma(const vec4 l) {
    return vec4(gamma(l.r), gamma(l.g), gamma(l.b), l.a);
}

void main() {
    color_0 = gamma(i_color);
}
""".strip()

# FIXME: We need to set up our vertex data here. This will define our 3D shape as well as the colors for each point.
# Both values (position and color) should be 3 float values each.
# Positions should be between -1 and 1
# Colors should be between 0 and 1
pass
# FIXME: Here we will set up an "element buffer" this is data that tells OpenGL what order to read our vertex data in.
# We need one value for each vertex (corner) in our vertex data.
# Each value should be an int.
pass
indices = numpy.array((0, 1, 2))
controller = Controller()
controller.map_action("left", (pygame.K_a, pygame.K_LEFT))
controller.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controller.map_action("forward", (pygame.K_w, pygame.K_UP))
controller.map_action("backward", (pygame.K_s, pygame.K_DOWN))
controller.map_action("turnl", (pygame.K_q,))
controller.map_action("turnr", (pygame.K_e,))
pygame.init()
footstep = pygame.mixer.Sound("step.ogg")
footstep.set_volume(1 / 3)
hmm = pygame.mixer.Sound("hmm.ogg")
# FIXME: Before we create our display, we have to tell PyGame what kind of OpenGL environment we need.
# We need to set the major version, the minor version, and the profile.
# The profile tells OpenGL if we want just the core features or if we want older compatibility features too.
pass
pygame.display.set_mode((WIDTH, HEIGHT), pygame.DOUBLEBUF | pygame.OPENGL)
gl = moderngl.get_context()
gl.enable(gl.DEPTH_TEST)
clock = pygame.time.Clock()
quitting = False
# FIXME: Now, we need to transfer our data to our GPU.
# To do this we need to create buffers for our data (vertices and indices) with the correct OpenGL types.
# We also need to create a shader program using the provided shader source code.
# Finally, we need to setup a vertex array to tell OpenGL how to relate all of our data.
#
# Vertex data should all be "f4".
# Index data should all be "u4".
pass
projection = glm.perspective(glm.radians(60), WIDTH / HEIGHT, 0.1, 1000.0)
camera = Camera(glm.vec3(0.0, 0.0, 2.0))
model = glm.mat4()
dt = 0.0
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE and hmm.get_num_channels() == 0:
                hmm.play()
            if event.key == pygame.K_TAB:
                gl.wireframe = not gl.wireframe
        controller.update(event)
    if controller.is_action_pressed("forward"):
        camera.move_forward(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("backward"):
        camera.move_backward(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("left"):
        camera.move_left(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("right"):
        camera.move_right(CAMERA_SPEED * dt)
        if footstep.get_num_channels() == 0:
            footstep.play()
    if controller.is_action_pressed("turnl"):
        camera.turn_left(glm.radians(CAMERA_ROTATION_THETA * dt))
    if controller.is_action_pressed("turnr"):
        camera.turn_right(glm.radians(CAMERA_ROTATION_THETA * dt))
    gl.clear(glu.gamma(0.2), glu.gamma(0.2), glu.gamma(0.2), 1.0)
    shader["model"].write(model)
    shader["view"].write(camera.look())
    shader["projection"].write(projection)
    vao.render()
    pygame.display.flip()
    dt = clock.tick() / 1000
# FIXME: It's not strictly required, but it's good practice for us to manually clean up our OpenGL data.
# This is like closing files, if we're not careful OpenGL will keep all this data around forever.
# Each OpenGL object should be released in the reverse of the order we created it.
pass
pygame.quit()
