import pygame

from library import *

WIDTH = 640
HEIGHT = 480
SPEED = 200

pygame.init()
controls = Controller()
controls.map_action("left", (pygame.K_a, pygame.K_LEFT))
controls.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controls.map_action("up", (pygame.K_w, pygame.K_UP))
controls.map_action("down", (pygame.K_s, pygame.K_DOWN))
screen = pygame.display.set_mode((WIDTH, HEIGHT))
background = pygame.image.load("scroller.png").convert_alpha()
backbuffer = pygame.surface.Surface(background.get_size(), flags=pygame.SRCALPHA).convert_alpha()
position = [ 0, 0 ]
camera = pygame.Rect((0, 0, WIDTH // 4, HEIGHT // 4))
quitting = False
clock = pygame.time.Clock()
dt = 0
player = pygame.Surface((3, 3), flags=pygame.SRCALPHA)
player.set_at((1, 0), (255, 0, 0))
player.set_at((0, 1), (255, 0, 0))
player.set_at((1, 1), (255, 0, 0))
player.set_at((2, 1), (255, 0, 0))
player.set_at((1, 2), (255, 0, 0))
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        controls.update(event)
    if controls.is_action_pressed("left"):
        position[0] -= SPEED * dt
    if controls.is_action_pressed("right"):
        position[0] += SPEED * dt
    if controls.is_action_pressed("up"):
        position[1] -= SPEED * dt
    if controls.is_action_pressed("down"):
        position[1] += SPEED * dt
    if position[0] < 0:
        position[0] = 0
    if position[0] + player.get_width() >= backbuffer.get_width():
        position[0] = backbuffer.get_width() - player.get_width()
    if position[1] < 0:
        position[1] = 0
    if position[1] + player.get_height() >= backbuffer.get_height():
        position[1] = backbuffer.get_height() - player.get_height()
    if position[0] - camera.width // 2 >= 0 and position[0] + camera.width // 2 < backbuffer.get_width():
        camera.centerx = int(position[0])
    elif position[0] - camera.width // 2 < 0:
        camera.left = 0
    elif position[0] + camera.width // 2 >= backbuffer.get_width():
        camera.right = backbuffer.get_width()
    if position[1] - camera.height // 2 >= 0 and position[1] + camera.height // 2 < backbuffer.get_height():
        camera.centery = int(position[1])
    elif position[1] - camera.height // 2 < 0:
        camera.top = 0
    elif position[1] + camera.height // 2 >= backbuffer.get_height():
        camera.bottom = backbuffer.get_height()
    screen.fill((255, 255, 255))
    backbuffer.fill((255, 255, 255))
    backbuffer.blit(background, (0, 0))
    backbuffer.blit(player, position)
    image = backbuffer.subsurface(camera)
    if image.get_width() < screen.get_width() or image.get_height() < screen.get_height():
        image = pygame.transform.scale(image.copy(), screen.get_size())
    screen.blit(image, (0, 0))
    pygame.display.update()
    dt = clock.tick() / 1000
pygame.quit()
