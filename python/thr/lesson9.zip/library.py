import sys
import math
import pygame
import pygame.freetype
import pymunk

def fequal(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    abs_a = math.fabs(a)
    abs_b = math.fabs(b)
    difference = math.fabs(a - b)
    if a == b:
        return True
    elif a == 0 or b == 0 or (abs_a + abs_b < sys.float_info.min):
        return difference < (epsilon * sys.float_info.min)
    else:
        return difference / min(abs_a + abs_b, sys.float_info.max) < epsilon

class Controller:
    def __init__(self):
        self.__keymap = { }
        self.__action_states = { }
    def map_action(self, action: str, keys: tuple) -> None:
        for key in keys:
            self.__keymap[key] = action
        self.__action_states[action] = 0
    def update(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYUP or event.type == pygame.KEYDOWN:
            if event.key in self.__keymap:
                action = self.__keymap[event.key]
                if event.type == pygame.KEYUP:
                    self.__action_states[action] = 0
                else:
                    self.__action_states[action] = ((self.__action_states[action] & 1) << 1) | 1
    def is_action_pressed(self, action: str) -> bool:
        return self.__action_states[action] > 0

class FixedUpdateStep:
    def __init__(self, time: float):
        self.__step_time = time
        self.__acc = 0
    def _update_handler(self, dt: float, fresh: bool) -> None:
        pass
    def tick(self, dt: float) -> None:
        self.__acc = self.__acc + dt
    def update(self) -> None:
        fresh = True
        while self.__acc >= self.__step_time:
            self.__acc = self.__acc - self.__step_time
            self._update_handler(self.__step_time, fresh)
            fresh = False

class PhysicsUpdateStep(FixedUpdateStep):
    UPDATE_TIME: float = 1 / 60
    STEPS_PER_UPDATE: int  = 4
    MAX_UPDATES_PER_FRAME: int = 8
    def __init__(self, space: pymunk.Space):
        super().__init__(PhysicsUpdateStep.UPDATE_TIME)
        self.__space = space
        self.__updates = 0
    def _update_handler(self, dt: float, fresh: bool) -> None:
        if fresh:
            self.__updates = 0
        for i in range(PhysicsUpdateStep.STEPS_PER_UPDATE):
            if self.__updates > PhysicsUpdateStep.MAX_UPDATES_PER_FRAME:
                break
            self.__space.step(dt / PhysicsUpdateStep.STEPS_PER_UPDATE)
            self.__updates = self.__updates + 1

class FramerateUpdateStep(FixedUpdateStep):
    UPDATE_TIME: float = 1 / 6
    def __init__(self, clock: pygame.time.Clock, typeface: pygame.freetype.Font):
        super().__init__(FramerateUpdateStep.UPDATE_TIME)
        self.__clock = clock
        self.__typeface = typeface
        self.__target = self.__typeface.render(f"{self.__clock.get_fps():.02f} Hz")[0]
    def _update_handler(self, dt: float, fresh: bool) -> None:
        self.__target = self.__typeface.render(f"{self.__clock.get_fps():.02f} Hz")[0]
    def draw(self, target: pygame.surface.Surface) -> None:
        target.blit(self.__target, (2, 5))

class Entity:
    def __init__(self):
        pass
    def update(self, controls: Controller, dt: float) -> None:
        pass
    def draw(self, target: pygame.surface.Surface) -> pygame.Rect:
        pass

class Platform(Entity):
    def __init__(self, body_type: int, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__()
        self._body = pymunk.Body(body_type=body_type, moment=math.inf)
        self._body.position = (x, y)
        self._body_shape = pymunk.Poly.create_box(self._body, size=(width, height))
        self._body_shape.mass = 1000
        self._body_shape.collision_type = 0b10
        self._body.moment = float("inf")
        space.add(self._body, self._body_shape)
        self._sprite = pygame.surface.Surface((width, height), flags=pygame.SRCALPHA)
        self._sprite.fill(pygame.Color(0, 255, 0))
    def draw(self, target: pygame.surface.Surface) -> pygame.Rect:
        rect = self._sprite.get_rect()
        return target.blit(self._sprite, (self._body.position.x - rect.w / 2, self._body.position.y - rect.h / 2))
    def rectangle(self) -> pygame.Rect:
        rect = self._sprite.get_rect()
        return pygame.Rect(self._body.position.x - rect.w / 2, self._body.position.y - rect.h / 2, rect.w, rect.h)

class StaticPlatform(Platform):
    def __init__(self, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__(pymunk.Body.STATIC, space, x, y, width, height)

class KinematicPlatform(Platform):
    def __init__(self, space: pymunk.Space, x: int, y: int, width: int, height: int):
        super().__init__(pymunk.Body.KINEMATIC, space, x, y, width, height)

def player_platform_post_solve(arbiter: pymunk.Arbiter, space: pymunk.Space, data) -> None:
    player_shape, platform_shape = arbiter.shapes
    if platform_shape.collision_type != 0b10:
        player_shape, platform_shape = platform_shape, player_shape
    normal = arbiter.contact_point_set.normal
    if normal.y > 0.5 and not fequal(normal.y, 0.5, 1e-7):
        data._ground_velocity = platform_shape.body.velocity

def player_pickup_post_solve(arbiter: pymunk.Arbiter, space: pymunk.Space, data) -> None:
    player_shape, pickup_shape = arbiter.shapes
    if pickup_shape.collision_type != 0b100:
        player_shape, pickup_shape = pickup_shape, player_shape
    space.remove(pickup_shape.body, pickup_shape)

class Pickup(Entity):
    def __init__(self, space: pymunk.Space, x: int, y: int, radius: int):
        super().__init__()
        self.__body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
        self.__body.position = (x, y)
        self.__body_shape = pymunk.Circle(self.__body, radius)
        self.__body_shape.collision_type = 0b100
        self.__should_remove = False
        space.add(self.__body, self.__body_shape)
        space.on_collision(0b1, 0b100, post_solve=player_pickup_post_solve)
        self.__sprite = pygame.surface.Surface((radius * 4, radius * 4), flags=pygame.SRCALPHA)
        pygame.draw.circle(self.__sprite, pygame.Color(255, 255, 0), self.__sprite.get_rect().center, radius)
    def should_remove(self) -> bool:
        return self.__should_remove
    def update(self, controls: Controller, dt: float) -> None:
        if self.__body.space is None:
            self.__should_remove = True
    def draw(self, target: pygame.surface.Surface) -> pygame.Rect:
        if self.__body.space is None:
            return
        rect = self.__sprite.get_rect()
        return target.blit(self.__sprite, (self.__body.position.x - rect.w / 2, self.__body.position.y - rect.h / 2))
    def rectangle(self) -> pygame.Rect:
        rect = self.__sprite.get_rect()
        return pygame.Rect(self.__body.position.x - rect.w / 2, self.__body.position.y - rect.h / 2, rect.w, rect.h)

class Player(Entity):
    SPEED: float = 100
    JUMP_SPEED: float = -2500
    def __init__(self, space: pymunk.Space, size: tuple[int, int]):
        super().__init__()
        self.__space = space
        self.__body = pymunk.Body(mass=5, moment=float("inf"))
        self.__body.position = (0, 0)
        self.__body_shape = pymunk.Poly.create_box(self.__body, size)
        self.__body_shape.elasticity = 0.5
        self.__body_shape.collision_type = 0b1
        self._ground_velocity = pymunk.Vec2d.zero()
        space.add(self.__body, self.__body_shape)
        space.on_collision(0b1, 0b10, post_solve=player_platform_post_solve, data=self)
        self.__sprite = pygame.surface.Surface(size, flags=pygame.SRCALPHA)
        self.__sprite.fill(pygame.Color(255, 0, 0))
    def set_position(self, x: int, y: int) -> None:
        self.__body.position = (x - self.__sprite.get_width() // 2, y - self.__sprite.get_height() // 2)
        self.__body.velocity = (0, 0)
    def position(self) -> tuple[int, int]:
        return (self.__body.position.x - self.__sprite.get_width() // 2,
                self.__body.position.y - self.__sprite.get_height() // 2)
    def width(self) -> int:
        return self.__sprite.get_width()
    def height(self) -> int:
        return self.__sprite.get_height()
    def update(self, controls: Controller, dt: float) -> None:
        self.__body.angular_velocity = 0
        self.__body.angle = 0
        if controls.is_action_pressed("left"):
            self.__body.apply_impulse_at_local_point((-Player.SPEED - self.__body.velocity.x, 0))
        elif controls.is_action_pressed("right"):
            self.__body.apply_impulse_at_local_point((Player.SPEED - self.__body.velocity.x, 0))
        else:
            self.__body.velocity = (self._ground_velocity.x, self.__body.velocity.y)
        if controls.is_action_pressed("jump") and fequal(self.__body.velocity.y, 0, 1e-7):
            self.__body.apply_impulse_at_local_point((0, Player.JUMP_SPEED))
            self._ground_velocity = pymunk.Vec2d.zero()
    def draw(self, target: pygame.surface.Surface) -> pygame.Rect:
        rect = self.__sprite.get_rect()
        return target.blit(self.__sprite, (self.__body.position.x - rect.w / 2, self.__body.position.y - rect.h / 2))
