import pygame
import pygame.freetype
import pymunk
import pymunk.pygame_util

from library import *

DEBUG = False
SHOW_FPS = True

WIDTH = 640
HEIGHT = 480

WORLD_WIDTH = 4 * WIDTH
WORLD_HEIGHT = 2 * HEIGHT

TILE_WIDTH = 16
TILE_HEIGHT = 16

# FIXME: We need to develop a Camera class here. The camera is a rectangle that should stay centered around the player
# except when keeping it centered would go off the edge of the world. When this happens, the player should be able to
# move off the camera origin on the axis or axes that are at their limit. The camera should move independently on the
# X-axis and Y-axis.
pass

pygame.init()
controls = Controller()
controls.map_action("left", (pygame.K_a, pygame.K_LEFT))
controls.map_action("right", (pygame.K_d, pygame.K_RIGHT))
controls.map_action("jump", (pygame.K_SPACE, pygame.K_UP, pygame.K_w))
controls.map_action("reset", (pygame.K_e,))
space = pymunk.Space()
space.gravity = (0, 980)
# Invisible walls
walls = [ ]
walls.append({ "body": pymunk.Body(body_type=pymunk.Body.STATIC), "shape": None })
walls[-1]["shape"] = pymunk.Segment(walls[-1]["body"], (WORLD_WIDTH -  2 * TILE_WIDTH, 0), (WORLD_WIDTH - 2 * TILE_WIDTH, WORLD_HEIGHT), 1)
walls.append({ "body": pymunk.Body(body_type=pymunk.Body.STATIC), "shape": None })
walls[-1]["shape"] = pymunk.Segment(walls[-1]["body"], (2 * TILE_WIDTH, 0), (2 * TILE_WIDTH, WORLD_HEIGHT), 1)
for wall in walls:
    space.add(wall["body"], wall["shape"])
player = Player(space, (TILE_WIDTH, TILE_HEIGHT))
player.set_position(WORLD_WIDTH // 2, WORLD_HEIGHT - TILE_HEIGHT - 1)
platforms = [ ]
# Ground
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2, WORLD_HEIGHT - TILE_HEIGHT // 2, 100 * WORLD_WIDTH, TILE_HEIGHT))
# Floating Platform
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2, WORLD_HEIGHT - 4 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + 4 * TILE_WIDTH, WORLD_HEIGHT - 6 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + 8 * TILE_WIDTH, WORLD_HEIGHT - 8 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + 4 * TILE_WIDTH, WORLD_HEIGHT - 10 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2, WORLD_HEIGHT - 12 * TILE_HEIGHT, 2 * TILE_WIDTH, TILE_HEIGHT))
# Stairs
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH, WORLD_HEIGHT - 1.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + TILE_WIDTH, WORLD_HEIGHT - 2.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 2 * TILE_WIDTH, WORLD_HEIGHT - 3.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 3 * TILE_WIDTH, WORLD_HEIGHT - 4.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 4 * TILE_WIDTH, WORLD_HEIGHT - 5.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 5 * TILE_WIDTH, WORLD_HEIGHT - 6.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 6 * TILE_WIDTH, WORLD_HEIGHT - 7.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 7 * TILE_WIDTH, WORLD_HEIGHT - 8.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 8 * TILE_WIDTH, WORLD_HEIGHT - 9.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 9 * TILE_WIDTH, WORLD_HEIGHT - 8.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 10 * TILE_WIDTH, WORLD_HEIGHT - 7.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 11 * TILE_WIDTH, WORLD_HEIGHT - 6.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 12 * TILE_WIDTH, WORLD_HEIGHT - 5.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 13 * TILE_WIDTH, WORLD_HEIGHT - 4.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 14 * TILE_WIDTH, WORLD_HEIGHT - 3.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 15 * TILE_WIDTH, WORLD_HEIGHT - 2.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
platforms.append(StaticPlatform(space, WORLD_WIDTH // 2 + WIDTH + 16 * TILE_WIDTH, WORLD_HEIGHT - 1.5 * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
pickups = [ ]
pickups.append(Pickup(space, WORLD_WIDTH // 2, WORLD_HEIGHT - 5 * TILE_HEIGHT, TILE_WIDTH // 2))
pickups.append(Pickup(space, WORLD_WIDTH // 2 + 4 * TILE_WIDTH, WORLD_HEIGHT - 7 * TILE_HEIGHT, TILE_WIDTH // 2))
pickups.append(Pickup(space, WORLD_WIDTH // 2 + 8 * TILE_WIDTH, WORLD_HEIGHT - 9 * TILE_HEIGHT, TILE_WIDTH // 2))
pickups.append(Pickup(space, WORLD_WIDTH // 2 + 4 * TILE_WIDTH, WORLD_HEIGHT - 11 * TILE_HEIGHT, TILE_WIDTH // 2))
pickups.append(Pickup(space, WORLD_WIDTH // 2, WORLD_HEIGHT - 13 * TILE_HEIGHT, TILE_WIDTH // 2))
screen = pygame.display.set_mode((WIDTH, HEIGHT))
backbuffer = pygame.surface.Surface((WORLD_WIDTH, WORLD_HEIGHT)).convert_alpha()
camera = Camera((WIDTH, HEIGHT), backbuffer, player)
clock = pygame.time.Clock()
typeface = pygame.freetype.Font("nec.ttf", 16)
typeface.fgcolor = pygame.Color(255, 255, 255)
typeface.bgcolor = pygame.Color(0, 0, 0)
dt = 0
physics = PhysicsUpdateStep(space)
framerate = FramerateUpdateStep(clock, typeface)
quitting = False
space.step(1)
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        controls.update(event)
        if controls.is_action_pressed("reset"):
            player.set_position(WORLD_WIDTH // 2, WORLD_HEIGHT // 2)
    physics.update()
    if DEBUG or SHOW_FPS:
        framerate.update()
    player.update(controls, dt)
    for platform in platforms:
        platform.update(controls, dt)
    for pickup in pickups:
        pickup.update(controls, dt)
        if pickup.should_remove():
            pickups.remove(pickup)
    camera.update(controls, dt)
    # FIXME: We need to draw our world and then use the camera to render the visible portion of it here. This means
    # we need to clear the backbuffer, draw any background, draw all the entities (player, platforms, pickups), and
    # use the camera to render the correct region to the screen.
    #
    # We also need to cull (remove) any entities that aren't visible! We don't want to draw things that aren't on the
    # screen
    pass
    if DEBUG:
        options = pymunk.pygame_util.DrawOptions(backbuffer)
        options.flags |= pymunk.SpaceDebugDrawOptions.DRAW_COLLISION_POINTS | pymunk.SpaceDebugDrawOptions.DRAW_CONSTRAINTS
        space.debug_draw(options)
    screen.fill(pygame.Color(0, 0, 0))
    camera.draw(screen)
    if DEBUG or SHOW_FPS:
        framerate.draw(screen)
    pygame.display.flip()
    dt = clock.tick() / 1000.0
    physics.tick(dt)
    framerate.tick(dt)
pygame.quit()
