def remap(x: int|float, a: int|float, b: int|float) -> int|float:
    return (x / a) * b


