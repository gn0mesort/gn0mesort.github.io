def remap(x: int|float, a: int|float, b: int|float, c: int|float, d: int|float) -> int|float:
    return c + (x - a) * (d - c) / (b - a)


