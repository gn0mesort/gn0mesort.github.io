import random

number = random.randint(100000, 999999)
print(f"Your magic number is: " + str(number) + "!")


