from dataclasses import dataclass

WIDTH = 3
HEIGHT = 3

NORTH = 0
EAST = 1
SOUTH = 2
WEST = 3

@dataclass
class Cell:
    text: str = ""
    win: bool = False
    exits: set = None

@dataclass
class Position:
    x: int = 0
    y: int = 0

def index(x: int, y: int) -> int:
    return y * WIDTH + x

quitting = False
map = [ None ] * WIDTH * HEIGHT
# Upper Left
map[index(0, 0)] = Cell()
map[index(0, 0)].text = "You see a waterfall."
map[index(0, 0)].exits = { EAST, SOUTH }
# Upper Center
map[index(1, 0)] = Cell()
map[index(1, 0)].text = "You come to a cliff that overlooks the ocean."
map[index(1, 0)].exits = { EAST, WEST, SOUTH }
# Upper Right
map[index(2, 0)] = Cell()
map[index(2, 0)].text = "You have found the treasure!"
map[index(2, 0)].win = True
map[index(2, 0)].exits = { WEST, SOUTH }
# Middle Left
map[index(0, 1)] = Cell()
map[index(0, 1)].text = "You see a dark cave. Perhaps it's best not to enter."
map[index(0, 1)].exits = { NORTH, SOUTH, EAST }
# Middle Center
map[index(1, 1)] = Cell()
map[index(1, 1)].text = "You're at your campsite."
map[index(1, 1)].exits = { NORTH, SOUTH, EAST, WEST }
# Middle Right
map[index(2, 1)] = Cell()
map[index(2, 1)].text = "You are surrounded by forest as far as you can see."
map[index(2, 1)].exits = { NORTH, SOUTH, WEST }
# Bottom Left
map[index(0, 2)] = Cell()
map[index(0, 2)].text = "You are on a scenic beach. Too bad you don't have a boat."
map[index(0, 2)].exits = { NORTH, EAST }
# Bottom Center
map[index(1, 2)] = Cell()
map[index(1, 2)].text = "You see a banana tree. It's too tall for you to get any though."
map[index(1, 2)].exits = { NORTH, EAST, WEST }
# Bottom Right
map[index(2, 2)] = Cell()
map[index(2, 2)].text = "You come to a small delta where a river meets the ocean."
map[index(2, 2)].exits = { NORTH, WEST }
position = Position()
position.x = 1
position.y = 1
print("You've been shipwrecked on a desert island while searching for treasure.")
while not quitting:
    cell = map[index(position.x, position.y)]
    print(cell.text)
    if cell.win:
        quitting = True
        continue
    print("You can exit to the: ", end="")
    if NORTH in cell.exits:
        print("NORTH ", end="")
    if EAST in cell.exits:
        print("EAST ", end="")
    if SOUTH in cell.exits:
        print("SOUTH ", end="")
    if WEST in cell.exits:
        print("WEST ", end="")
    print("")
    direction = input("> ").upper().strip()
    if direction.startswith("N") and NORTH in cell.exits:
        position.y = position.y - 1
    if direction.startswith("E") and EAST in cell.exits:
        position.x = position.x + 1
    if direction.startswith("S") and SOUTH in cell.exits:
        position.y = position.y + 1
    if direction.startswith("W") and WEST in cell.exits:
        position.x = position.x - 1
