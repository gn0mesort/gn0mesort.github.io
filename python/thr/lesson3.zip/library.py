import pygame
import pathlib
import math
import random
from collections.abc import Callable

class Sprite:
    """
    A class for handling blittable sprite images.
    """
    def __init__(self, surface: pygame.Surface, rect: pygame.Rect, x: float = 0, y: float = 0):
        """
        Construct a new Sprite.

        @type surface: pygame.Surface
        @param surface: A Surface that contains the image data for the Sprite. This doesn't need to exclusively contain
                        the Sprite data. This must not be None.
        @type rect: pygame.Rect
        @param rect: A rectangle describing the bounds of the Sprite's image in surface. This can differ from the
                     bounds of surface itself. This must not be None.
        @type x: float
        @param x: The x-axis position of the Sprite on the screen. This defaults to 0. This must not be None.
        @type y: float
        @param y: The y-axis position of the Sprite on the screen. This defaults to 0. This must not be None.
        """
        self.__surface = surface
        self.__rect = rect
        self.__x = x
        self.__y = y
    def move_to(self, x: float, y: float) -> None:
        """
        Move the Sprite to the desired (x, y) screen position.

        @type x: float
        param x: The x-axis position of the Sprite on the screen. This defaults to 0. This must not be None.
        @type y: float
        @param y: The y-axis position of the Sprite on the screen. This defaults to 0. This must not be None.
        """
        self.__x = x
        self.__y = y
    def render(self, target: pygame.Surface) -> None:
        """
        Render the Sprite to the target Surface.

        @type target: pygame.Surface
        @param target: The Surface that the Sprite will be drawn to. This doesn't have to be the actual visible window,
                       any pygame.Surface will do. This must not be None.
        """
        target.blit(self.__surface, (self.__x, self.__y), area=self.__rect)

class SpriteMap:
    """
    A class representing a NxM pixel map of Sprites.
    """
    def __init__(self, path: pathlib.Path|str, width: int, height: int):
        """
        Construct a new SpriteMap.

        @type path: pathlib.Path|str
        @param path: The path to the file containing pixel data for the SpriteMap. This must be a valid file path.
        @type width: int
        @param width: The width of a single Sprite in the map measured in pixels. This must not be None.
        @type height: int
        @param height: The height of a single Sprite in the map measured in pixels. This must not be None.
        """
        self.__map = pygame.image.load(path)
        self.__width = width
        self.__height = height
    def get(self, x: int, y: int) -> Sprite:
        """
        Retrieve a new Sprite referencing the indicated Sprite in the map.

        @type x: int
        @param x: The x-axis position of the desired Sprite. This is measured in Sprites and not pixels! This must
                  not be None.
        @type y: int
        @param y: The y-axis position of the desired Sprite. This is measured in Sprites and not pixels! This must
                  not be None.
        @rtype: Sprite
        @returns: A Sprite object referencing the indicated pixels of the map.
        """
        return Sprite(self.__map, pygame.Rect(x * self.__width, y * self.__height, self.__width, self.__height))

class Clickable:
    """
    A class for handling clickable game objects.
    """
    def __init__(self, sprite: Sprite, effect: Callable, args: tuple|list = tuple()):
        """
        Construct a new Clickable.

        @type sprite: Sprite
        @param sprite: A Sprite graphic to associate with the Clickable. This must not be None.
        @type effect: Callable
        @param effect: A Callable object that determines what will happen when the Clickable is clicked. This must
                       not be None.
        @type args: tuple|list
        @param args: An iterable array of arguments to pass to effect. This defaults to tuple(). This must not be None.
        """
        self.__sprite = sprite
        self.__effect = effect
        self.__args = args
    def move_to(self, x: float, y: float) -> None:
        """
        Move the Clickable's underlying Sprite.

        @type x: float
        param x: The x-axis position of the Sprite on the screen. This defaults to 0. This must not be None.
        @type y: float
        @param y: The y-axis position of the Sprite on the screen. This defaults to 0. This must not be None.
        """
        self.__sprite.move_to(x, y)
    def render(self, target: pygame.Surface) -> None:
        """
        Render the underlying Sprite to the target Surface.

        @type target: pygame.Surface
        @param target: The Surface that the Sprite will be drawn to. This doesn't have to be the actual visible window,
                       any pygame.Surface will do. This must not be None.
        """
        self.__sprite.render(target)
    def click(self) -> None:
        """
        Click the Clickable. This triggers its effect.
        """
        self.__effect(*self.__args)

class TileMap:
    """
    A class for managing an NxM rectangular map of tiles.
    """
    TILE_SIZE = 18
    def __init__(self, width: int, height: int):
        """
        Construct a new TileMap.

        @type width: int
        @param width: The width of the map in tiles. This must not be None.
        @type height: int
        @param height: The height of the map in tiles. This must not be None.
        """
        self.__width = int(width)
        self.__height = int(height)
        self.__tiles = [ None ] * (self.__width * self.__height)
        self.__surface = pygame.Surface((self.__width * TileMap.TILE_SIZE, self.__height * TileMap.TILE_SIZE), flags=pygame.SRCALPHA)
    def width(self) -> int:
        """
        Retrieve the TileMap's width.

        @rtype: int
        @returns: The width of the map in tiles.
        """
        return self.__width
    def height(self) -> int:
        """
        Retrieve the TileMap's height.

        @rtype: int
        @returns: The height of the map in tiles.
        """
        return self.__height
    def set_tile(self, x: int, y: int, clickable: Clickable|None) -> None:
        """
        Place a Clickable in a tile.

        @type x: int
        @param x: The x-axis position of the tile. This is in tiles and not pixels! This must not be None.
        @type y: int
        @param y: The y-axis position of the tile. This is in tiles and not pixels! This must not be None.
        @type clickable: Clickable|None
        @param clickable: A Clickable object to place at the given coordinates. If this is None, the tile is cleared.
        """
        self.__tiles[y * self.__width + x] = clickable
        if clickable is not None:
            self.__tiles[y * self.__width + x].move_to(x * TileMap.TILE_SIZE, y * TileMap.TILE_SIZE)
    def get_tile(self, x: int, y: int) -> Clickable|None:
        """
        Retrieve the contents of a tile.

        @rtype: Clickable|None
        @returns: A valid Clickable if the tile is full. Otherwise, None.
        """
        return self.__tiles[y * self.__width + x]
    def tile_from_point(self, x: float, y: float) -> tuple|None:
        """
        Retrieve the coordinates of a tile from an (x, y) position in pixels. Positions are measured against an
        width() * TileMap.TILE_SIZE x height() * TileMap.TILE_SIZE raster of pixels.

        @type x: float
        @param x: The x-axis position of a pixel to check for tile membership. This must not be None.
        @type y: float
        @param y: The y-axis position of a pixel to check for tile membership. This must not be None.
        @rtype: tuple|None
        @returns: If the (x, y) position is within a tile, a 2-tuple of tile coordinates is returned. Otherwise, this
                  returns None.
        """
        for i in range(self.__height):
            for j in range(self.__width):
                rect = pygame.Rect(j * TileMap.TILE_SIZE, i * TileMap.TILE_SIZE, TileMap.TILE_SIZE, TileMap.TILE_SIZE)
                if rect.collidepoint(x, y):
                    return (j, i)
        return None
    def render(self) -> pygame.Surface:
        """
        Render the entire TileMap to a pygame.Surface. The resulting surface is safe to use as an input for other
        rendering operations. However, it cannot be used as an output target. The underlying Surface belongs to the
        TileMap.

        @rtype: pygame.Surface
        @returns: A reference to the TileMap's Surface with the entire map rendered.
        """
        self.__surface.fill(pygame.Color(0, 0, 0, 0))
        for i in range(self.__height):
            for j in range(self.__width):
                sprite = self.__tiles[i * self.__width + j]
                if sprite is not None:
                    sprite.render(self.__surface)
        return self.__surface

def to_human_readable(value: int|float) -> str:
    """
    Convert a measurement to an abbreviated metric unit.

    @type value: int|float
    @param value: The value to convert. This must not be None.
    @rtype: str
    @returns: A string representing the input value. For example, 1000 becomes 1K, 1000000 becomes 1M, and so on.
    """
    if value < 1000:
        return str(value)
    UNITS = ("K","M", "B", "T", "Qa", "Qi", "Sx", "Oc", "No", "Dc")
    power = 0
    buffer = bytearray()
    power = int(math.log(value) / math.log(1000))
    buffer.extend(f"{value / 1000 ** power:0.2f}".encode("utf-8"))
    buffer.extend(UNITS[power - 1].encode("utf-8"))
    return buffer.decode("utf-8")

class Score:
    """
    A class representing a game score.
    """
    INITIAL_SCORE_PER_CLICK = 100
    def __init__(self):
        """
        Construct a new Score. The initial value is 0.
        """
        self.__score = 0
        self.__multiplier = 1
        self.__base_increment = Score.INITIAL_SCORE_PER_CLICK
    def increment(self) -> None:
        """
        Increase the score based on the current base increment and multiplier.
        """
        self.__score = self.__score + self.__base_increment * self.__multiplier
    def increment_by(self, by: int) -> None:
        """
        Increase the score by a fixed amount.

        @type by: int
        @param by: The amount to increase the score by. This must not be None.
        """
        self.__score = self.__score + by
    def set_multiplier(self, multiplier: float) -> None:
        """
        Set the score multiplier. The product of this value and the base increment are applied to the score for
        each call to increment.

        @type multiplier: float
        @param multiplier: The value to multiply the base increment by. This should be >=1. This must not be None.
        """
        self.__multiplier = multiplier
    def multiplier(self) -> float:
        """
        Retrieve the current score multiplier.

        @rtype: float
        @returns: The current multiplier value.
        """
        return self.__multiplier
    def set_base_increment(self, base_increment: int) -> None:
        """
        Set the score's base increment. The product of this value and the multiplier are applied to the score for
        each call to increment.

        @type base_increment: int
        @param base_increment: The value to increment the score by. This should be >=1. This must not be None.
        """
        self.__base_increment = base_increment
    def base_increment(self) -> int:
        """
        Retrieve the current score's base increment.

        @rtype: int
        @returns: The current base increment value.
        """
        return self.__base_increment
    def __str__(self) -> str:
        """
        Convert a Score to a human readable string.

        @rtype: str
        @returns: A human readable score string.
        """
        return to_human_readable(self.__score)

class Timer:
    """
    A class representing a game timer. This must be fed with the current delta time by a game loop.
    """
    def __init__(self, duration: float, loop: bool, elapsed: Callable, args: tuple|list = tuple()):
        """
        Construct a new Timer.

        @type duration: float
        @param duration: The wait time of the Timer in seconds. This must be >=0. This must not be None.
        @type loop: bool
        @param loop: Whether or not the timer should loop (repeat) after it has elapsed. This must not be None.
        @type elapsed: Callable
        @param elapsed: A Callable object that will be invoked when the Timer's wait time has elapsed. This must not
                        be None.
        @type args: tuple|list
        @param args: An iterable array of arguments to pass to elapsed. This defaults to tuple(). This must not be None.
        """
        self.__secs = 0
        self.__duration = duration
        self.__running = True
        self.__loop = loop
        self.__elapsed = elapsed
        self.__args = args
    def update(self, delta_time: float) -> None:
        """
        Update a Timer. If the accumulated time is >=duration, the elapsed Callable will be invoked. The Callable will
        be invoked multiple times if necessary.

        @type delta_time: float
        @param delta_time: The amount of time that has passed since the last update. This must be >=0. This must not
                           be None.
        """
        self.__secs = self.__secs + delta_time
        while self.__secs >= self.__duration and self.__running:
            self.__secs = self.__secs - self.__duration
            self.__elapsed(*self.__args)
            if not self.__loop:
                self.__running = False
    def is_running(self) -> bool:
        """
        Determine whether or not the Timer is running.

        @rtype: bool
        @returns: True if the Timer is currently running. False if the Timer was a one-shot Timer and it has elapsed.
                  For looping Timers this will always be True.
        """
        return self.__running
