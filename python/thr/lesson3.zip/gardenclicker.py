import pygame
import random
from library import *

WIDTH = 1280
HEIGHT = 720
SCORE_PER_SECOND = 1
UPGRADE_PERCENTAGE = 40
UPGRADE_KIND_MULT = 0
UPGRADE_KIND_BASE = 1
MULTIPLIER_INCREMENT = 0.25
BASE_INCREMENT = 100

def remap(a: float, b: float, c: float, d: float, x: float) -> float:
    """
    Remap a value from one range to another. This is useful for converting screen coordinates to tilemap coordinates.

    @type a: float
    @param a: The minimum value of the source range. This must not be None.
    @type b: float
    @param b: The maximum value of the source range. This must not be None.
    @type c: float
    @param c: The minimum value of the destination range. This must not be None.
    @type d: float
    @param d: The maximum value of the destination range. This must not be None.
    @type x: float
    @param x: The value to remap. This must not be None.
    @rtype: float
    @returns: A floating point value in the new range that is equivalent to the source range value.
    """
    return c + (x - a) * (d - c) / (b - a)

def handle_upgrade_click(kind: int, score: Score, tilemap: TileMap, x: int, y: int) -> None:
    """
    Handle clicks on upgrade items.

    @type kind: int
    @param kind: The kind of upgrade. This must be an UPGRADE_KIND value.
    @type score: Score
    @param score: The current game Score. This must not be None.
    @type tilemap: TileMap
    @param tilemap: A TileMap representing the current state of the game. This must not be None.
    @type x: int
    @param x: The x-axis position of the upgrade item's tile. This must not be None.
    @type y: int
    @param y: The y-axis position of the upgrade item's tile. This must not be None.
    """
    # FIXME: We need to implement what happens when an upgrade is clicked.
    pass

def handle_remove_upgrade(clickable: Clickable, tilemap: TileMap, x: int, y: int) -> None:
    """
    Remove an upgrade item from the game, even if it hasn't been clicked.

    @type clickable: Clickable
    @param clickable: The Clickable that represents the upgrade item. This must not be None.
    @type tilemap: TileMap
    @param tilemap: A TileMap representing the current state of the game. This must not be None.
    @type x: int
    @param x: The x-axis position of the upgrade item's tile. This must not be None.
    @type y: int
    @param y: The y-axis position of the upgrade item's tile. This must not be None.
    """
    # FIXME: We need to handle removing upgrades after a Timer is fired too.
    pass

def add_upgrade(tilemap: TileMap, spritemap: SpriteMap, score: Score, timers: list) -> None:
    """
    Add an upgrade item to the game.

    @type tilemap: TileMap
    @param tilemap: A TileMap representing the current state of the game. This must not be None.
    @type spritemap: SpriteMap
    @param spritemap: A map of Sprites to retrieve upgrade item Sprites from. This must not be None.
    @type score: Score
    @param score: The current game Score. This must not be None.
    @type timers: list
    @param timers: A list of Timer objects that are currently being processed by the game loop. This must not be None.
    """
    if random.randint(1, 100) <= 100 - UPGRADE_PERCENTAGE:
        return
    kind = random.choice((UPGRADE_KIND_MULT, UPGRADE_KIND_BASE))
    sprite = None
    if kind == UPGRADE_KIND_MULT:
        sprite = spritemap.get(8, 3)
    else:
        sprite = spritemap.get(10, 2)
    empty = [ ]
    for i in range(tilemap.height()):
        for j in range(tilemap.width()):
            if tilemap.get_tile(j, i) is None:
                empty.append((j, i))
    if len(empty) > 0:
        x, y = random.choice(empty)
        tilemap.set_tile(x, y, Clickable(sprite, handle_upgrade_click, (kind, score, tilemap, x, y)))
        timers.append(Timer(random.randint(1, 5), False, handle_remove_upgrade, (tilemap.get_tile(x, y), tilemap, x, y)))

pygame.init()
clock = pygame.time.Clock()
quitting = False
screen = pygame.display.set_mode((WIDTH, HEIGHT), flags=pygame.RESIZABLE)
pygame.display.set_caption("Garden Clicker")
scaled = pygame.surface.Surface((WIDTH, HEIGHT), flags=pygame.SRCALPHA)
spritemap = SpriteMap("sprites.png", TileMap.TILE_SIZE, TileMap.TILE_SIZE)
tilemap = TileMap(3, 3)
score = Score()
tilemap.set_tile(1, 1, Clickable(spritemap.get(5, 0), score.increment))
typeface = pygame.font.Font("kenney_blocks.ttf", 24)
delta_time = 0.0
timers = [ Timer(1, True, score.increment_by, (SCORE_PER_SECOND, )) ]
# This timer requires a reference to the timers list, so it has to be appended here.
timers.append(Timer(2, True, add_upgrade, (tilemap, spritemap, score, timers)))
while not quitting:
    for timer in timers:
        timer.update(delta_time)
        if not timer.is_running():
            timers.remove(timer)
    screen.fill((0, 128, 0))
    pygame.transform.scale(tilemap.render(), (screen.get_width(), screen.get_height()), dest_surface=scaled)
    screen.blit(scaled, (0, 0))
    ui = f"Score: ${score}    ${to_human_readable(score.base_increment())} \u00d7 {to_human_readable(score.multiplier())} / Click "
    screen.blit(typeface.render(ui, False, pygame.Color(255, 255, 255)), (5, 0))
    pygame.display.flip()
    delta_time = clock.tick() / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        elif event.type == pygame.WINDOWRESIZED:
            scaled = pygame.Surface((event.x, event.y), flags=pygame.SRCALPHA)
        elif event.type == pygame.MOUSEBUTTONUP:
            # FIXME: Something must be done to handle game clicks. However, clicks are in screen coordinates and not
            #        game coordinates!!
            pass
pygame.quit()
