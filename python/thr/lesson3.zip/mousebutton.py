from dataclasses import dataclass
import pygame

WIDTH = 640
HEIGHT = 360

@dataclass
class Position:
    x: int = 0
    y: int = 0

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), flags=pygame.RESIZABLE)
typeface = pygame.font.Font(pygame.font.get_default_font(), 24)
position = Position()
quitting = False
while not quitting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quitting = True
        elif event.type == pygame.MOUSEBUTTONUP:
            position.x = event.pos[0]
            position.y = event.pos[1]
    screen.fill(pygame.Color(0, 0, 0))
    text = "Last Click: (" + str(position.x) + ", " + str(position.y) + ")"
    rendered_text = typeface.render(text, True, pygame.Color(255, 255, 255))
    text_x = int(screen.get_width() / 2) - int(rendered_text.get_width() / 2)
    text_y = int(screen.get_height() / 2) - int(rendered_text.get_height() / 2)
    screen.blit(rendered_text, (text_x, text_y))
    pygame.display.flip()
pygame.quit()


