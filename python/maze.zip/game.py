"""
This module handles I/O and terminal configuration for a simple interactive game. It also provides utilities for
terminal output including pixel oriented images, and a randomized maze generator.
"""
import platform
import sys
import os
import math
import time
import random
import io
from enum import Enum

if platform.system() == "Windows":
    import msvcrt
elif platform.system() == "Linux" or platform.system() == "Darwin":
    import tty
    import termios
    import select
else:
    raise RuntimeError("Your system is unsupported by py.")

class Pixel:
    """
    Represents a single pixel in a raster image. This type is mutable.
    """
    def __init__(self, r, g, b):
        """
        Constructs a new pixel using integer data.

        @type r: int
        @param r: The value of the red channel. This must be between 0 and 255.
        @type g: int
        @param g: The value of the green channel. This must be between 0 and 255.
        @type b: int
        @param b: The value of the blue channel. This must be between 0 and 255.
        """
        self.__rgb = bytes((r, g, b))
    def copy(self):
        """
        Copies a pixel and returns the copy.

        @rtype: Pixel
        @returns: A deep copy of the parent Pixel.
        """
        return Pixel(self.red(), self.green(), self.blue())
    def red(self):
        """
        Gets the red channel value of the pixel.

        @rtype: int
        @returns: A value between 0 and 255 representing the intensity.
        """
        return self.__rgb[0]
    def green(self):
        """
        Gets the green channel value of the pixel.

        @rtype: int
        @returns: A value between 0 and 255 representing the intensity.
        """
        return self.__rgb[1]
    def blue(self):
        """
        Gets the blue channel value of the pixel.

        @rtype: int
        @returns: A value between 0 and 255 representing the intensity.
        """
        return self.__rgb[2]

    def __eq__(self, rhs):
        """
        Compares two pixels to determine if they are equal.

        @type rhs: Pixel
        @param rhs: The other Pixel for comparison.
        @rtype: bool
        @returns: True if both Pixels have the same channel data. False otherwise.
        """
        return self.__rgb == rhs.__rgb
    def __str__(self):
        """
        Converts a Pixel to a string for output.

        @rtype: str
        @returns: A string representing the Pixel as a tuple. This is formatted as "(r, g, b)".
        """
        return str(self.to_tuple())
    def to_tuple(self):
        """
        Converts a Pixel to a 3-tuple for ease of comparison and output.

        @rtype: tuple
        @returns: A 3-tuple containing red, green, and blue color channel data in that order.
        """
        return tuple(self.__rgb)

def clamp(v, l, h):
    """
    Clamps a value between a maximum and minimum. The exact input types don't matter as long as they define greater
    than and less than operations coherently.

    @param v: The value to clamp.
    @param l: The minimum acceptable value.
    @param h: The maximum acceptable value.
    @returns: l if v < l, h if v > h, or otherwise v.
    """
    if v > h:
        return h
    if v < l:
        return l
    return v

class Image:
    """
    Represents a raster image using Pixels as data.
    """
    @staticmethod
    def __remap(a, b, c, d, x):
        """
        Remap a value from one range to another. This is useful for taking colors into normalized [0, 1] space or into
        binary [0, 255] space.

        @type a: float
        @param a: The minimum value of the source range.
        @type b: float
        @param b: The maximum value of the source range.
        @type c: float
        @param c: The minimum value of the destination range.
        @type d: float
        @param d: The maximum value of the destination range.
        @type x: float
        @param x: The value to remap.
        @rtype: float
        @returns: A floating point value in the new range that is equivalent to the source range value.
        """
        return c + (x - a) * (d - c) / (b - a)

    @staticmethod
    def __flt(a, b, epsilon = 1e-10):
        """
        Determine if a floating point value is less than some other floating point value using an epsilon.

        @type a: float
        @param a: The first value to consider.
        @type b: float
        @param b: The second value to consider.
        @type epsilon: float
        @param epsilon: An epsilon (minimum difference) value. This defaults to 1e-10.

        @rtype: bool
        @returns: True if |a - b| > epsilon and a < b. Otherwise False.
        """
        return math.fabs(a - b) > epsilon and a < b

    @staticmethod
    def __srgb_gamma(l):
        """
        Gamma encode/transfer a linear normalized color value into sRGB colorspace.

        @type l: float
        @param l: A linear color value in the range [0, 1].
        @rtype: float
        @returns: An sRGB encoded color value matching the input linear value.
        """
        if Image.__flt(l, 0.0031308):
            return 12.92 * l
        else:
            return 1.055 * l ** (1 / 2.4) - 0.055

    @staticmethod
    def __bt709_degamma(v):
        """
        Decode for a normalized color value from BT.709 into linear space.

        @type v: float
        @param v: A BT.709 color value in the range [0, 1].
        @rtype: float
        @returns: A linear color value matching the input value.
        """
        if Image.__flt(v, 0.081):
            return v / 4.5
        else:
            return ((v + 0.099) / 1.099) ** (1.0 / 0.45)

    @staticmethod
    def __next_line(file):
        """
        Locate the next line of a PPM file. This skips any comment lines in the file.

        @param file: A file like object containing valid NetPBM PPM data. The file should be in binary mode.
        @rtype: str
        @return An ASCII encoded line of text. The line does not include a line ending (e.g., "\n").
        """
        line = file.readline().decode("ascii").strip()
        while line.startswith("#"):
            line = file.readline().decode("ascii").strip()
        return line

    @staticmethod
    def __load_ppm_data(file):
        """
        Load NetPBM PPM file data into an Image.

        @param file: A file like object containing valid NetPBM PPM data. The file should be in binary mode.
        @rtype: Image
        @return An Image containing pixel data decoded from the input file.
        """
        magic = file.readline().decode("ascii").strip()
        if magic != "P6":
            raise RuntimeError("Invalid image format: \"" + str(magic) + "\".")
        lines = [ ]
        while len(lines) < 3:
            lines.extend(Image.__next_line(file).split())
        width = int(lines[0])
        height = int(lines[1])
        maxcolor = int(lines[2])
        bytes_per_channel = 1 if maxcolor < 256 else 2
        res = Image(width, height)
        for i in range(height):
            for j in range(0, width):
                red = Image.__remap(0, maxcolor, 0, 1, int.from_bytes(file.read(bytes_per_channel), byteorder="big"))
                green = Image.__remap(0, maxcolor, 0, 1, int.from_bytes(file.read(bytes_per_channel), byteorder="big"))
                blue = Image.__remap(0, maxcolor, 0, 1, int.from_bytes(file.read(bytes_per_channel), byteorder="big"))
                red = int(Image.__remap(0, 1, 0, 255, Image.__bt709_degamma(red)))
                green = int(Image.__remap(0, 1, 0, 255, Image.__bt709_degamma(green)))
                blue = int(Image.__remap(0, 1, 0, 255, Image.__bt709_degamma(blue)))
                res.set(j, i, Pixel(red, green, blue))
        return res

    @staticmethod
    def load_ppm(path):
        """
        Load a PPM file and convert it to an Image.

        @param path: The path to the desired file to load.
        @rtype: Image
        @returns: An Image object loaded with the data in the indicated file. The resulting image will be processed using
                  the ITU-R BT.709 gamma transfer function.
        """
        file = open(path, "rb")
        try:
            return Image.__load_ppm_data(file)
        finally:
            file.close()
    def __init__(self, width, height):
        """
        Constructs a new image with the specified width and height.

        @type width: int
        @param width: The width of the image in Pixels. This must be greater than 0.
        @type height: int
        @param height: The height of the image in Pixels. This must be greater than 0.
        """
        if type(width) is not int or type(height) is not int:
            raise RuntimeError("Image dimensions must be integer values.")
        if width < 1 or height < 1:
            raise RuntimeError("Images must have at least one pixel.")
        self.__width = width
        self.__height = height
        # The raster is 2 dimensional and must be accessed as such.
        self.__raster = [ Pixel(0, 0, 0) ] * (width * height)
        self.__compiled = None
    def copy(self):
        res = Image(self.__width, self.__height)
        res.__raster = self.__raster.copy()
        res.__compiled = self.__compiled
        return res
    def get(self, x, y):
        """
        Get a Pixel from the Image's raster grid.

        @type x: int
        @param x: The x-axis coordinate of the desired Pixel. This must be within the bounds of the raster grid or
                  an error will be raised.
        @type y: int
        @param y: The y-axis coordinate of the desired Pixel. This must be within the bounds of the raster grid or
                  an error will be raised.
        @rtype: Pixel
        @returns: The Pixel at (x, y) in the raster.
        """
        return self.__raster[y * self.__width + x]
    def set(self, x, y, pixel):
        """
        Set a Pixel from the Image's raster grid.

        @type x: int
        @param x: The x-axis coordinate of the desired Pixel. This must be within the bounds of the raster grid or
                  an error will be raised.
        @type y: int
        @param y: The y-axis coordinate of the desired Pixel. This must be within the bounds of the raster grid or
                  an error will be raised.
        @type pixel: Pixel
        @param pixel: The Pixel data to set the cell at (x, y) to.
        """
        if type(pixel) is not Pixel:
            raise RuntimeError("Pixel data must actually be pixel data.")
        self.__raster[y * self.__width + x] = pixel
        self.__compiled = None
    def width(self):
        """
        Get the Image's width.

        @rtype: int
        @returns: The width of the image as provided at construction.
        """
        return self.__width
    def height(self):
        """
        Get the Image's height.

        @rtype: int
        @returns: The height of the image as provided at construction.
        """
        return self.__height
    def compile(self):
        """
        Compile the image to a string that can be sent directly to a compatible terminal for output. The result is
        cached so that the image is only recompiled if its pixel data has changed. This also performs run-length
        encoding, which means minimal pixel data is written with runs being encoded as sequences of " ".

        @rtype: str
        @returns: A string containing the color data of the image encoded as virtual terminal command sequences.
        """
        if self.__compiled:
            return self.__compiled
        last = None
        buffer = [ ]
        for i in range(self.__height):
            for j in range(self.__width):
                pixel = self.get(j, i)
                if not last:
                    red = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.red())))
                    green = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.green())))
                    blue = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.blue())))
                    buffer.extend(f"\x1b[48;2;{int(red)};{int(green)};{int(blue)}m")
                    last = pixel
                elif last != pixel:
                    red = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.red())))
                    green = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.green())))
                    blue = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.blue())))
                    buffer.extend(f"\x1b[0m\x1b[48;2;{int(red)};{int(green)};{int(blue)}m")
                    last = pixel
                buffer.extend(" ")
            buffer.extend("\n")
        buffer.extend("\x1b[0m")
        self.__compiled = "".join(buffer)
        return self.__compiled
    def deltacompile(self, prev):
        """
        Compile the image to a string that can be sent directly to a compatible terminal for output. The result is
        not cached, unlike Image.compile(). This performs delta compression on the output data. Essentially, only pixel
        data that has changed from the previous frame is encoded into the output string. Instead of writing the whole
        frame, this generates cursor operations to move around the screen.

        @type prev: Image
        @param prev: The previous Image used in delta compression comparisons. Where a pixel has changed, a new value
                     will be emitted.
        @rtype: str
        @returns: A string containing the color data of the image encoded as virtual terminal command sequences.
        """
        buffer = [ ]
        current_color = None
        for i in range(self.__height):
            for j in range(self.__width):
                pixel = self.get(j, i)
                if pixel != prev.get(j, i):
                    buffer.extend(f"\x1b[{i + 1};{j + 1}H")
                    if not current_color or pixel != current_color:
                        red = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.red())))
                        green = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.green())))
                        blue = self.__remap(0, 1, 0, 255, self.__srgb_gamma(self.__remap(0, 255, 0, 1, pixel.blue())))
                        buffer.extend(f"\x1b[48;2;{int(red)};{int(green)};{int(blue)}m")
                        current_color = pixel
                    buffer.extend(" ")
        buffer.extend("\x1b[0m")
        return "".join(buffer)
    def clear(self, pixel = Pixel(0, 0, 0)):
        """
        Fill the Image with Pixel data.

        @type pixel: Pixel
        @param pixel: The Pixel to use with as a filler for the image. This defaults to Pixel(0, 0, 0) (black).
        """
        for i in range(self.__width * self.__height):
            self.__raster[i] = pixel
        self.__compiled = None
    def blit(self, src_image, src_x, src_y, dst_x, dst_y, width, height, transparent=None):
        """
        Copy a block from the source Image into the current Image pixel-by-pixel.

        @type src_image: Image
        @param src_image: The source Image to copy Pixel data from.
        @type src_x: int
        @param src_x: The left-most position in src_image to copy data from.
        @type src_y: int
        @param src_y: The top-most position in src_image to copy data from.
        @type dst_x: int
        @param dst_x: The left-most position in the image to copy data to.
        @type dst_y: int
        @param dst_y: The top-most position in the image to copy data to.
        @type width: int
        @param width: The width of the desired block to transfer.
        @type height: int
        @param height: The height of the desired block to transfer.
        """
        # Adjust width/height to avoid out of range access.
        width = min(width, src_image.width() - src_x, self.__width - dst_x)
        height = min(height, src_image.height() - src_y, self.__height - dst_y)
        # If either width or height is still out of range, return immediately.
        if width <= 0 or height <= 0:
            return
        # Copy pixels from the source block to the destination block.
        for y in range(height):
            for x in range(width):
                pixel = src_image.get(src_x + x, src_y + y)
                # If the pixel is "transparent", immediately move to the next pixel.
                if transparent and pixel == transparent:
                      continue
                self.set(dst_x + x, dst_y + y, pixel)
        self.__compiled = None

class Stopwatch:
    """
    A simple time keeping class.
    """
    def __init__(self):
        """
        Construct a new Stopwatch and start it immediately.
        """
        self.__start = time.process_time_ns()
    def reset(self):
        """
        Reset the Stopwatch and return the previously recorded duration in seconds.

        @rtype: float
        @returns: The duration between the last reset and the current time in seconds.
        """
        res = (time.process_time_ns() - self.__start) * 1e-9
        self.__start = time.process_time_ns()
        return res

class AverageFrameRate:
    """
    A class that calculates a rolling average of the current framerate.
    """
    def __init__(self):
        """
        Construct a new AverageFrameRate with a framerate of 0.
        """
        self.__average = 0.0
    def update(self, delta_time):
        """
        Accumulate time and average it to compute a new framerate.

        @type delta_time: float
        @param delta_time: The time required to draw the previous frame of data.
        """
        self.__average += (delta_time - self.__average) * 0.03
    def get(self):
        """
        Retrieve the average framerate of the application.

        @rtype: float
        @returns: The average framerate in Hertz.
        """
        return 1 / self.__average if self.__average != 0.0 else 0.0
    def __str__(self):
        """
        Retrieve the string representation of the average framerate of the application.

        @rtype: str
        @returns: A string representing the average framerate in Hertz.
        """
        return str(1 / self.__average) if self.__average != 0.0 else str(0.0)

class SpecialKey(Enum):
    """
    An enumeration of special (non-alphanumeric) keys understood by the application.
    """
    Invalid = 0
    Up = 1
    Down = 2
    Left = 3
    Right = 4
    Home = 5
    End = 6
    Function1 = 7
    Function2 = 8
    Function3 = 9
    Function4 = 10
    Function5 = 11
    Function6 = 12
    Function7 = 13
    Function8 = 14
    Function9 = 15
    Function10 = 16
    Function11 = 17
    Function12 = 18
    NumpadSpace = 19
    NumpadTab = 20
    NumpadEnter = 21
    NumpadPF1 = 22
    NumpadPF2 = 22
    NumpadPF3 = 23
    NumpadPF4 = 24
    NumpadMultiply = 25
    NumpadAdd = 26
    NumpadComma = 27
    NumpadMinus = 28
    NumpadPeriod = 29
    NumpadDivide = 30
    Numpad0 = 31
    Numpad1 = 32
    Numpad2 = 33
    Numpad3 = 34
    Numpad4 = 35
    Numpad5 = 36
    Numpad6 = 37
    Numpad7 = 38
    Numpad8 = 39
    Numpad9 = 40
    NumpadEqual = 41
    Insert = 42
    Delete = 43
    PageUp = 44
    PageDown = 45
    Escape = 46
    def __str__(self):
        """
        Retrieve the string representation of a SpecialKey.

        @rtype: str
        @returns: A string representing the name of the corresponding SpecialKey.
        """
        return self.name

__terminal_settings = None
__polling = None
__keymap = None
__displaybuffer = bytearray()
victory = None
gameover = None

if platform.system() == "Windows":
    __keymap = { b"\x48": SpecialKey.Up, b"\x50": SpecialKey.Down, b"\x4b": SpecialKey.Left,
                 b"\x4d": SpecialKey.Right, b"\x47": SpecialKey.Home, b"\x4f": SpecialKey.End }
elif platform.system() == "Linux" or platform.system() == "Darwin":
    __keymap = { b"\x1bOA": SpecialKey.Up, b"\x1bOB": SpecialKey.Down, b"\x1bOC": SpecialKey.Right,
                 b"\x1bOD": SpecialKey.Left, b"\x1bOH": SpecialKey.Home, b"\x1bOF": SpecialKey.End, }

def emit(data):
    """
    Emit data to the display. Data is buffered an only emitted after a flush.

    @type data: str
    @param data: A string to emit to the display.
    """
    global __displaybuffer
    __displaybuffer.extend(data.encode("ascii"))

def flush():
    """
    Flush data to the display.
    """
    global __displaybuffer
    os.write(sys.stdout.fileno(), __displaybuffer)
    __displaybuffer.clear()

def poll_event():
    """
    Poll for event data.

    @rtype: str|SpecialKey|None
    @returns: If an alphanumeric key was struck, this returns the key's string representation. If a SpecialKey was
              struck, and that SpecialKey was understood by the application it returns the corresponding SpecialKey
              value. If the SpecialKey wasn't understood, it may return SpecialKey.Escape. In all other it returns
              None.
    """
    global __keymap
    if platform.system() == "Windows":
        if msvcrt.kbhit():
            data = msvcrt.getch()
            if data in b"\x00\xe0":
                key = msvcrt.getch()
                if key in __keymap:
                    return __keymap[key]
            return data.decode("ascii")
    else:
        global __polling
        available = __polling.poll(1)
        data = sys.stdin.buffer.read(1)
        if len(data) == 0:
            return None
        if data != b"\x1b":
            return data.decode("ascii")
        else:
            sequence = bytearray(5)
            sequence[0] = 0x1b
            index = 1
            buffer = bytearray(1)
            count = sys.stdin.buffer.readinto(buffer)
            while count and index < len(sequence):
                sequence[index] = buffer[0]
                index += 1
                key = bytes(sequence[:index])
                if key in __keymap:
                    return __keymap[key]
                count = sys.stdin.buffer.readinto(buffer)
            return SpecialKey.Escape
    return None

def init():
    """
    Initialize the game display.
    """
    if not sys.stdin.isatty():
        raise RuntimeError("py requires an interactive terminal.")
    emit("\x1b[?1049h\x1b=\x1b[?1h\x1b[?25l\x1b[2J\x1b[3J\x1b[0;0H")
    flush()
    if platform.system() == "Linux" or platform.system() == "Darwin":
        global __terminal_settings
        global __polling
        __terminal_settings = termios.tcgetattr(sys.stdin.fileno())
        settings = __terminal_settings.copy()
        settings[3] &= ~(termios.ICANON | termios.ECHO)
        settings[3] |= termios.ISIG
        settings[6][termios.VMIN] = 0
        settings[6][termios.VTIME] = 0
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, settings)
        __polling = select.poll()
        __polling.register(sys.stdin.fileno(), select.POLLIN)
    global victory
    global gameover
    victory = Image.load_ppm("victory.ppm")
    gameover = Image.load_ppm("gameover.ppm")

def quit():
    """
    Clean up the game display.
    """
    global victory
    global gameover
    victory = None
    gameover = None
    if platform.system() == "Linux" or platform.system() == "Darwin":
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, __terminal_settings)
    emit("\x1b[?1l\x1b>\x1b[?1049l\x1b[?25h")
    flush()

def screen_size():
    """
    Retrieve the size of the screen in pixels.

    @rtype: tuple
    @returns: A 2-tuple (pair) of integer values. The first value is the display width and the second is the display
              height.
    """
    size = os.get_terminal_size()
    return (size[0], size[1] - 1)

def clear():
    """
    Reset the display cursor to (0, 0).
    """
    emit("\x1b[0;0H")

__lastbuffer = None

def blank():
    """
    Reset the display and fill it with blank data.
    """
    emit("\x1b[2J\x1b[3J\x1b[0;0H")

def display(image):
    """
    Display an image on the screen.

    @type image: Image
    @param image: The image to be displayed.
    """
    global __lastbuffer
    if __lastbuffer is None:
        emit(image.compile())
    else:
        emit(image.deltacompile(__lastbuffer))
    emit(f"\x1b[{image.height() + 1};0H")
    flush()
    __lastbuffer = image.copy()

def wait(seconds):
    """
    Pause execution for the desired number of seconds.

    @type seconds: float
    @param seconds: A number of seconds to wait for.
    """
    time.sleep(seconds)

def _frontier(distance, x, y, width, height):
    """
    Find frontier cells during maze generation.

    @type distance: int
    @param distance: The distance in cells to inspect.
    @type x: int
    @param x: The x position of the current cell.
    @type y: int
    @param y: The y position of the current cell.
    @type width: int
    @param width: The width of the maze in cells.
    @type height: int
    @param height: The height of the maze in cells.
    @rtype: list[tuple]
    @returns: A list of 2-tuple positions of valid cells distance units from (x, y).
    """
    cells = [ ]
    if x - distance >= 0:
        cells.append((x - distance, y))
    if x + distance < width:
        cells.append((x + distance, y))
    if y - distance >= 0:
        cells.append((x, y - distance))
    if y + distance < height:
        cells.append((x, y + distance))
    return cells

def _frontier_walls(cells, x, y):
    """
    Find the set of frontier cells of a given cell that are walls.

    @type cells: Image
    @param cells: An Image containing the cell data of the maze.
    @type x: int
    @param x: The current x position to inspect.
    @type y: int
    @param y: The current y position to inspect.
    @rtype: set[tuple]
    @returns: A set of 2-tuple positions of frontier cells that are walls.
    """
    indices = _frontier(2, x, y, cells.width(), cells.height())
    return { index for index in indices if cells.get(*index) == Pixel(0, 0, 0)  }

def _frontier_passages(cells, x, y):
    """
    Find the set of frontier cells of a given cell that are passages.

    @type cells: Image
    @param cells: An Image containing the cell data of the maze.
    @type x: int
    @param x: The current x position to inspect.
    @type y: int
    @param y: The current y position to inspect.
    @rtype: set[tuple]
    @returns: A set of 2-tuple positions of frontier cells that passages.
    """
    indices = _frontier(2, x, y, cells.width(), cells.height())
    return { index for index in indices if cells.get(*index) != Pixel(0, 0, 0) }

def _distance(x1, y1, x2, y2):
    """
    Find the distance between two points.

    @type x1: int|float
    @param x1: The first x position.
    @type y1: int|float
    @param y1: The first y position.
    @type x2: int|float
    @param x2: The second x position.
    @type y2: int|float
    @param y2: The second y position.
    @rtype: tuple
    @returns: A 2-tuple position indicating the distance between the input points along the x and y axes.
    """
    return (x2 - x1, y2 - y1)

def _normalize(x):
    """
    Remap a value into the range [-1, 1].

    @param x: The value to remap.
    @rtype: int
    @returns 1 if x > 0, -1 if x < 0 and otherwise 0.
    """
    if x > 0:
        return 1
    elif x < 0:
        return -1
    return 0

def generate_maze(width, height):
    """
    Generate a randomized maze as an Image.

    @type width: int
    @param width: The width of the maze in Pixels.
    @type height: int
    @param height: The height of the maze in Pixels.
    @rtype: Image
    @returns: A width*height pixel Image with a maze drawn into it.
    """
    cells = Image(width, height)
    index = (0, 0)
    cells.set(0, 0, Pixel(255, 0, 255))
    walls = _frontier_walls(cells, *index)
    wall = None
    while len(walls) != 0:
        if wall:
            cells.set(*wall, Pixel(255, 255, 255))
        wall = random.choice(list(walls))
        neighbors = _frontier_passages(cells, *wall)
        selected = random.choice(list(neighbors))
        delta = _distance(*selected, *wall)
        index = (selected[0] + _normalize(delta[0]), selected[1] + _normalize(delta[1]))
        cells.set(*index, Pixel(255, 255, 255))
        cells.set(*wall, Pixel(0, 255, 0))
        walls.remove(wall)
        walls |= _frontier_walls(cells, *wall)
    return cells


class Position:
    """
    A class representing an (x, y) coordinate.
    """
    def __init__(self, x = 0, y = 0):
        """
        Constructs a position.

        @type x: int
        @param x: The x-axis coordinate. Defaults to 0.
        @type y: int
        @param y: The y-axis coordinate. Defaults to 0.
        """
        self.x = x
        self.y = y
    def copy(self):
        """
        Create a copy of a Position.

        @rtype: Position
        @returns: A deep-copy of the Position.
        """
        return Position(self.x, self.y)
