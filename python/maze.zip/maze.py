import sys

import game

EASY = (20, 23)
MEDIUM = (40, 23)
HARD = (80, 23)

PLAYING = 0
QUITTING = 1
WON = 2

CONTROL_UP = 0
CONTROL_DOWN = 1
CONTROL_LEFT = 2
CONTROL_RIGHT = 3
CONTROL_QUIT = 4

def in_bounds(maze, position):
    """
    Determines if a position is in bounds in the given maze.

    @type maze: game.Image
    @param maze: The maze to inspect.
    @type position: game.Position
    @param position: The (x, y) position to inpsect maze at.
    @rtype: bool
    @returns: False if position is out of bounds or if the pixel at position is black. Otherwise True.
    """
    # Check if the position is in bounds and not inside a wall here.

def at_finish(maze, position):
    """
    Determines if a position is the winning pixel for the given maze.

    @type maze: game.Image
    @param maze: The maze to inspect.
    @type position: game.Position
    @param position: THe (x, y) position to inspect maze at.
    @rtype: bool
    @returns: True if the pixel at position is game.Pixel(0, 255, 0) (a/k/a green).
    """
    # Check if the position is the winning position here.

def camera(position, maze, backbuffer):
    """
    Compute the 2D position of the game's 2D camera.

    @type position: game.Position
    @param position: The (x, y) position of the player in the scene.
    @type maze: game.Image
    @param maze: The maze image.
    @type backbuffer: game.Image
    @param backbuffer: The image into which everything will be drawn before display.
    @rtype: game.Position
    @returns: An (x, y) position that should be used to control the game's viewport. That is, it should be used as the
              src_x and src_y values of a blit to backbuffer.
    """
    res = game.Position(position.x - backbuffer.width() // 2, position.y - backbuffer.height() // 2)
    res.x = max(0, min(res.x, maze.width() - backbuffer.width()))
    res.y = max(0, min(res.y, maze.height() - backbuffer.height()))
    return res

def read_inputs():
    """
    Retrieve an input from standard input and map it to a game action.

    @rtype: int|None
    @returns: One of CONTROL_UP, CONTROL_DOWN, CONTROL_LEFT, CONTROL_RIGHT, CONTROL_QUIT, or None.
    """
    ev = game.poll_event()
    if ev == game.SpecialKey.Up or ev == "w":
        return CONTROL_UP
    elif ev == game.SpecialKey.Down or ev == "s":
        return CONTROL_DOWN
    elif ev == game.SpecialKey.Left or ev == "a":
        return CONTROL_LEFT
    elif ev == game.SpecialKey.Right or ev == "d":
        return CONTROL_RIGHT
    elif ev == "q" or ev == "Q":
        return CONTROL_QUIT
    return None

def update_state(ev, maze, position):
    """
    Update the game's mutable state.

    @type ev: int|None
    @param ev: The last action the player took, or None.
    @type maze: game.Image
    @param maze: The game maze.
    @type position: The current position. This will be updated if the player successfully moves.
    @rtype: int
    @returns: The next state for the game. One of: QUITTING, WON, and PLAYING.
    """
    if maze.get(position.x, position.y) == game.Pixel(255, 255, 255):
        maze.set(position.x, position.y, game.Pixel(0, 128, 255))
    next = position.copy()
    if ev == CONTROL_QUIT:
        return QUITTING
    elif ev == CONTROL_UP:
        # Move the player up one row
    elif ev == CONTROL_DOWN:
        # Move the player down one row
    elif ev == CONTROL_LEFT:
        # Move the player left one column
    elif ev == CONTROL_RIGHT:
        # Move the player right one column
    if in_bounds(maze, next):
        # Update the player's position here
    if at_finish(maze, position):
        return WON
    return PLAYING

difficulty = None
if len(sys.argv) > 1:
    difficulty = sys.argv[1].lower().strip()
maze_size = None
# Build a solution to selecting the maze size here. You should use sys.argv and the EASY, MEDIUM, and HARD size tuples.
# Create your backbuffer Image here. It should be the size of the entire available screen minus one row.
maze = game.generate_maze(maze_size[0], maze_size[1])
player = game.Image(1, 1)
player.set(0, 0, game.Pixel(255, 0, 0))
position = game.Position(0, 0)
view = camera(position, maze, backbuffer)
quitting = False
state = PLAYING
fps = game.AverageFrameRate()
total_time = 0
game.init()
try:
    updatetime = game.Stopwatch()
    dt = 0
    while not quitting:
        try:
            backbuffer.clear()
            ev = read_inputs()
            if state == PLAYING:
                # Blit the maze and then the player to the backbuffer. For the maze, be sure to use the view as the
                # source (x, y) position of the blit.
                # For the player, be sure to use (position.x - view.x, position.y - view.y) for the destination
                # position of the blit.
                state = update_state(ev, maze, position)
                view = camera(position, maze, backbuffer)
            elif state == WON:
                backbuffer.blit(game.victory, 0, 0, 0, 0, game.victory.width(), game.victory.height())
            elif state == QUITTING:
                backbuffer.blit(game.gameover, 0, 0, 0, 0, game.gameover.width(), game.gameover.height())
            game.clear()
            game.display(backbuffer)
            dt = updatetime.reset()
            fps.update(dt)
            total_time += dt
            print("fps = " + str(fps)[:5] + " Hz difficulty = " + str(maze_size) + " time = " + str(int(total_time)) + " s")
        except KeyboardInterrupt:
            if state == QUITTING or state == WON:
                quitting = True
            else:
                state = QUITTING
except KeyboardInterrupt:
    pass
finally:
    game.quit()
