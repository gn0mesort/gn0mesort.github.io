import random

BOY_NAMES = { "Jude", "Liam", "Gabriel", "William", "Adam", "Dallas", "Charles", "Kenneth","Tristan", "Talon" }
GIRL_NAMES = { "Eve", "Madeleine", "Paige", "Samantha", "Zoe", "Armani", "Fernanda", "Amiyah", "Lilyanna", "Victoria" }
MAX_AGE = 11
MIN_AGE = 6

def create_student(name, age, grade, last_id):
    return (last_id + 1, name, age, grade)

def print_student(student):
    print("Student #" + str(student[0]) + ":")
    print("\tName: " + student[1])
    print("\tAge: " + str(student[2]))
    print("\tGrade: " + str(student[3]))

def grade_from_age(age):
    if age == 6:
        return 1
    elif age == 7:
        return random.randint(1, 2)
    elif age == 8:
        return random.randint(2, 3)
    elif age == 9:
        return random.randint(3, 4)
    elif age == 10:
        return random.randint(4, 5)
    elif age == 11:
        return 5
    else:
        return -1

def generate_students(count):
    # FIXME: We need to generate a set of random students here. Each student needs a name, age, grade, and ID number.
    # Some of this data should be random (name, age), but other data needs to be sane (ID, grade).
    pass

def search_by_name(students):
    # FIXME: We need to be able to find a student by looking at their name. This requires a type of approach called
    # a linear search.
    pass

def search_by_id(students):
    # FIXME: This works like the name search, but it should look for the ID instead.
    pass

def list_all(students):
    for student in students:
        print_student(student)

def filter_by_grade(students):
    # FIXME: We need to be able to filter students by their grade. That means we need to list all the students who
    # belong to a specific grade. We need to take two inputs for this, the maximum and minimum grade.
    pass

def filter_by_age(students):
    # FIXME: This is like filtering by grade, except with age.
    pass

students = generate_students(100)
quitting = False
while not quitting:
    print("Student Database")
    print("\t1. Search by name")
    print("\t2. Search by Student #")
    print("\t3. List all students")
    print("\t4. Filter by grade")
    print("\t5. Filter by age")
    print("\t0. Quit")
    choice = int(input("> "))
    if choice == 0:
        quitting = True
    elif choice == 1:
        search_by_name(students)
    elif choice == 2:
        search_by_id(students)
    elif choice == 3:
        list_all(students)
    elif choice == 4:
        filter_by_grade(students)
    elif choice == 5:
        filter_by_age(students)
