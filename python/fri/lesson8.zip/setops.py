twos = { 2, 4, 6, 8 }
threes = { 3, 6, 9 }
fives = { 5 }
even = { 0, 2, 4, 6, 8 }
odd = { 1, 3, 5, 7, 9 }
digits = even | odd
only_twos = digits & twos
only_evens = digits - odd
no_fives = digits ^ fives

print(digits)
print(only_twos)
print(only_evens)
print(no_fives)
