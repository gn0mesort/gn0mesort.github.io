names = { "Carl", "Steven", "John", "Francis", "John" }
for name in names:
    print(name)
