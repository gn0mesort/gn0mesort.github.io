i = 0
while i >= 0:
    i = int(input("Input a number, negative numbers exit: "))
    print(i)
