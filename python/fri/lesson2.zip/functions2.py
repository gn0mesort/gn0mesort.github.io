def fib(n):
    a = 0
    b = 1
    for i in range(n):
        tmp = a + b
        a = b
        b = tmp
    return b

for i in range(100):
    print(fib(i))
