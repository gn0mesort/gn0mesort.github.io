choice = input("Continue? ")
if choice == "yes":
    print("Continuing!")
else:
    print("Finished!")
