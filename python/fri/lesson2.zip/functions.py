def max_from_input():
    next = 0
    max = float("-inf")
    while next >= 0:
        next = int(input("Enter a number, negative numbers quit: "))
        if next > max and next >= 0:
            max = next
    print(max)
