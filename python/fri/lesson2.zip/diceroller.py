import random

def roll(count, sides):
    results = [ ]
    # FIXME: We need to figure out how to roll our dice. We have the number of dice (count) and how many sides each
    # die has. Now we need to generate the data.
    pass
    return results

quitting = False
score = 0
rolls = 0
while not quitting:
    # FIXME: We need to implement the rest of the game here.
    pass
print("Your final score is: " + str(score) + "\nYou rolled " + str(rolls) + " times.")
