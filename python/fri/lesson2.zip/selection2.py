import random

magic = random.randint(1, 100)
if magic > 50:
    print("You'll have good luck today!")
elif magic > 75:
    print("You'll have great luck today!!")
elif magic >= 99:
    print("Today is the luckiest day of your life!!!")
else:
    print("Bad luck!")
