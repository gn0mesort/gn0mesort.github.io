print("Hello!")
print("Goodbye!")
