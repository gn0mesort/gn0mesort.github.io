import sys
import math
import terminal

from enum import Enum

def fequal(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    abs_a = math.fabs(a)
    abs_b = math.fabs(b)
    difference = math.fabs(a - b)
    if a == b:
        return True
    elif a == 0 or b == 0 or abs_a + abs_b < sys.float_info.min:
        return difference < epsilon * sys.float_info.min
    else:
        return difference / min(abs_a + abs_b, sys.float_info.max) < epsilon

def flessthan(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    return a < b and not fequal(a, b, epsilon=epsilon)

def fgreaterthan(a: float, b: float, epsilon: float = sys.float_info.epsilon) -> bool:
    return a > b and not fequal(a, b, epsilon=epsilon)

def remap(x: int|float, a: int|float, b: int|float, c: int|float, d: int|float) -> int|float:
    """
    Remap a value from one range to another range.

    @type x: int|float
    @param x: The value to remap.
    @type a: int|float
    @param a: The minimum value (inclusive) of the current range.
    @type b: int|float
    @param b: The maximum value (inclusive) of the current range.
    @type c: int|float
    @param c: The minimum value (inclusive) of the new range.
    @type d: int|float
    @param d: The maximum value (inclusive) of the new range.
    @rtype: int|float
    @returns: The value of x remapped from [a, b] to [c, d].
    """
    return c + (x - a) * (d - c) / (b - a)

def map_srgb(linear: float) -> float:
    if linear <= 0.0031308:
        return 12.92 * linear
    else:
        return 1.055 * linear ** (1 / 2.4) - 0.055

def clamp(v, l, h):
    """
    Clamps a value between a maximum and minimum. The exact input types don't matter as long as they define greater
    than and less than operations coherently.

    @param v: The value to clamp.
    @param l: The minimum acceptable value.
    @param h: The maximum acceptable value.
    @returns: l if v < l, h if v > h, or otherwise v.
    """
    if v > h:
        return h
    if v < l:
        return l
    return v

class Color:
    __RED: int = 0
    __GREEN: int = 1
    __BLUE: int = 2

    @staticmethod
    def from_int(c: int):
        data = c.to_bytes(3, byteorder="little")
        return Color(data[0], data[1], data[2])
    @staticmethod
    def from_floats(r: float, g: float, b: float):
        return Color(remap(r, 0, 1, 0, 255), remap(g, 0, 1, 0, 255), remap(b, 0, 1, 0, 255))
    def __init__(self, r: int, g: int, b: int):
        self.__data = bytearray((0, ) * 3)
        self.__data[Color.__RED] = clamp(int(r), 0, 255)
        self.__data[Color.__GREEN] = clamp(int(g), 0, 255)
        self.__data[Color.__BLUE] = clamp(int(b), 0, 255)
    def copy(self):
        return Color(self.red(), self.green(), self.blue())
    def red(self) -> int:
        return self.__data[Color.__RED]
    def green(self) -> int:
        return self.__data[Color.__GREEN]
    def blue(self) -> int:
        return self.__data[Color.__BLUE]
    def set_red(self, r: int) -> None:
        self.__data[Color.__RED] = clamp(r, 0, 255)
    def set_green(self, g: int) -> None:
        self.__data[Color.__GREEN] = clamp(g, 0, 255)
    def set_blue(self, b: int) -> None:
        self.__data[Color.__BLUE] = clamp(b, 0, 255)
    def as_int(self) -> int:
        return int.from_bytes(self.__data, byteorder=sys.byteorder)
    def __str__(self) -> str:
        return f"#{self.__data[Color.__RED]:x}{self.__data[Color.__GREEN]:x}{self.__data[Color.__BLUE]:x}"
    def __eq__(self, other) -> bool:
        return self.__data == other.__data

class Cell:
    def __init__(self):
        self.__fgcolor = Color(255, 255, 255)
        self.__bgcolor = Color(0, 0, 0)
        self.__character = " "
    def copy(self):
        other = Cell()
        other.__fgcolor = self.__fgcolor.copy()
        other.__bgcolor = self.__bgcolor.copy()
        other.__character = self.__character
        return other
    def fgcolor(self) -> Color:
        return self.__fgcolor
    def set_fgcolor(self, fgcolor: Color) -> None:
        self.__fgcolor = fgcolor
    def bgcolor(self) -> Color:
        return self.__bgcolor
    def set_bgcolor(self, bgcolor: Color) -> None:
        self.__bgcolor = bgcolor
    def character(self) -> str:
        return self.__character
    def set_character(self, character: str) -> None:
        if len(character) == 0 or character.isspace():
            character = " "
        if len(character) != 1:
            RuntimeError("Cells can only contain exactly one character")
        self.__character = character

class Screen:
    __WIDTH: int = 80
    __HEIGHT: int = 24
    def __init__(self, width: int = 0, height: int = 0):
        tmp = [ ]
        width = max(width, Screen.__WIDTH)
        height = max(height, Screen.__HEIGHT)
        for i in range(width):
            for j in range(height):
                tmp.append(Cell())
        self.__buffer = tuple(tmp)
        self.__width = width
        self.__height = height
    def at(self, x: int, y: int) -> Cell:
        if x < 0 or x >= self.__width or y < 0 or y >= self.__height:
            raise RuntimeError(f"The index ({x}, {y}) is out of bounds.")
        return self.__buffer[y * self.__width + x]
    def print_at(self, x: int, y: int, line: str, fgcolor: Color = None, bgcolor: Color = None) -> None:
        for i, c in enumerate(line):
            if x + i >= self.__width:
                return
            cell = self.at(x + i, y)
            if c.isspace():
                cell.set_character(" ")
            else:
                cell.set_character(c)
            if fgcolor is not None:
                cell.set_fgcolor(fgcolor)
            if bgcolor is not None:
                cell.set_bgcolor(bgcolor)
    def fillbg(self, bgcolor: Color) -> None:
        for cell in self.__buffer:
            cell.set_bgcolor(bgcolor)
    def fillfg(self, fgcolor: Color) -> None:
        for cell in self.__buffer:
            cell.set_fgcolor(fgcolor)
    def fillcharacter(self, character: str) -> None:
        for cell in self.__buffer:
            cell.set_character(character)
    def clear(self):
        for cell in self.__buffer:
            cell.set_fgcolor(Color.from_int(0xffffff))
            cell.set_bgcolor(Color.from_int(0))
            cell.set_character(" ")
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def __str__(self):
        lastfg = Color(255, 255, 255)
        lastbg = Color(0, 0, 0)
        buffer = bytearray()
        buffer.extend("\x1b[38;2;255;255;255m\x1b[48;2;0;0;0m".encode("utf-8"))
        for i in range(self.__height):
            for j in range(self.__width):
                cell = self.at(j, i)
                if cell.fgcolor() != lastfg:
                    red = remap(cell.fgcolor().red(), 0, 255, 0, 1)
                    red = int(remap(map_srgb(red), 0, 1, 0, 255))
                    green = remap(cell.fgcolor().green(), 0, 255, 0, 1)
                    green = int(remap(map_srgb(green), 0, 1, 0, 255))
                    blue = remap(cell.fgcolor().blue(), 0, 255, 0, 1)
                    blue = int(remap(map_srgb(blue), 0, 1, 0, 255))
                    buffer.extend(f"\x1b[38;2;{red};{green};{blue}m".encode("utf-8"))
                    lastfg = cell.fgcolor().copy()
                if cell.bgcolor() != lastbg:
                    red = remap(cell.bgcolor().red(), 0, 255, 0, 1)
                    red = int(remap(map_srgb(red), 0, 1, 0, 255))
                    green = remap(cell.bgcolor().green(), 0, 255, 0, 1)
                    green = int(remap(map_srgb(green), 0, 1, 0, 255))
                    blue = remap(cell.bgcolor().blue(), 0, 255, 0, 1)
                    blue = int(remap(map_srgb(blue), 0, 1, 0, 255))
                    buffer.extend(f"\x1b[48;2;{red};{green};{blue}m".encode("utf-8"))
                    lastbg = cell.bgcolor().copy()
                buffer.extend(cell.character().encode("utf-8"))
            if i + 1 < self.__height:
                buffer.extend("\n".encode("utf-8"))
        buffer.extend("\x1b[0m".encode("utf-8"))
        return buffer.decode("utf-8")

class UpdateAction(Enum):
    Nothing = 0,
    Remove = 1,
    Position = 2

class Entity(Cell):
    def __init__(self):
            super().__init__()
            self.__x = 0
            self.__y = 0
    def x(self) -> int:
        return self.__x
    def set_x(self, x: int) -> int:
        self.__x = x
    def y(self) -> int:
        return self.__y
    def set_y(self, y: int) -> int:
        self.__y = y
    def position(self) -> (int, int):
        return (self.__x, self.__y)
    def set_position(self, x: int, y: int) -> None:
        self.__x = x
        self.__y = y
    def render(self, cell: Cell) -> None:
        cell.set_fgcolor(self.fgcolor())
        cell.set_bgcolor(self.bgcolor())
        cell.set_character(self.character())
    def update(self, ev: str|terminal.SpecialKey) -> UpdateAction:
        return UpdateAction.Nothing

class MapPosition:
    def __init__(self):
        self.__terrain = "X"
        self.__terrainbg = Color(0, 0, 0)
        self.__terrainfg = Color(255, 255, 255)
        self.__passable = False
    def terrain(self) -> str:
        return self.__terrain
    def fgcolor(self) -> Color:
        return self.__terrainfg.copy()
    def bgcolor(self) -> Color:
        return self.__terrainbg.copy()
    def is_passable(self) -> bool:
        return self.__passable
    def set_terrain(self, terrain: str) -> None:
        self.__terrain = terrain
    def set_bgcolor(self, bgcolor: Color) -> None:
        self.__terrainbg = bgcolor
    def set_fgcolor(self, fgcolor: Color) -> None:
        self.__terrainfg = fgcolor
    def set_passable(self, passable: bool) -> None:
        self.__passable = passable
    def render(self, cell: Cell) -> None:
        cell.set_character(self.__terrain)
        cell.set_bgcolor(self.__terrainbg)
        cell.set_fgcolor(self.__terrainfg)

class Map:
    def __init__(self, width: int, height: int):
        self.__width = width
        self.__height = height
        self.__data = [ MapPosition() for _ in range(self.__width * self.__height) ]
        self.__entities = [ ]
    def at(self, x: int, y: int) -> MapPosition:
        return self.__data[y * self.__width + x]
    def width(self) -> int:
        return self.__width
    def height(self) -> int:
        return self.__height
    def add_entity(self, entity: Entity) -> None:
        self.__entities.append(entity)
    def remove_entity(self, entity: Entity) -> None:
        self.__entities.remove(entity)
    def render(self, screen: Screen, dest: (int, int)) -> None:
        origin_x, origin_y = dest
        width = min(self.__width, screen.width())
        height = min(self.__height, screen.height())
        for i in range(height):
            for j in range(width):
                cell = screen.at(origin_x + j, origin_y + i)
                position = self.__data[i * self.__width + j]
                position.render(cell)
        for entity in self.__entities:
            x, y = entity.position()
            if x >= 0 and x < screen.width() and y >= 0 and y < screen.height():
                cell = screen.at(origin_x + x, origin_y + y)
                entity.render(cell)
    def update(self, ev: str|terminal.SpecialKey) -> None:
        for entity in self.__entities:
            current_x, current_y = entity.position()
            result = entity.update(ev)
            if result == UpdateAction.Remove:
                self.__entities.remove(entity)
            elif result == UpdateAction.Position:
                next_x, next_y = entity.position()
                if next_x < 0 or next_x >= self.__width:
                    entity.set_position(current_x, current_y)
                    return
                if next_y < 0 or next_y >= self.__height:
                    entity.set_position(current_x, current_y)
                    return
                if not self.at(next_x, next_y).is_passable():
                    entity.set_position(current_x, current_y)
                    return

class Player(Entity):
    def __init__(self):
        super().__init__()
        self.set_character("@")
        self.set_fgcolor(Color.from_floats(1, 0, 0))
    def update(self, ev: str|terminal.SpecialKey) -> UpdateAction:
        result = UpdateAction.Nothing
        if ev == "w" or ev == terminal.SpecialKey.Up:
            self.set_y(self.y() - 1)
            result = UpdateAction.Position
        elif ev == "s" or ev == terminal.SpecialKey.Down:
            self.set_y(self.y() + 1)
            result = UpdateAction.Position
        elif ev == "a" or ev == terminal.SpecialKey.Left:
            self.set_x(self.x() - 1)
            result = UpdateAction.Position
        elif ev == "d" or ev == terminal.SpecialKey.Right:
            self.set_x(self.x() + 1)
            result = UpdateAction.Position
        return result

class Base(Entity):
    def __color_from_ticks(self) -> Color:
        factor = self.__ticks / self.__max_ticks
        return Color.from_floats(factor, factor, 0)
    def __init__(self, character: str, max_ticks: int):
        super().__init__()
        self.__max_ticks = max_ticks
        self.__ticks = max_ticks
        self.set_character(character)
        self.set_fgcolor(self.__color_from_ticks())
    def update(self, ev) -> UpdateAction:
        self.__ticks = self.__ticks - 1
        self.set_fgcolor(self.__color_from_ticks())
        return UpdateAction.Nothing

class DayNightCycle(Entity):
    def __init__(self, is_day: bool, day_ticks: int, night_ticks: int):
        super().__init__()
        self.__day_ticks = day_ticks
        self.__night_ticks = night_ticks
        self.__is_day = is_day
        if self.__is_day:
            self.__ticks = self.__day_ticks
        else:
            self.__ticks = self.__night_ticks
    def is_day(self) -> bool:
        return self.__is_day
    def update(self, ev) -> UpdateAction:
        self.__ticks = self.__ticks - 1
        if self.__ticks <= 0:
            self.__is_day = not self.__is_day
            if self.__is_day:
                self.__ticks = self.__day_ticks
            else:
                self.__ticks = self.__night_ticks
        return UpdateAction.Nothing

