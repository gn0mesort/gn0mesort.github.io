path = input("Enter a file path: ")
file = open(path, "r")
for line in file:
    print(line)
file.close()
