file = open("hello.txt", "r")
done = False
while not done:
    character = file.read()
    if character == "":
        done = True
    else:
        print(character)
file.close()
