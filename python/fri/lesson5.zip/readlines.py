file = open("hello.txt", "r")
done = False
while not done:
    line = file.readline()
    if line != "":
        print(line)
    else:
        done = True
file.close()
