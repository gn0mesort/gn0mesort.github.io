file = open("output.txt", "w")
file.write("Hello, world!")
file.close()
