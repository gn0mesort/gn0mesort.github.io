from game import *
import terminal

def dimensions_from_line(line):
    # FIXME: The first line of each map file is two numbers that represent the width and the height of the map.
    # They are always in the format "WIDTH HEIGHT\n". We need to convert this from text to numbers and return both
    # numbers.
    pass

def load_map(path):
    # FIXME: We need to tell the program how to load the map file. The map file is made up of numbers with each
    # number representing a different type of tile. The first line of the file is the width of the map by the
    # height of the map. After that each line is a single row of map data.
    # 0 represents grass
    # 1 represents a wall
    # 2 represents water
    # 3 represents a bridge
    pass

def save_game(path, player):
    # FIXME: We need to save the player's position so that the game knows where to put the player on a reload.
    # To do this, we need to write a save file with that information.
    pass

def load_game(path, player):
    # FIXME: We need to load the game save data whenever we start the game back up. This is like the reverse of saving
    # the game.
    pass

terminal.init()
try:
    map = load_map("map.txt")
    terminal_width, terminal_height = terminal.screen_size()
    screen = Screen(terminal_width, terminal_height)
    player = Player()
    load_game("save.txt", player)
    map.add_entity(player)
    base = Base("^", 200)
    base.set_position(31, 7)
    map.add_entity(base)
    daynightcycle = DayNightCycle(True, 60, 40)
    daynightcycle.set_position(-1, -1)
    map.add_entity(daynightcycle)
    quitting = False
    while not quitting:
        ev = terminal.poll_event()
        if ev is not None:
            map.update(ev)
        screen.clear()
        map.render(screen, (0, 0))
        screen.print_at(0, map.height(), "Player at (" + str(player.x()) + ", " + str(player.y()) + ")")
        if daynightcycle.is_day():
            screen.print_at(0, map.height() + 1, "Day")
        else:
            screen.print_at(0, map.height() + 1, "Night")
        print(screen, end="")
except KeyboardInterrupt:
    pass
finally:
    save_game("save.txt", player)
    terminal.quit()
