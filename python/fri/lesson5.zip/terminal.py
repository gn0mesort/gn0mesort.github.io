import platform
import sys
import os
import math
import time
import random
import io
from enum import Enum

if platform.system() == "Windows":
    import msvcrt
elif platform.system() == "Linux" or platform.system() == "Darwin":
    import tty
    import termios
    import select
else:
    raise RuntimeError("Your system is unsupported by game.py.")

class Stopwatch:
    """
    A simple time keeping class.
    """
    def __init__(self):
        """
        Construct a new Stopwatch and start it immediately.
        """
        self.__start = time.process_time_ns()
    def reset(self):
        """
        Reset the Stopwatch and return the previously recorded duration in seconds.

        @rtype: float
        @returns: The duration between the last reset and the current time in seconds.
        """
        res = (time.process_time_ns() - self.__start) * 1e-9
        self.__start = time.process_time_ns()
        return res

class AverageFrameRate:
    """
    A class that calculates a rolling average of the current framerate.
    """
    def __init__(self):
        """
        Construct a new AverageFrameRate with a framerate of 0.
        """
        self.__average = 0.0
    def update(self, delta_time):
        """
        Accumulate time and average it to compute a new framerate.

        @type delta_time: float
        @param delta_time: The time required to draw the previous frame of data.
        """
        self.__average += (delta_time - self.__average) * 0.03
    def get(self):
        """
        Retrieve the average framerate of the application.

        @rtype: float
        @returns: The average framerate in Hertz.
        """
        return 1 / self.__average if self.__average != 0.0 else 0.0
    def __str__(self):
        """
        Retrieve the string representation of the average framerate of the application.

        @rtype: str
        @returns: A string representing the average framerate in Hertz.
        """
        return str(1 / self.__average) if self.__average != 0.0 else str(0.0)

class SpecialKey(Enum):
    """
    An enumeration of special (non-alphanumeric) keys understood by the application.
    """
    Invalid = 0
    Up = 1
    Down = 2
    Left = 3
    Right = 4
    Home = 5
    End = 6
    Function1 = 7
    Function2 = 8
    Function3 = 9
    Function4 = 10
    Function5 = 11
    Function6 = 12
    Function7 = 13
    Function8 = 14
    Function9 = 15
    Function10 = 16
    Function11 = 17
    Function12 = 18
    NumpadSpace = 19
    NumpadTab = 20
    NumpadEnter = 21
    NumpadPF1 = 22
    NumpadPF2 = 22
    NumpadPF3 = 23
    NumpadPF4 = 24
    NumpadMultiply = 25
    NumpadAdd = 26
    NumpadComma = 27
    NumpadMinus = 28
    NumpadPeriod = 29
    NumpadDivide = 30
    Numpad0 = 31
    Numpad1 = 32
    Numpad2 = 33
    Numpad3 = 34
    Numpad4 = 35
    Numpad5 = 36
    Numpad6 = 37
    Numpad7 = 38
    Numpad8 = 39
    Numpad9 = 40
    NumpadEqual = 41
    Insert = 42
    Delete = 43
    PageUp = 44
    PageDown = 45
    Escape = 46
    def __str__(self):
        """
        Retrieve the string representation of a SpecialKey.

        @rtype: str
        @returns: A string representing the name of the corresponding SpecialKey.
        """
        return self.name

__terminal_settings = None
__polling = None
__keymap = None
__displaybuffer = bytearray()

if platform.system() == "Windows":
    __keymap = { b"\x48": SpecialKey.Up, b"\x50": SpecialKey.Down, b"\x4b": SpecialKey.Left,
                 b"\x4d": SpecialKey.Right, b"\x47": SpecialKey.Home, b"\x4f": SpecialKey.End }
elif platform.system() == "Linux" or platform.system() == "Darwin":
    __keymap = { b"\x1bOA": SpecialKey.Up, b"\x1bOB": SpecialKey.Down, b"\x1bOC": SpecialKey.Right,
                 b"\x1bOD": SpecialKey.Left, b"\x1bOH": SpecialKey.Home, b"\x1bOF": SpecialKey.End, }

def emit(data):
    """
    Emit data to the display. Data is buffered an only emitted after a flush.

    @type data: str
    @param data: A string to emit to the display.
    """
    global __displaybuffer
    __displaybuffer.extend(data.encode("ascii"))

def flush():
    """
    Flush data to the display.
    """
    global __displaybuffer
    os.write(sys.stdout.fileno(), __displaybuffer)
    __displaybuffer.clear()

def poll_event():
    """
    Poll for event data.

    @rtype: str|SpecialKey|None
    @returns: If an alphanumeric key was struck, this returns the key's string representation. If a SpecialKey was
              struck, and that SpecialKey was understood by the application it returns the corresponding SpecialKey
              value. If the SpecialKey wasn't understood, it may return SpecialKey.Escape. In all other it returns
              None.
    """
    global __keymap
    if platform.system() == "Windows":
        if msvcrt.kbhit():
            data = msvcrt.getch()
            if data in b"\x00\xe0":
                key = msvcrt.getch()
                if key in __keymap:
                    return __keymap[key]
            return data.decode("ascii")
    else:
        global __polling
        available = __polling.poll(1)
        data = sys.stdin.buffer.read(1)
        if len(data) == 0:
            return None
        if data != b"\x1b":
            return data.decode("ascii")
        else:
            sequence = bytearray(5)
            sequence[0] = 0x1b
            index = 1
            buffer = bytearray(1)
            count = sys.stdin.buffer.readinto(buffer)
            while count and index < len(sequence):
                sequence[index] = buffer[0]
                index += 1
                key = bytes(sequence[:index])
                if key in __keymap:
                    return __keymap[key]
                count = sys.stdin.buffer.readinto(buffer)
            return SpecialKey.Escape
    return None

def init():
    """
    Initialize the game display.
    """
    if not sys.stdin.isatty():
        raise RuntimeError("py requires an interactive terminal.")
    emit("\x1b[?1049h\x1b=\x1b[?1h\x1b[?25l\x1b[2J\x1b[3J\x1b[1;1H")
    flush()
    if platform.system() == "Linux" or platform.system() == "Darwin":
        global __terminal_settings
        global __polling
        __terminal_settings = termios.tcgetattr(sys.stdin.fileno())
        settings = __terminal_settings.copy()
        settings[3] &= ~(termios.ICANON | termios.ECHO)
        settings[3] |= termios.ISIG
        settings[6][termios.VMIN] = 0
        settings[6][termios.VTIME] = 0
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, settings)
        __polling = select.poll()
        __polling.register(sys.stdin.fileno(), select.POLLIN)

def quit():
    """
    Clean up the game display.
    """
    global victory
    global gameover
    victory = None
    gameover = None
    if platform.system() == "Linux" or platform.system() == "Darwin":
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, __terminal_settings)
    emit("\x1b[?1l\x1b>\x1b[?1049l\x1b[?25h")
    flush()

def screen_size():
    """
    Retrieve the size of the screen in pixels.

    @rtype: tuple
    @returns: A 2-tuple (pair) of integer values. The first value is the display width and the second is the display
              height.
    """
    size = os.get_terminal_size()
    return (size[0], size[1])

def clear():
    """
    Reset the display cursor to (0, 0).
    """
    emit("\x1b[1;1H")

__lastbuffer = None

def blank():
    """
    Reset the display and fill it with blank data.
    """
    emit("\x1b[2J\x1b[3J\x1b[0;0H")

def display(image):
    """
    Display an image on the screen.

    @type image: Image
    @param image: The image to be displayed.
    """
    global __lastbuffer
    if __lastbuffer is None:
        emit(image.compile())
    else:
        emit(image.deltacompile(__lastbuffer))
    emit(f"\x1b[{image.height() + 1};0H")
    flush()
    __lastbuffer = image.copy()

def wait(seconds):
    """
    Pause execution for the desired number of seconds.

    @type seconds: float
    @param seconds: A number of seconds to wait for.
    """
    time.sleep(seconds)
