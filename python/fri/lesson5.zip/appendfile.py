file = open("output.txt", "a")
file.write("Hello, world!")
file.close()
