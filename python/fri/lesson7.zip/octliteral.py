if 0o10 == 8:
    print(oct(0o10) + " is the same as " + str(8))
