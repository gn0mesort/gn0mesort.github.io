if 0xA == 10:
    print(hex(0xA) + " is the same as " + str(10))
