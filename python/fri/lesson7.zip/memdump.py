from pathlib import Path

def to_hex_string(number):
    # FIXME: We need to convert our number into a hexadecimal string. We can't
    # just use hex(), that would be cheating.
    pass

def to_oct_string(number):
    # FIXME: The same for an octal string
    pass

def to_bin_string(number):
    # FIXME: The same for a binary string
    pass

def zero_fill(text, fillcount):
    if len(text) < fillcount:
        return ("0" * (fillcount - len(text))) + text
    return text

def to_radix_string(radix, number):
    # FIXME: We need to write a function that correctly converts to the given
    # radix (base) and zero fills the resulting string. That means we also need
    # to know how many digits per byte in the radix.
    pass

def to_text(data):
    result = bytearray(data)
    for i in range(len(data)):
        if data[i] < 0x20 or data[i] > 0x7e:
            result[i] = 0x2e
    return result.decode("ascii")

radix = int(input("Input a base to dump the file in (2, 8, 10, 16): "))
if radix not in { 2, 8, 10, 16 }:
    print("Invalid base.")
    exit(1)
path = Path(input("Input a file to dump: "))
if path.is_file():
    file = open(path, "rb")
    data = file.read()
    file.close()
    char_size = len(to_radix_string(radix, len(data)))
    print(path)
    bytes_per_line = 16
    if radix < 8:
        bytes_per_line = 6
    pos = 0
    # FIXME: We need to actually perform our output. To do this we need to loop through our data and print
    # the offset (in the correct base), the correct amount of data (bytes_per_line) in the correct base
    # and the text version of that data (using to_text()).
    pass
    print("")
else:
    print("Invalid path.")
    exit(1)
