import sys

value = 0xaabb
print("Writing " + str(value) + " to the disk as big, little, and system endian")
big = value.to_bytes(2, byteorder="big")
little = value.to_bytes(2, byteorder="little")
system = value.to_bytes(2, byteorder=sys.byteorder)
spacer = b"\x00" * 14
file = open("value.bin", "wb")
file.write(big)
file.write(spacer)
file.write(little)
file.write(spacer)
file.write(system)
file.write(spacer)
file.close()
