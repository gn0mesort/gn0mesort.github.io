MONKEY = """
               ',
            .-`-,\\__
              ."`   `,
            .'_.  ._  `;.
        __ / `      `  `.\\ .--.
       /--,| 0)   0)     )`_.-,)
      |    ;.-----.__ _-');   /
       '--./         `.`/  `"`
          :   '`      |.
          | \\     /  //
           \\ '---'  /'
            `------' \\
             _/       `--...
"""
ALPHABET =   "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
SECRETCODE = "ZYXWVUTSRQPONMLKJIHGFEDCBA"

def find(alphabet, character):
    """
    Finds a character in an alphabet.

    @type alphabet: str
    @param alphabet: The alphabet to search. This must not be None.
    @type character: str
    @param character: The character to search for. This must be a str with a length of 1.
    @rtype: int
    @returns: The index of character in alphabeth or -1 if character isn't found.
    """
    index = 0
    while index < len(alphabet):
        if alphabet[index] == character:
            return index
        index = index + 1
    return -1

def encrypt(message):
    """
    Encrypt a message using a cipher.

    @type message: str
    @param message: The message to encrypt.
    @rtype: str
    @returns: A string containing the encrypted message.
    """
    cipher = ""
    for character in message:
        index = find(ALPHABET, character)
        if index >= 0:
            cipher = cipher + SECRETCODE[index]
        else:
            cipher = cipher + character
    return cipher

def decrypt(message):
    """
    Decrypt a message using a cipher.

    @type message: str
    @param message: The message to decrypt.
    @rtype: str
    @returns: A string containing the decrypted message.
    """
    plain = ""
    for character in message:
        index = find(SECRETCODE, character)
        if index >= 0:
            plain = plain + ALPHABET[index]
        else:
            plain = plain + character

def monkeysay(message):
    """
    Display a graphic of a monkey saying your message.

    @type message: str
    @param message: The message the monkey will say.
    """
    # Here we need to write a complete program to display our monkey with a speech bubble. We already have the monkey
    # so we need to figure out the speech bubble!
    pass
    print(MONKEY)

# Here, we need to write the main process of our program. This is where we will ask for input, transform our input,
# and write our output.
pass
