ALPHABET =   "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
SECRETCODE = "ZYXWVUTSRQPONMLKJIHGFEDCBA"

def find(alphabet, character):
    index = 0
    while index < len(alphabet):
        if alphabet[index] == character:
            return index
        index = index + 1
    return -1

def encrypt(message):
    cipher = ""
    for character in message:
        index = find(ALPHABET, character)
        if index >= 0:
            cipher = cipher + SECRETCODE[index]
        else:
            cipher = cipher + character
    return cipher

def decrypt(message):
    plain = ""
    for character in message:
        index = find(SECRETCODE, character)
        if index >= 0:
            plain = plain + ALPHABET[index]
        else:
            plain = plain + character
    return plain

message = input("Input a message: ")
secret = encrypt(message.upper())
print(secret)
