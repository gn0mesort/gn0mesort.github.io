import time
import math

import image
import terminal

class Stopwatch:
    def __init__(self):
        self.__start = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    def reset(self):
        now = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        res = (now - self.__start) * 1e-6
        self.__start = now
        return res

FRAME_RATE = 1 / 16

def lerp(a, b, t):
    return a + t * (b - a)

def lerp_color(a, b, t):
    ar, ag, ab = a
    br, bg, bb = b
    return (lerp(ar, br, t), lerp(ag, bg, t), lerp(ab, bb, t))

try:
    clock = Stopwatch()
    frame = 0
    dt = 0
    acc = 0
    colors = ((255, 0, 0), (0, 255, 0), (0, 0, 255))
    color = 0
    normalized = colors[color]
    terminal.init()
    backbuffer = image.Image((32, 4))
    direction = 1
    sprite = image.Image((4, 4))
    sprite.fill(image.Pixel(colors[0]))
    while True:
        while math.isclose(acc, FRAME_RATE, rel_tol=0, abs_tol=0.0001) or acc > FRAME_RATE:
            next = frame + direction
            if next * sprite.width() >= backbuffer.width() or next < 0:
                direction = direction * -1
                next = frame + direction
            frame = next
            acc = acc - FRAME_RATE
        next = (color + 1) % len(colors)
        normalized = lerp_color(normalized, colors[next], dt)
        if (math.isclose(normalized[0], colors[next][0], rel_tol=0, abs_tol=1 / 511) and
            math.isclose(normalized[1], colors[next][1], rel_tol=0, abs_tol=1 / 511) and
            math.isclose(normalized[2], colors[next][2], rel_tol=0, abs_tol=1 / 511)):
            color = next
            normalized = colors[color]
        pixel = image.Pixel((int(normalized[0]), int(normalized[1]), int(normalized[2])))
        sprite.fill(pixel)
        terminal.clear()
        backbuffer.fill(image.Pixel((0, 0, 0)))
        backbuffer.blit(sprite, (frame * 4, 0))
        print(backbuffer)
        terminal.flush()
        dt = clock.reset() / 1000
        acc = acc + dt
except KeyboardInterrupt:
    pass
finally:
    terminal.quit()
