a = [ "Hello", "World" ]
b = a
if a is b:
    print("ID of a = " + str(id(a)))
    print("ID of b = " + str(id(b)))
    for line in a:
        print(line)
c = b
if a is c:
    print("ID of a = " + str(id(a)))
    print("ID of c = " + str(id(c)))
    for i, _ in enumerate(a):
        print(i)
c = [ "Hello", "World" ]
if c is not a:
    print("ID of a = " + str(id(a)))
    print("ID of c = " + str(id(c)))
