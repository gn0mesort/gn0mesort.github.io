a = [ 1, 2, 3, 4 ]
print(id(a))
b = a
print(id(b))
c = a.copy()
print(id(c))
