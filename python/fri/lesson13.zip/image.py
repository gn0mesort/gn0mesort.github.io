def clamp(v, lo, hi):
    return min(max(v, lo), hi)

class Pixel:
    def __init__(self, rgb):
        if isinstance(rgb, int):
            self.__color = rgb & 0xff_ff_ff
        elif isinstance(rgb, tuple):
            self.__color = (rgb[0] << 16 | rgb[1] << 8 | rgb[2]) & 0xff_ff_ff
        else:
            raise RuntimeError("Pixels must be initialized with integers or tuples")
    def color(self):
        return self.__color
    def red(self):
        return (self.__color & 0xff_00_00) >> 16
    def green(self):
        return (self.__color & 0xff_00) >> 8
    def blue(self):
        return self.__color & 0xff
    def __add__(self, other):
        red = clamp(self.red() + other.red(), 0, 255)
        green = clamp(self.green() + other.green(), 0, 255)
        blue = clamp(self.blue() + other.blue(), 0, 255)
        return Pixel((red, green, blue))
    def __sub__(self, other):
        red = clamp(self.red() - other.red(), 0, 255)
        green = clamp(self.green() - other.green(), 0, 255)
        blue = clamp(self.blue() - other.blue(), 0, 255)
        return Pixel((red, green, blue))
    def __mul__(self, other):
        red = int(255 * (self.red() / 255) * (other.red() / 255))
        green = int(255 * (self.green() / 255) * (other.green() / 255))
        blue = int(255 * (self.blue() / 255) * (other.blue() / 255))
        return Pixel((red, green, blue))
    def __truediv__(self, other):
        red = int(255 * (self.red() / 255) / (other.red() / 255))
        print(red)
        green = int(255 * (self.green() / 255) / (other.green() / 255))
        blue = int(255 * (self.blue() / 255) / (other.blue() / 255))
        return Pixel((red, green, blue))
    def tuple(self):
        return ((self.__color & 0xff_00_00) >> 16, (self.__color & 0xff_00) >> 8, self.__color & 0xff)
    def __eq__(self, other):
        return self.__color == other.__color
    def __ne__(self, other):
        return not (self == other)
    def __repr__(self):
        return "Pixel(" + hex(self.__color) + ")"
    def __str__(self):
        return str(self.red()) + ";" + str(self.green()) + ";" + str(self.blue())

class Image:
    def __init__(self, size):
        self.__size = size
        self.__pixels = [ 0 ] * (self.__size[0] * self.__size[1])
        for i in range(len(self.__pixels)):
            self.__pixels[i] = Pixel((0, 0, 0))
    def width(self):
        return self.__size[0]
    def height(self):
        return self.__size[1]
    def __getitem__(self, coords):
        x, y = coords
        return self.__pixels[y * self.__size[0] + x]
    def __setitem__(self, coords, item):
        x, y = coords
        self.__pixels[y * self.__size[0] + x] = item
    def pixels(self):
        return tuple(self.__pixels)
    def set_transparent(self, color, fill = (0, 0, 0)):
        for i in range(len(self.__pixels)):
            if self.__pixels[i] == color:
                self.__pixels[i] = Pixel(fill)
    def fill(self, color):
        for i in range(len(self.__pixels)):
            self.__pixels[i] = color
    def blit(self, source, origin, srcrect = None):
        x, y = origin
        sx = 0
        sy = 0
        sw = source.width()
        sh = source.height()
        if srcrect is not None:
            sx, sy, sw, sh = srcrect
        for i in range(y, min(y + (self.height() - y), y + sh)):
            for j in range(x, min(x + (self.width() - x), x  + sw)):
                self[(j, i)] = source[(sx + (j - x), sy + (i - y))]
    def __str__(self):
        current = None
        buffer = [ "\x1b[0m" ]
        for i, pixel in enumerate(self.__pixels):
            if current is None or current != pixel:
                current = pixel
                buffer.append("\x1b[48;2;" + str(current) + "m")
            buffer.append("  ")
            if (i + 1) % self.width() == 0 and i + 1 < len(self.__pixels):
                buffer.append("\x1b[0m\n")
                current = None
        buffer.append("\x1b[0m")
        return "".join(buffer)
    def __repr__(self):
        return repr(str(self))

def load_image(path):
    MODE_PLAIN = "P3"
    MODE_BINARY = "P6"
    STATE_WIDTH = 0
    STATE_HEIGHT = 1
    STATE_MAXVAL = 2
    STATE_DATA = 3
    image = None
    file = open(path, "rb")
    try:
        mode = file.readline().decode("ascii").strip()
        if mode not in (MODE_PLAIN, MODE_BINARY):
            raise RuntimeError("Invalid PPM file.")
        state = STATE_WIDTH
        width = 0
        height = 0
        maxval = 0
        for line in file:
            decoded = line.decode("ascii")
            if decoded.startswith("#"):
                continue
            words = decoded.strip().split()
            for word in words:
                if state == STATE_WIDTH:
                    width = int(word)
                    if width < 1:
                      raise RuntimeError("0 pixel image.")
                    state = STATE_HEIGHT
                elif state == STATE_HEIGHT:
                    height = int(word)
                    if height < 1:
                      raise RuntimeError("0 pixel image.")
                    state = STATE_MAXVAL
                elif state == STATE_MAXVAL:
                    maxval = int(word)
                    if maxval > 65536 or maxval < 0:
                        raise RuntimeError("Invalid maximum color valid.")
                    state = STATE_DATA
            if state == STATE_DATA:
                break
        if state != STATE_DATA:
            raise RuntimeError("Invalid PPM Header.")
        image = Image((width, height))
        x = 0
        y = 0
        if mode == MODE_BINARY:
            bytes_per_color = int(maxval > 255) + 1
            next = file.read(3 * bytes_per_color)
            while len(next) > 0:
                red = int.from_bytes(next[0:bytes_per_color], byteorder="big")
                green = int.from_bytes(next[bytes_per_color:bytes_per_color * 2], byteorder="big")
                blue = int.from_bytes(next[bytes_per_color * 2:], byteorder="big")
                image[(x, y)] = Pixel((red, green, blue))
                x = x + 1
                if x >= image.width():
                    x = 0
                    y = y + 1
                next = file.read(3 * bytes_per_color)
        else:
            colors = file.read().decode("ascii").strip().split()
            if len(colors) % 3 != 0:
                raise RuntimeError("Invalid color data.")
            for i in range(0, len(colors), 3):
                red = int(colors[i])
                green = int(colors[i + 1])
                blue = int(colors[i + 2])
                image[(x, y)] = Pixel((red, green, blue))
                x = x + 1
                if x >= image.width():
                    x = 0
                    y = y + 1
    finally:
        file.close()
    return image
