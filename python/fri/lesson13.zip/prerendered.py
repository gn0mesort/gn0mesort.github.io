import time
import math

import image
import terminal

class Stopwatch:
    def __init__(self):
        self.__start = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    def reset(self):
        now = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        res = (now - self.__start) * 1e-6
        self.__start = now
        return res

FRAME_RATE = 1 / 12
FRAME_COUNT = 6

try:
    clock = Stopwatch()
    frame = 0
    dt = 0
    acc = 0
    terminal.init()
    backbuffer = image.Image((66, 66))
    sprite = image.load_image("sonic.ppm")
    sprite.set_transparent(image.Pixel((255, 0, 255)), (255, 255, 255))
    while True:
        while math.isclose(acc, FRAME_RATE, rel_tol=0, abs_tol=0.0001) or acc > FRAME_RATE:
            frame = (frame + 1) % FRAME_COUNT
            acc = acc - FRAME_RATE
        terminal.clear()
        backbuffer.fill(image.Pixel((255, 255, 255)))
        backbuffer.blit(sprite, (0, 0), srcrect=(frame * 66, 0, 66, 66))
        print(backbuffer)
        terminal.flush()
        dt = clock.reset() / 1000
        acc = acc + dt
except KeyboardInterrupt:
    pass
finally:
    terminal.quit()
