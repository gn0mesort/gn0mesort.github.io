import random
import time
import math

import image
import terminal

SYMBOL_WIDTH = 22
SYMBOL_HEIGHT = 18
FIXED_UPDATE = 1 / 10

class Stopwatch:
    def __init__(self):
        self.__start = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    def reset(self):
        now = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        res = (now - self.__start) * 1e-6
        self.__start = now
        return res

class Symbol:
    def __init__(self, name, image):
        self.__name = name
        self.__image = image
    def __repr__(self):
        return "Symbol(" + str(self.__name) + ")"
    def name(self):
        return self.__name
    def image(self):
        return self.__image

class Reel:
    def __init__(self, symbols):
        self.__stopped = True
        self.__index = 0
        self.__symbols = list(symbols)
        random.shuffle(self.__symbols)
    def start(self):
        self.__stopped = False
        self.__index = 0
    def stop(self):
        self.__stopped = True
    def next(self):
        if not self.__stopped:
            self.__index = (self.__index + 1) % len(self.__symbols)
    def symbol(self):
        return self.__symbols[self.__index]

def create_symbols():
    # FIXME: Here we need to create the symbols that will go on our slot machine. Each symbol is a Symbol object with
    # a name and an Image. First we need a list to store our symbols, and then we need to append each newly
    # constructed symbol into that list. Finally, we need to ensure each symbol's background matches the background
    # color of the game.
    pass

def create_reels(count, symbols):
    # FIXME: We need to create slot machine reels here. Each reel contains every symbol in a randomized order.
    # Reels reference symbols and don't copy them so they all reference the same underlying data. Once each reel is
    # created we need to start it spinning.
    pass

def check_win(reels):
    # FIXME: We need to check if each reel has the same symbol. Recall that the symbols are referenced by the reel
    # and not copied. That means we can check if each symbol has the same ID to determine equality.
    pass

try:
    terminal.init()
    win = image.load_image("win.ppm")
    win.set_transparent(image.Pixel((255, 0, 255)), fill=(51, 51, 51))
    lose = image.load_image("lose.ppm")
    lose.set_transparent(image.Pixel((255, 0, 255)), fill=(51, 51, 51))
    symbols = create_symbols()
    reels = create_reels(3, symbols)
    backbuffer = image.Image((SYMBOL_WIDTH * 3, SYMBOL_HEIGHT))
    clock = Stopwatch()
    dt = 0
    acc = 0
    event = None
    reel_index = 0
    quitting = False
    while not quitting:
        event = terminal.poll_event()
        while event is not None:
            if event == "q" or event == "Q":
                quitting = True
            if event == "S":
                if FIXED_UPDATE == (1 / 10):
                    FIXED_UPDATE = 1
                else:
                    FIXED_UPDATE = (1 / 10)
            if event == " ":
                if reel_index >= len(reels):
                    terminal.blank()
                    for reel in reels:
                        reel.start()
                    reel_index = 0
                else:
                    reels[reel_index].stop()
                    reel_index = reel_index + 1
            event = terminal.poll_event()
        while math.isclose(acc, FIXED_UPDATE, rel_tol=0, abs_tol=0.0001) or acc > FIXED_UPDATE:
            for reel in reels:
                reel.next()
            acc = acc - FIXED_UPDATE
        backbuffer.fill(image.Pixel((51, 51, 51)))
        for i, reel in enumerate(reels):
            backbuffer.blit(reel.symbol().image(), (SYMBOL_WIDTH * i, 0))
        terminal.clear()
        print(backbuffer)
        if reel_index >= len(reels):
            if check_win(reels):
                print(win)
            else:
                print(lose)
        terminal.flush()
        dt = clock.reset() / 1000
        acc = acc + dt
except KeyboardInterrupt:
    pass
finally:
    terminal.quit()
