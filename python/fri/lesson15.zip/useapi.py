import math

WIDTH = 64
HEIGHT = 16

step = 2 * math.pi / WIDTH
current = 0
grid = [ " " ] * (WIDTH * HEIGHT)
for i in range(WIDTH):
    factor = math.cos(current)
    amplitude = math.floor((HEIGHT - 1) // 2 * factor)
    grid[(amplitude + (HEIGHT - 1) // 2) * WIDTH + i] = "*"
    current = current + step
for i in range(HEIGHT):
    for j in range(WIDTH):
        print(grid[i * WIDTH + j], end="")
    print("")
