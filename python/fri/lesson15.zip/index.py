import random

from pathlib import Path
from datetime import datetime, timedelta

class Page:
    def __init__(self, method, path, getparams=None, postparams=None):
        self._method = method
        self._path = path
        self._getparams = getparams
        self._postparams = postparams
    def _read_file(self, path):
        # FIXME: We need to read an entire file here. We don't care what is in the file, we just want to
        # read all the bytes and return them as is.
        pass
    def _write_file(self, path, content):
        try:
            file = open(path, "wb")
            file.write(content)
        finally:
            file.close()
    def language(self):
        return "en"
    def title(self):
        return "My Home Page"
    def style(self):
        return self._read_file("css/homepage.css.in").decode("utf-8").strip()
    def body(self):
        # FIXME: We have to write a method that generates our HTML body. This should load the HTML from a file and
        # then format the resulting string with the correct data to display our page as intended.
        pass
    def _save_daily(self, path, lucky, image):
        data = bytearray()
        now = int(datetime.now().timestamp())
        data.extend(now.to_bytes(8, byteorder="little"))
        data.extend(lucky.to_bytes(1, byteorder="little"))
        image_bytes = str(image).encode("utf-8")
        data.extend(len(image_bytes).to_bytes(8, byteorder="little"))
        data.extend(image_bytes)
        self._write_file(path, data)
    def _load_daily(self, path):
        # FIXME: Here we want to write a method that reads a the daily binary data file and returns its data if less
        # than a day has passed. Otherwise, we just return (None, None).
        pass
