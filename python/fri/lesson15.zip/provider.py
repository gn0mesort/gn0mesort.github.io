def fibonacci(index, cache = { }):
    """
    Generate Fibonacci numbers using a memoization cache.

    @type index: int
    @param index: The index of the desired Fibonacci number. If this is less than 1, the result will be 0.
    @type cache: dict[int, int]
    @param cache: A dictionary used for caching results. This is used for speeding up computations. The default
                  cache is used if not provided. This cannot be None.
    @rtype: int
    @returns: The integer Fibonnaci number with the input index.
    """
    if index < 1:
        return 0
    if index < 3:
        return 1
    if index in cache:
        return cache[index]
    cache[index] = fibonacci(index - 1, cache=cache) + fibonacci(index - 2, cache=cache)
    return cache[index]
