import provider

def main():
    for i in range(20):
        print(provider.fibonacci(i))
        #print(provider.fibonacci(i, cache=None))

if __name__ == "__main__":
    main()
