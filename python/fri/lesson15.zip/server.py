import mimetypes

from pathlib import Path
from urllib.parse import parse_qsl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class Handler(BaseHTTPRequestHandler):
    def _resolve_path(self):
        parts = self.path.split("?")
        hier = ""
        query = ""
        if len(parts) == 2:
            hier, query = parts
        else:
            hier = parts[0]
        path = Path(hier)
        path = (Path.cwd() / path.relative_to(path.anchor)).absolute()
        params = { }
        for pair in parse_qsl(query):
            key, value = pair
            params[key] = value
        return (path, params)
    def _find_file(self, path):
        if path.exists() and path.is_dir():
            for candidate in ("index.py", "index.html"):
                complete = path / candidate
                if complete.exists() and complete.is_file():
                    mime, encoding = mimetypes.guess_file_type(complete)
                    return (complete, mime, encoding)
        elif path.exists() and path.is_file():
            mime, encoding = mimetypes.guess_file_type(path)
            return (path, mime, encoding)
        return (None, None, None)
    def _generate_page(self, page):
        html = """<!DOCTYPE html><html {language}><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1" />{title}{style}</head><body>{body}</body></html>""".strip()
        language = ""
        title = ""
        style = ""
        if hasattr(page, "language"):
            language = "lang=\"{}\"".format(page.language())
        if hasattr(page, "title"):
            title = "<title>{}</title>".format(page.title())
        if hasattr(page, "style"):
            style = "<style>{}</style>".format(page.style())
        return html.format(language=language, title=title, style=style, body=page.body())
    def do_HEAD(self):
        path, params = self._resolve_path()
        self.log_message("Path = " + str(path) + ", Params = " + str(params))
        path, mime, encoding = self._find_file(path)
        self.log_message("Path = " + str(path) + ", Mimetype = " + str(mime) + ", Encoding = " + str(encoding))
        if path is None:
            self.send_error(404)
        else:
            self.send_response(200)
            if mime is not None:
                if mime == "text/x-python":
                    self.send_header("Content-Type", "text/html")
                else:
                    self.send_header("Content-Type", mime)
            else:
                self.send_header("Content-Type", "application/octet-stream")
            if encoding is not None:
                self.send_header("Content-Encoding", encoding)
            self.end_headers()
            self.flush_headers()
    def do_GET(self):
        path, params = self._resolve_path()
        path, mime, encoding = self._find_file(path)
        if path is None:
            self.send_error(404)
        else:
            self.send_response(200)
            if mime is not None:
                if mime == "text/x-python":
                    self.send_header("Content-Type", "text/html")
                else:
                    self.send_header("Content-Type", mime)
            else:
                self.send_header("Content-Type", "application/octet-stream")
            if encoding is not None:
                self.send_header("Content-Encoding", encoding)
            self.end_headers()
            self.flush_headers()
            if mime == "text/x-python":
                state = { }
                file = open(path, "r")
                program = file.read()
                file.close()
                exec(program, globals=state)
                if "Page" in state:
                    page = state["Page"]("GET", path, getparams=params)
                    self.wfile.write(self._generate_page(page).encode("utf-8"))
            else:
                file = open(path, "rb")
                self.wfile.write(file.read())
                file.close()
    def do_POST(self):
        path, _ = self._resolve_path()
        params = { }
        length = int(self.headers.get("Content-Length"))
        for pair in parse_qsl(self.rfile.read(length)):
            key, value = pair
            params[key.decode("utf-8").strip()] = value.decode("utf-8").strip()
        path, mime, encoding = self._find_file(path)
        if path is None:
            self.send_error(404)
        else:
            self.send_response(200)
            if mime is not None:
                if mime == "text/x-python":
                    self.send_header("Content-Type", "text/html")
                else:
                    self.send_header("Content-Type", mime)
            else:
                self.send_header("Content-Type", "application/octet-stream")
            if encoding is not None:
                self.send_header("Content-Encoding", encoding)
            self.end_headers()
            self.flush_headers()
            if mime == "text/x-python":
                state = { }
                file = open(path, "r")
                program = file.read()
                file.close()
                exec(program, globals=state)
                if "Page" in state:
                    page = state["Page"]("POST", path, postparams=params)
                    self.wfile.write(self._generate_page(page).encode("utf-8"))
            else:
                file = open(path, "rb")
                self.wfile.write(file.read())
                file.close()

def main():
    try:
        mimetypes.init()
        server = ThreadingHTTPServer(("", 8000), Handler)
        server.serve_forever()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
