import sys

NO = 0
YES = 1

def confirm(prompt):
    choice = input(prompt).strip().lower()
    if choice == "y":
        return YES
    elif choice == "n":
        return NO
    else:
        raise RuntimeError("The input \"" + choice + "\" isn't valid.")

quitting = False
while not quitting:
    try:
        choice = confirm("Quit? (Y/N) ")
        if choice == YES:
            quitting = True
    except Exception as error:
        print(error, file=sys.stderr)
