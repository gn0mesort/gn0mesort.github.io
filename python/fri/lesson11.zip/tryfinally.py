def write_hello(path):
    file = open(path, "w")
    try:
        file.write("Hello!")
    finally:
        file.close()
