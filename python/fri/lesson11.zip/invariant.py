class Cat:
    def __init__(self, name):
        self.__name = name
        if not isinstance(self.__name, str):
            raise ValueError("Cat names must be strings.")
        if len(self.__name) < 1:
            raise ValueError("Cat names cannot be empty.")
    def name(self):
        return self.__name
    def speak(self):
        return "Meow!"
