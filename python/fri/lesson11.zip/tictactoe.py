import sys

DEFAULT = 0
RED = 31
GREEN = 32
YELLOW = 33
BLUE = 34
MAGENTA = 35
CYAN = 36

TURN_PLAYER = 0
TURN_CPU = 1

class Mark:
    def __init__(self, character, color):
        # FIXME: We need to implement the Mark constructor. A Mark is a character and a color that will be used to
        # mark the game board during play. We need to enforce invariants on here by raising errors.
        # We have to make sure a character is exactly 1 character long.
        # We also have to make sure that the color is one of the colors listed above.
        pass
    def character(self):
        return self.__character
    def __str__(self):
        return "\x1b[" + str(self.__color) + "m" + self.__character + "\x1b[0m"

class Board:
    def __init__(self):
        self.__board = [ ]
        for i in range(9):
            self.__board.append(Mark(str(i + 1), DEFAULT))
    def copy(self):
        res = Board()
        res.__board = self.__board.copy()
        return res
    def get(self, xy):
        return self.__board[xy[1] * 3 + xy[0]]
    def set(self, xy, value):
        if not isinstance(value, Mark):
            raise RuntimeError("Boards can only accept Marks.")
        self.__board[xy[1] * 3 + xy[0]] = value
    def print(self):
        for i in range(3):
            for j in range(3):
                print(" " + str(self.__board[i * 3 + j]) + " ", end="")
                if j < 2:
                    print("|", end="")
            print("")
            if i < 2:
                print("-" * 11)
    def is_row_all(self, row, mark):
        for i in range(3):
            if self.__board[row * 3 + i].character() != mark.character():
                return False
        return True
    def is_column_all(self, column, mark):
        for i in range(3):
            if self.__board[i * 3 + column].character() != mark.character():
                return False
        return True
    def is_left_diagonal_all(self, mark):
        return (self.__board[0].character() == mark.character() and
                self.__board[4].character() == mark.character() and
                self.__board[8].character() == mark.character())
    def is_right_diagonal_all(self, mark):
        return (self.__board[2].character() == mark.character() and
                self.__board[4].character() == mark.character() and
                self.__board[6].character() == mark.character())
    def count(self, mark):
        res = 0
        for i in range(len(self.__board)):
            if self.__board[i].character() == mark.character():
                res = res + 1
        return res
    def empty_locations(self):
        res = [ ]
        for i in range(len(self.__board)):
            if self.__board[i].character() not in "XO":
                y = i // 3
                x = i - (y * 3)
                res.append((x, y))
        return tuple(res)
    def find_winner(self):
        for i in range(3):
            if self.is_row_all(i, Mark("X", DEFAULT)) or self.is_column_all(i, Mark("X", DEFAULT)):
                return TURN_PLAYER
            elif self.is_row_all(i, Mark("O", DEFAULT)) or self.is_column_all(i, Mark("O", DEFAULT)):
                return TURN_CPU
        if self.is_left_diagonal_all(Mark("X", DEFAULT)) or self.is_right_diagonal_all(Mark("X", DEFAULT)):
            return TURN_PLAYER
        elif self.is_left_diagonal_all(Mark("O", DEFAULT)) or self.is_right_diagonal_all(Mark("O", DEFAULT)):
            return TURN_CPU
        return None

class Player:
    def __init__(self, mark):
        self.__mark = mark
        if not isinstance(self.__mark, Mark):
            raise RuntimeError("The player's mark must be of the type Mark.")
    def mark(self):
        return self.__mark

class CPUPlayer:
    def __init__(self, mark):
        self.__mark = mark
        if not isinstance(self.__mark, Mark):
            raise RuntimeError("The player's mark must be of the type Mark.")
    def mark(self):
        return self.__mark
    def __find_win(self, board):
        if board.count(Mark("O", DEFAULT)):
            for location in board.empty_locations():
                next = board.copy()
                next.set(location, Mark("O", DEFAULT))
                if next.find_winner() == TURN_CPU:
                    return location
        return None
    def __find_block(self, board):
        if board.count(Mark("X", DEFAULT)):
            for location in board.empty_locations():
                next = board.copy()
                next.set(location, Mark("X", DEFAULT))
                if next.find_winner() == TURN_PLAYER:
                    return location
    def __find_all_blocks(self, board):
        res = [ ]
        if board.count(Mark("X", DEFAULT)) > 2:
            for location in board.empty_locations():
                next = board.copy()
                next.set(location, Mark("X", DEFAULT))
                if next.find_winner() == TURN_PLAYER:
                    res.append(location)
        return tuple(res)
    def __find_fork_block(self, board):
        available = [ ]
        for location in board.empty_locations():
            next = board.copy()
            next.set(location, Mark("O", DEFAULT))
            fork = False
            for next_location in next.empty_locations():
                next_next = next.copy()
                next_next.set(next_location, Mark("X", DEFAULT))
                blocks = self.__find_all_blocks(next_next)
                if len(blocks) > 1 and self.__find_win(next_next) is None:
                    fork = True
            if not fork:
                available.append(location)
        if len(available) == 0:
            return None
        return available[0]
    def __find_opposite_corner(self, board, last):
        empty = board.empty_locations()
        if last == (0, 0) and (2, 2) in empty:
            return (2, 2)
        if last == (0, 2) and (2, 0) in empty:
            return (2, 0)
        if last == (2, 2) and (0, 0) in empty:
            return (0, 0)
        if last == (2, 0) and (0, 2) in empty:
            return (0, 2)
        return None
    def __find_corner(self, board):
        empty = board.empty_locations()
        if (0, 0) in empty:
            return (0, 0)
        if (0, 2) in empty:
            return (0, 2)
        if (2, 2) in empty:
            return (2, 2)
        if (2, 0) in empty:
            return (2, 0)
        return None
    def __find_edge(self, board):
        empty = board.empty_locations()
        if (1, 0) in empty:
            return (1, 0)
        if (0, 1) in empty:
            return (0, 1)
        if (1, 2) in empty:
            return (1, 2)
        if (2, 1) in empty:
            return (2, 1)
        return None
    def choose_move(self, board, last):
        move = self.__find_win(board)
        if move is not None:
            return move
        move = self.__find_block(board)
        if move is not None:
            return move
        filled = board.count(Mark("X", DEFAULT)) + board.count(Mark("O", DEFAULT))
        if filled == 3 or filled == 6:
            move = self.__find_fork_block(board)
            if move is not None:
                return move
        if board.get((1, 1)).character() not in "XO":
            return (1, 1)
        move = self.__find_opposite_corner(board, last)
        if move is not None:
            return move
        move = self.__find_corner(board)
        if move is not None:
            return move
        move = self.__find_edge(board)
        if move is not None:
            return move
        raise RuntimeError("A valid move couldn't be located.")

class Game:
    def __init__(self):
       self.__board = Board()
       self.__player = Player(Mark("X", RED))
       self.__cpu = CPUPlayer(Mark("O", BLUE))
       self.__turn = TURN_PLAYER
       self.__last_move = None
    def __player_turn(self):
        # FIXME: Here we need to implement the logic for the player taking a turn. We need to be careful about what
        # happens if the player inputs an invalid value and handle the error to prevent the program from crashing.
        pass
    def __cpu_turn(self):
        xy = self.__cpu.choose_move(self.__board, self.__last_move)
        self.__board.set(xy, self.__cpu.mark())
        self.__last_move = xy
    def take_turn(self):
        if not self.is_playing():
            return
        if self.__turn == TURN_PLAYER:
            self.__board.print()
            self.__player_turn()
            print("")
        else:
            self.__cpu_turn()
        self.__turn = (self.__turn + 1) % 2
    def is_playing(self):
        return self.winner() is None and len(self.__board.empty_locations()) > 0
    def winner(self):
        return self.__board.find_winner()
    def board(self):
        return self.__board.copy()

try:
    game = Game()
    while game.is_playing():
        game.take_turn()
    game.board().print()
    winner = game.winner()
    if winner == TURN_PLAYER:
        print("\"X\" wins!")
    elif winner == TURN_CPU:
        print("\"O\" wins!")
    else:
        print("Cat's game!")
except KeyboardInterrupt:
    pass
except Exception as err:
    print(err, file=sys.stderr)
