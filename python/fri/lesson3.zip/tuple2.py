data = (1, 2, 3, "dog", "cat", "fish", True, False, 1.33, 2.66, 3.99)
for value in data:
    print(value)
