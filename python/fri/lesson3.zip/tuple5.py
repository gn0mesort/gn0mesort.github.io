students = (("Fred", 10), ("Samantha", 9),
            ("Kyle", 9), ("Terry", 10))

if ("Elizabeth", 9) in students:
    print("Elizabeth is in the class!")
else:
    print("Elizabeth is not in the class!")

students = (("Elizabeth", 9), ("Samantha", 9),
            ("Kyle", 9), ("Terry", 10))

if ("Fred", 10) not in students:
    print("Fred is not in the class!")
else:
    print("Fred is in the class!")
