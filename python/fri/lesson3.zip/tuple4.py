students = (("Fred", 10), ("Samantha", 9),
            ("Kyle", 9), ("Terry", 10))

# Error!!
students[0] = ("Elizabeth", 9)

# Allowed
students = (("Elizabeth", 9), ("Samantha", 9),
            ("Kyle", 9), ("Terry", 10))
