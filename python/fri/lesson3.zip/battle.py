import random

PLAYER_TURN = 0
MONSTER_TURN = 1

def roll(sides):
    return random.randint(1, sides)

# Each monster has a name, stats, and an amount of gold the player wins for beating them.
# The stats are total HP, strength, and defense.
monsters = (("goblin", (100, 5, 1), 3),
            ("kobold", (110, 7, 3), 10),
            ("skeleton", (150, 10, 5), 25),
            ("black widow", (200, 15, 7), 50),
            ("knight", (500, 25, 15), 150))

player_hp = 0
player_max_hp = 0
player_str = 0
player_def = 0
player_is_defending = False
player_gp = 0
monster_name = ""
monster_hp = 0
monster_str = 0
monster_def = 0
monster_gp = 0

print("Generating character...")
confirmed = False
while not confirmed:
    player = (random.randint(100, 999), random.randint(1, 30), random.randint(1, 30))
    print("Player:")
    # FIXME: We need to display the values of the player tuple here
    pass
    print("Proceed with this character? (Y/N)")
    choice = input("> ").lower().strip()
    if choice == "y":
        confirmed = True
        # FIXME: We need to store the generated tuple values into the correct player variables here
        pass
player_name = input("Give your character a name: ").strip().capitalize()
quitting = False
while not quitting:
    monster = random.choice(monsters)
    # FIXME: We need to map the selected monster's data to the variables we use during battle.
    pass
    print("You encounter a " + monster_name)
    player_initiative = roll(20)
    monster_initiative = roll(20)
    turn_order = None
    # FIXME: We need to ensure that there is a turn order tuple and that it represents the correct order. If the
    # player rolled a higher initiative then they need to go first. Otherwise the monster goes first.
    pass
    turn = 0
    fled = False
    player_hp = player_max_hp
    while monster_hp > 0 and player_hp > 0:
        if turn_order[turn] == PLAYER_TURN:
            choice = 0
            player_is_defending = False
            while choice not in (1, 2, 3):
                print("It is " + player_name + "\'s turn.")
                print("HP: " + str(player_hp) + "/" + str(player_max_hp))
                print("What will you do?")
                print("(1) Attack")
                print("(2) Defend")
                print("(3) Flee")
                choice = int(input("> "))
            if choice == 1:
                print(player_name + " attacks!")
                to_hit = (player_str + roll(20)) - (monster_def + roll(20))
                if to_hit >= 10:
                      damage = roll(4) + int(player_str / (21 - roll(20)))
                      print(player_name + " hits the " + monster_name + " for " + str(damage) + " points.")
                      monster_hp = monster_hp - damage
                else:
                    print(player_name + " misses!")
            elif choice == 2:
                player_is_defending = True
                print(player_name + " takes a defensive stance.")
            elif choice == 3:
                can_flee = roll(100)
                if can_flee >= 66:
                    print(player_name + " fled the battle!")
                    fled = True
                    break
                else:
                    print(player_name + " tried to run away, but failed!")
            turn = (turn + 1) % len(turn_order)
        else:
            print("It is the " + monster_name + "\'s turn.")
            print("The " + monster_name + " attacks!")
            to_hit = (monster_str + roll(20)) - (player_def + roll(20))
            if to_hit >= 10:
                damage = roll(4) + int(monster_str / (21 - roll(20)))
                if player_is_defending:
                    damage = int(damage / 2)
                print("The " + monster_name + " hits " + player_name + " for " + str(damage) + " points.")
                player_hp = player_hp - damage
            else:
                print("The " + monster_name + " misses!")
            turn = (turn + 1) % len(turn_order)
    if player_hp > 0:
        if not fled:
            player_gp = player_gp + monster_gp
            print(player_name + " defeated the " + monster_name)
        print(player_name + " has " + str(player_gp) + " gold.")
        print("Continue fighting? (Y/N) ")
        choice = input("> ").lower().strip()
        if choice != "y":
            quitting = True
    else:
        print(player_name + " is dead.")
        print("GAME OVER")
        quitting = True
print("Your final score was " + str(player_gp) + " gold.")
