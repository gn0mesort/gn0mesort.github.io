# Creating an empty tuple
numbers = tuple()

for i in range(100):
    # (i, ) is a single value tuple with just i in it
    numbers = numbers + (i, )

print("There are " + str(len(numbers)) + " numbers in the tuple.")
# Numbers should have 0 to 99 in it now!
print(numbers)

