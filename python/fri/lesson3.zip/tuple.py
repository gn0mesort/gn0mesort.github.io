import time
numbers = (5, 4, 3, 2, 1)
print("Beginning countdown!")
for i in numbers:
    print(i)
    time.sleep(1)
boom = "BOOM!!"
print("/" + ("-" * (len(boom) + 4)) + "\\")
print("|  " + boom + "  |")
print("\\" + ("-" * (len(boom) + 4)) + "/")
